'use client';

import { useState, useCallback } from 'react';
import { Upload, X, Image as ImageIcon, Loader2 } from 'lucide-react';

interface LogoUploadProps {
  label: string;
  description: string;
  previewShape: 'square' | 'wide' | 'circle';
  previewSize: 'sm' | 'md' | 'lg';
  value?: string;
  onChange: (url: string | null) => void;
  onUpload: (file: File) => Promise<string>;
}

export function LogoUpload({ 
  label, 
  description, 
  previewShape, 
  previewSize,
  value, 
  onChange,
  onUpload 
}: LogoUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-24 h-24',
    lg: 'w-32 h-32'
  };

  const shapeClasses = {
    square: 'rounded-lg',
    wide: 'rounded-lg aspect-[3/1] w-full max-w-[200px] h-auto',
    circle: 'rounded-full'
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    setError(null);

    const file = e.dataTransfer.files[0];
    if (file) {
      await uploadFile(file);
    }
  }, []);

  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const file = e.target.files?.[0];
    if (file) {
      await uploadFile(file);
    }
  }, []);

  const uploadFile = async (file: File) => {
    // Validate file type
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file (PNG, JPG, SVG)');
      return;
    }

    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      setError('File size must be less than 2MB');
      return;
    }

    setIsUploading(true);
    try {
      const url = await onUpload(file);
      onChange(url);
    } catch (err) {
      setError('Failed to upload image. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemove = () => {
    onChange(null);
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-neutral-700">{label}</label>
      <p className="text-xs text-neutral-500">{description}</p>
      
      {value ? (
        // Preview with remove button
        <div className="relative inline-block group">
          <div className={`${previewShape === 'wide' ? shapeClasses.wide : `${sizeClasses[previewSize]} ${shapeClasses[previewShape]}`} overflow-hidden border-2 border-neutral-200 bg-neutral-100`}>
            <img 
              src={value} 
              alt={label}
              className="w-full h-full object-contain"
            />
          </div>
          <button
            type="button"
            onClick={handleRemove}
            className="absolute -top-2 -right-2 p-1 bg-red-500 text-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      ) : (
        // Upload dropzone
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`
            relative border-2 border-dashed rounded-lg p-6 text-center cursor-pointer
            transition-all duration-150
            ${isDragging 
              ? 'border-brand-500 bg-brand-50' 
              : 'border-neutral-300 hover:border-brand-400 hover:bg-neutral-50'
            }
            ${isUploading ? 'pointer-events-none opacity-60' : ''}
          `}
        >
          <input
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            disabled={isUploading}
          />
          
          <div className="flex flex-col items-center gap-2">
            {isUploading ? (
              <Loader2 className="w-8 h-8 text-brand-500 animate-spin" />
            ) : (
              <div className="p-3 bg-neutral-100 rounded-full">
                <Upload className="w-5 h-5 text-neutral-400" />
              </div>
            )}
            <div>
              <p className="text-sm font-medium text-neutral-700">
                {isUploading ? 'Uploading...' : 'Drop image here or click to upload'}
              </p>
              <p className="text-xs text-neutral-500 mt-1">
                PNG, JPG or SVG up to 2MB
              </p>
            </div>
          </div>
        </div>
      )}

      {error && (
        <p className="text-xs text-red-500 mt-1">{error}</p>
      )}
    </div>
  );
}

// Branding section component with all three logo upload zones
interface DevelopmentBrandingProps {
  sidebarLogo?: string;
  assistantLogo?: string;
  toolbarLogo?: string;
  onSidebarLogoChange: (url: string | null) => void;
  onAssistantLogoChange: (url: string | null) => void;
  onToolbarLogoChange: (url: string | null) => void;
  onUpload: (file: File, type: 'sidebar' | 'assistant' | 'toolbar') => Promise<string>;
}

export function DevelopmentBranding({
  sidebarLogo,
  assistantLogo,
  toolbarLogo,
  onSidebarLogoChange,
  onAssistantLogoChange,
  onToolbarLogoChange,
  onUpload
}: DevelopmentBrandingProps) {
  return (
    <div className="bg-white border border-gold-100 rounded-lg p-6 shadow-sm space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-neutral-100">
        <div className="p-2 bg-brand-50 rounded-lg">
          <ImageIcon className="w-5 h-5 text-brand-600" />
        </div>
        <div>
          <h3 className="font-semibold text-neutral-900">Branding & Logos</h3>
          <p className="text-sm text-neutral-500">Customize the look of the developer and homeowner portals</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Sidebar Logo */}
        <div className="space-y-3">
          <div className="bg-neutral-900 rounded-lg p-4 h-32 flex items-start">
            <div className="w-full">
              <div className="flex items-center gap-2 mb-3">
                {sidebarLogo ? (
                  <img src={sidebarLogo} alt="Sidebar logo" className="h-8 object-contain" />
                ) : (
                  <div className="h-8 w-24 bg-neutral-700 rounded animate-pulse" />
                )}
              </div>
              <div className="space-y-1.5">
                <div className="h-2 w-20 bg-neutral-700 rounded" />
                <div className="h-2 w-16 bg-neutral-800 rounded" />
                <div className="h-2 w-18 bg-neutral-800 rounded" />
              </div>
            </div>
          </div>
          <LogoUpload
            label="Sidebar Logo"
            description="Appears in top-left of developer dashboard"
            previewShape="wide"
            previewSize="md"
            value={sidebarLogo}
            onChange={onSidebarLogoChange}
            onUpload={(file) => onUpload(file, 'sidebar')}
          />
        </div>

        {/* Assistant Center Logo */}
        <div className="space-y-3">
          <div className="bg-neutral-100 rounded-lg p-4 h-32 flex items-center justify-center">
            <div className="text-center">
              {assistantLogo ? (
                <img src={assistantLogo} alt="Assistant logo" className="h-12 mx-auto object-contain" />
              ) : (
                <div className="h-12 w-12 bg-neutral-300 rounded-full mx-auto animate-pulse" />
              )}
              <p className="text-xs text-neutral-400 mt-2">Hi, how can I help?</p>
            </div>
          </div>
          <LogoUpload
            label="Assistant Logo"
            description="Centered in the property assistant chat"
            previewShape="circle"
            previewSize="lg"
            value={assistantLogo}
            onChange={onAssistantLogoChange}
            onUpload={(file) => onUpload(file, 'assistant')}
          />
        </div>

        {/* Toolbar Logo */}
        <div className="space-y-3">
          <div className="bg-white border border-neutral-200 rounded-lg h-32">
            <div className="flex items-center gap-2 px-3 py-2 border-b border-neutral-200 bg-neutral-50 rounded-t-lg">
              {toolbarLogo ? (
                <img src={toolbarLogo} alt="Toolbar logo" className="h-6 object-contain" />
              ) : (
                <div className="h-6 w-6 bg-neutral-300 rounded animate-pulse" />
              )}
              <span className="text-xs text-neutral-500">Development Name</span>
            </div>
            <div className="p-3 space-y-2">
              <div className="h-2 w-full bg-neutral-100 rounded" />
              <div className="h-2 w-3/4 bg-neutral-100 rounded" />
            </div>
          </div>
          <LogoUpload
            label="Toolbar Logo"
            description="Appears in the assistant toolbar header"
            previewShape="square"
            previewSize="sm"
            value={toolbarLogo}
            onChange={onToolbarLogoChange}
            onUpload={(file) => onUpload(file, 'toolbar')}
          />
        </div>
      </div>

      <div className="pt-4 border-t border-neutral-100">
        <p className="text-xs text-neutral-500">
          <strong>Tip:</strong> Use transparent PNG or SVG files for best results. Recommended sizes: Sidebar (200x50px), Assistant (120x120px), Toolbar (40x40px)
        </p>
      </div>
    </div>
  );
}

export default DevelopmentBranding;
