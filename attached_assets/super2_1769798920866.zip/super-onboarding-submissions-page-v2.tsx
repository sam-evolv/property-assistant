'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { 
  FileText, 
  Download, 
  Eye, 
  Calendar, 
  Building2, 
  MapPin, 
  Users, 
  Link as LinkIcon,
  Loader2,
  RefreshCw,
  CheckCircle,
  Clock,
  XCircle,
  Plus,
  ExternalLink,
  FileSpreadsheet,
  File
} from 'lucide-react';

interface OnboardingSubmission {
  id: string;
  tenant_id: string | null;
  admin_id: string | null;
  developer_email: string;
  development_name: string;
  development_address: string;
  county: string;
  estimated_units: number;
  expected_handover_date: string | null;
  planning_reference: string | null;
  planning_pack_url: string | null;
  master_spreadsheet_url: string | null;
  supporting_documents_urls: string[] | null;
  notes: string | null;
  status: 'pending' | 'in_review' | 'completed' | 'rejected';
  created_at: string;
  updated_at: string;
  // Joined data
  tenant_name?: string;
}

export default function OnboardingSubmissionsPage() {
  const router = useRouter();
  const [submissions, setSubmissions] = useState<OnboardingSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'pending' | 'in_review' | 'completed' | 'rejected'>('all');

  useEffect(() => {
    fetchSubmissions();
  }, []);

  const fetchSubmissions = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/super/onboarding-submissions');
      if (!res.ok) throw new Error('Failed to fetch submissions');
      const data = await res.json();
      setSubmissions(data.submissions || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load submissions');
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/super/onboarding-submissions/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (!res.ok) throw new Error('Failed to update status');
      fetchSubmissions();
    } catch (err) {
      alert('Failed to update status');
    }
  };

  const handleCreateDevelopment = (submission: OnboardingSubmission) => {
    // Navigate to new project page with submission data pre-filled
    const params = new URLSearchParams({
      from_submission: submission.id,
      name: submission.development_name,
      address: submission.development_address,
      county: submission.county,
      units: submission.estimated_units.toString(),
      tenant_id: submission.tenant_id || '',
      planning_ref: submission.planning_reference || '',
      handover_date: submission.expected_handover_date || '',
      spreadsheet_url: submission.master_spreadsheet_url || '',
    });
    router.push(`/super/projects/new?${params.toString()}`);
  };

  // Generate proper download URL for Supabase storage files
  const getFileDownloadUrl = (url: string | null) => {
    if (!url) return null;
    
    // If it's already a full URL, check if it needs the download parameter
    if (url.startsWith('http')) {
      // For Supabase storage URLs, ensure we have the right format
      if (url.includes('supabase') && !url.includes('?download=')) {
        return url;
      }
      return url;
    }
    
    // If it's a relative path, construct the full Supabase storage URL
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    if (supabaseUrl && url.startsWith('onboarding-files/')) {
      return `${supabaseUrl}/storage/v1/object/public/${url}`;
    }
    
    // Return as-is if we can't determine the format
    return url;
  };

  const getFileName = (url: string | null) => {
    if (!url) return 'Unknown file';
    const parts = url.split('/');
    const fileName = parts[parts.length - 1];
    // Remove any query parameters and decode
    return decodeURIComponent(fileName.split('?')[0]);
  };

  const filteredSubmissions = submissions.filter(s => 
    filter === 'all' ? true : s.status === filter
  );

  const statusConfig = {
    pending: { label: 'Pending', color: 'bg-amber-100 text-amber-700 border-amber-200', icon: Clock },
    in_review: { label: 'In Review', color: 'bg-blue-100 text-blue-700 border-blue-200', icon: Eye },
    completed: { label: 'Completed', color: 'bg-emerald-100 text-emerald-700 border-emerald-200', icon: CheckCircle },
    rejected: { label: 'Rejected', color: 'bg-red-100 text-red-700 border-red-200', icon: XCircle }
  };

  const formatDate = (date: string) => {
    const d = new Date(date);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    
    return d.toLocaleDateString('en-IE', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-900">Onboarding Submissions</h1>
          <p className="text-neutral-500 mt-1">Review and manage development onboarding requests from developers</p>
        </div>
        <button
          onClick={fetchSubmissions}
          className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-neutral-200 rounded-lg text-sm font-medium text-neutral-700 hover:bg-neutral-50 transition-all duration-150"
        >
          <RefreshCw className="w-4 h-4" />
          Refresh
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Submissions', value: submissions.length, icon: FileText, color: 'border-l-brand-500' },
          { label: 'Pending', value: submissions.filter(s => s.status === 'pending').length, icon: Clock, color: 'border-l-amber-500' },
          { label: 'In Review', value: submissions.filter(s => s.status === 'in_review').length, icon: Eye, color: 'border-l-blue-500' },
          { label: 'Completed', value: submissions.filter(s => s.status === 'completed').length, icon: CheckCircle, color: 'border-l-emerald-500' }
        ].map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className={`bg-white border-l-4 ${stat.color} rounded-lg p-4 shadow-sm`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-neutral-500">{stat.label}</p>
                  <p className="text-2xl font-semibold text-neutral-900 mt-1">{stat.value}</p>
                </div>
                <Icon className="w-8 h-8 text-neutral-200" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Search & Filter */}
      <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Search by development, email, or company..."
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none transition-all duration-150"
            />
            <Eye className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
          </div>
          <div className="flex gap-2">
            {(['all', 'pending', 'in_review', 'completed', 'rejected'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150 whitespace-nowrap ${
                  filter === f 
                    ? 'bg-neutral-900 text-white' 
                    : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                {f === 'all' ? 'All' : f === 'in_review' ? 'In Review' : f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}

      {/* Empty State */}
      {!loading && !error && filteredSubmissions.length === 0 && (
        <div className="bg-white border border-gold-100 rounded-lg p-12 text-center">
          <FileText className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-neutral-900">No submissions yet</h3>
          <p className="text-neutral-500 mt-1">New developer applications will appear here</p>
        </div>
      )}

      {/* Submissions List */}
      {!loading && !error && filteredSubmissions.length > 0 && (
        <div className="bg-white border border-gold-100 rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-neutral-100">
            <h2 className="font-semibold text-neutral-900">Submissions</h2>
            <p className="text-sm text-neutral-500">{filteredSubmissions.length} submission{filteredSubmissions.length !== 1 ? 's' : ''} found</p>
          </div>
          
          {/* Table Header */}
          <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3 bg-neutral-50 border-b border-neutral-100 text-xs font-semibold text-neutral-500 uppercase tracking-wider">
            <div className="col-span-3">Development</div>
            <div className="col-span-2">Developer</div>
            <div className="col-span-1">Units</div>
            <div className="col-span-2">Status</div>
            <div className="col-span-2">Submitted</div>
            <div className="col-span-2 text-right">Actions</div>
          </div>

          {/* Rows */}
          {filteredSubmissions.map((submission) => {
            const StatusIcon = statusConfig[submission.status].icon;
            const isExpanded = expandedId === submission.id;
            
            return (
              <div key={submission.id} className="border-b border-neutral-100 last:border-b-0">
                {/* Main Row */}
                <div 
                  className="grid grid-cols-12 gap-4 px-6 py-4 items-center hover:bg-neutral-50 transition-colors cursor-pointer"
                  onClick={() => setExpandedId(isExpanded ? null : submission.id)}
                >
                  <div className="col-span-3">
                    <p className="font-medium text-neutral-900">{submission.development_name}</p>
                    <p className="text-sm text-neutral-500 flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {submission.development_address}, {submission.county}
                    </p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-neutral-900">{submission.developer_email}</p>
                  </div>
                  <div className="col-span-1">
                    <span className="font-semibold text-neutral-900">{submission.estimated_units}</span>
                  </div>
                  <div className="col-span-2">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${statusConfig[submission.status].color}`}>
                      <StatusIcon className="w-3.5 h-3.5" />
                      {statusConfig[submission.status].label}
                    </span>
                  </div>
                  <div className="col-span-2 text-sm text-neutral-500">
                    {formatDate(submission.created_at)}
                  </div>
                  <div className="col-span-2 flex justify-end gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setExpandedId(isExpanded ? null : submission.id);
                      }}
                      className="p-2 text-neutral-400 hover:text-neutral-600 hover:bg-neutral-100 rounded-lg transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCreateDevelopment(submission);
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-white bg-brand-500 hover:bg-brand-600 rounded-lg transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      Create Development
                    </button>
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="px-6 py-4 bg-neutral-50 border-t border-neutral-100">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {/* Details Column */}
                      <div className="space-y-4">
                        <h4 className="font-medium text-neutral-900 text-sm">Details</h4>
                        <div className="space-y-3 text-sm">
                          <div className="flex items-start gap-3">
                            <Calendar className="w-4 h-4 text-neutral-400 mt-0.5" />
                            <div>
                              <p className="text-neutral-500">Expected Handover</p>
                              <p className="font-medium text-neutral-900">
                                {submission.expected_handover_date 
                                  ? new Date(submission.expected_handover_date).toLocaleDateString('en-IE', { day: 'numeric', month: 'short', year: 'numeric' })
                                  : 'Not specified'}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start gap-3">
                            <FileText className="w-4 h-4 text-neutral-400 mt-0.5" />
                            <div>
                              <p className="text-neutral-500">Planning Reference</p>
                              <p className="font-medium text-neutral-900">{submission.planning_reference || 'Not provided'}</p>
                            </div>
                          </div>
                          <div className="flex items-start gap-3">
                            <Building2 className="w-4 h-4 text-neutral-400 mt-0.5" />
                            <div>
                              <p className="text-neutral-500">Tenant</p>
                              <p className="font-medium text-neutral-900">{submission.tenant_name || 'Not assigned'}</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Files Column */}
                      <div className="space-y-4">
                        <h4 className="font-medium text-neutral-900 text-sm">Uploaded Files</h4>
                        <div className="space-y-2">
                          {submission.planning_pack_url && (
                            <a 
                              href={getFileDownloadUrl(submission.planning_pack_url) || '#'}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-3 p-3 bg-white border border-neutral-200 rounded-lg hover:border-brand-300 hover:bg-brand-50 transition-colors group"
                            >
                              <div className="p-2 bg-red-100 rounded-lg">
                                <File className="w-4 h-4 text-red-600" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-neutral-900 truncate">Planning Pack</p>
                                <p className="text-xs text-neutral-500 truncate">{getFileName(submission.planning_pack_url)}</p>
                              </div>
                              <ExternalLink className="w-4 h-4 text-neutral-400 group-hover:text-brand-500" />
                            </a>
                          )}
                          {submission.master_spreadsheet_url && (
                            <a 
                              href={getFileDownloadUrl(submission.master_spreadsheet_url) || '#'}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-3 p-3 bg-white border border-neutral-200 rounded-lg hover:border-brand-300 hover:bg-brand-50 transition-colors group"
                            >
                              <div className="p-2 bg-emerald-100 rounded-lg">
                                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-neutral-900 truncate">Master Spreadsheet</p>
                                <p className="text-xs text-neutral-500 truncate">{getFileName(submission.master_spreadsheet_url)}</p>
                              </div>
                              <ExternalLink className="w-4 h-4 text-neutral-400 group-hover:text-brand-500" />
                            </a>
                          )}
                          {(!submission.planning_pack_url && !submission.master_spreadsheet_url) && (
                            <p className="text-sm text-neutral-500 italic">No files uploaded</p>
                          )}
                        </div>
                      </div>

                      {/* Notes & Actions Column */}
                      <div className="space-y-4">
                        <h4 className="font-medium text-neutral-900 text-sm">Notes</h4>
                        {submission.notes ? (
                          <p className="text-sm text-neutral-600 bg-white p-3 rounded-lg border border-neutral-200">
                            {submission.notes}
                          </p>
                        ) : (
                          <p className="text-sm text-neutral-500 italic">No notes provided</p>
                        )}
                        
                        <div className="pt-2">
                          <h4 className="font-medium text-neutral-900 text-sm mb-2">Update Status</h4>
                          <div className="flex flex-wrap gap-2">
                            {(['pending', 'in_review', 'completed', 'rejected'] as const).map((status) => (
                              <button
                                key={status}
                                onClick={() => updateStatus(submission.id, status)}
                                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 ${
                                  submission.status === status
                                    ? 'bg-neutral-900 text-white'
                                    : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
                                }`}
                              >
                                {status === 'in_review' ? 'In Review' : status.charAt(0).toUpperCase() + status.slice(1)}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Create Development CTA */}
                    <div className="mt-6 pt-4 border-t border-neutral-200 flex justify-end">
                      <button
                        onClick={() => handleCreateDevelopment(submission)}
                        className="inline-flex items-center gap-2 px-5 py-2.5 bg-brand-500 text-white font-medium rounded-lg hover:bg-brand-600 shadow-sm transition-all duration-150"
                      >
                        <Plus className="w-4 h-4" />
                        Create Development from Submission
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
