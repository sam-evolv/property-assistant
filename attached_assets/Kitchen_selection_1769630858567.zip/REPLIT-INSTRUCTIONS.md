# Replit Integration Instructions

## Overview

I'm providing you with **complete, styled React components** for the Kitchen Selections feature. Your job is to:

1. Add these files to the project
2. Run the database schema
3. Wire up the routing
4. Make any small adjustments to match existing patterns

**DO NOT change the styling.** The components use the OpenHouse design system exactly. Any styling changes will break visual consistency.

---

## Step 1: Run Database Schema

Open Supabase SQL Editor and run the contents of `database-schema.sql`. This creates:
- `kitchen_selection_options` table (stores dropdown options per development)
- `kitchen_selections` table (stores actual selections per unit)
- Triggers to auto-calculate completion
- Trigger to sync completion to Sales Pipeline
- Row Level Security policies

**IMPORTANT:** The schema assumes these tables exist:
- `developments` (with `id`, `developer_id` columns)
- `units` (with `id`, `development_id`, `unit_number`, `address`, `type`, `beds` columns)
- `purchasers` (linked to units)

If your column names are different, adjust the SQL accordingly.

---

## Step 2: Add Components

Copy the entire folder structure into your project:

```
/components/developer/kitchen-selections/
├── components/
│   ├── KitchenSelectionsPage.tsx
│   ├── KitchenSelectionsTable.tsx
│   ├── SelectionDropdown.tsx
│   ├── FilterTabs.tsx
│   ├── StatusBadge.tsx
│   ├── TypeBadge.tsx
│   └── SettingsModal.tsx
├── hooks/
│   ├── useKitchenSelections.ts
│   └── useSelectionOptions.ts
├── types.ts
└── index.ts
```

---

## Step 3: Fix Import Paths

In each component file, update the import for `cn` utility:

```tsx
// Change this:
import { cn } from '@/lib/utils';

// To match your project's path, e.g.:
import { cn } from '@/utils/cn';
// or
import { cn } from '~/lib/utils';
```

If you don't have a `cn` utility, add this to your utils:

```ts
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

---

## Step 4: Update Supabase Client Import

The hooks use `@supabase/auth-helpers-nextjs`. If your project uses a different Supabase setup, update the import in both hook files:

```tsx
// Current:
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
const supabase = createClientComponentClient();

// Change to match your project, e.g.:
import { supabase } from '@/lib/supabase';
// or
import { useSupabase } from '@/hooks/useSupabase';
```

---

## Step 5: Update the Page Route

Find your kitchen selections page (probably `/app/developer/kitchen-selections/page.tsx` or similar) and replace it with:

```tsx
// app/developer/kitchen-selections/page.tsx
'use client';

import { useParams } from 'next/navigation';
import { KitchenSelectionsPage } from '@/components/developer/kitchen-selections';
// Import your existing hook or method to get current development
import { useDevelopment } from '@/hooks/useDevelopment'; 

export default function KitchenSelectionsRoute() {
  // Get the current development - adjust to match your existing pattern
  const { developmentId } = useParams();
  const { development } = useDevelopment(developmentId as string);
  
  if (!development) {
    return <div>Loading...</div>;
  }

  return (
    <KitchenSelectionsPage
      developmentId={development.id}
      developmentName={development.name}
    />
  );
}
```

---

## Step 6: Adjust Data Schema (if needed)

The components expect units to have this shape:

```ts
{
  id: string;
  unit_number: string;
  address: string;        // Full address like "1 Longview Park"
  type: string;           // Unit type like "BD01"
  beds: string;           // "3 bed"
  purchaser: {
    name: string;
  } | null;
}
```

If your `units` table doesn't have an `address` column, you'll need to either:
1. Add it to the database
2. Generate it in the query (e.g., `concat(unit_number, ' ', development_name) as address`)
3. Modify the component to construct it from available data

---

## Step 7: Connect Comments (Optional)

The table has a comments button that calls `onOpenComments(unitId)`. Connect this to your existing smart comments system:

```tsx
// In KitchenSelectionsTable usage:
onOpenComments={(unitId) => {
  // Open your existing comments modal/drawer
  openCommentsModal(unitId, 'kitchen-selection');
}}
```

---

## Step 8: Test

1. Navigate to Kitchen Selections
2. Verify units load with correct addresses and purchasers
3. Click a dropdown - it should open and show options
4. Select an option - it should save (check Supabase)
5. Select "No" for Kitchen - Counter/Units/Handle should disable
6. Complete all selections for a unit - Status should change to "Complete"
7. Open Settings - add/remove options
8. Use filters and search

---

## What NOT to Change

- **Colors** - Uses brand-500 (#D4AF37), emerald-500, amber-500
- **Border radius** - Uses rounded-lg (8px), rounded-xl (12px)
- **Spacing** - Uses design system spacing scale
- **Shadows** - Uses shadow-sm, shadow-lg
- **Transitions** - All use duration-150

If something looks wrong, it's likely an import path issue, not a styling issue.

---

## Troubleshooting

**Dropdowns not opening:**
- Check browser console for errors
- Verify z-index isn't being overridden by a parent

**Data not loading:**
- Check Supabase RLS policies
- Verify the user is authenticated
- Check that development_id is being passed correctly

**Styles look wrong:**
- Make sure Tailwind is processing the new files
- Check that your Tailwind config includes the brand colors
- Verify the `cn` utility is working

**"Column not found" errors:**
- Your table schema differs from expected
- Adjust the Supabase queries in the hooks to match your column names
