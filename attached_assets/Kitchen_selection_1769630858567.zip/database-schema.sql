-- Kitchen Selections Database Schema
-- Run this in Supabase SQL Editor

-- ============================================
-- TABLE: kitchen_selection_options
-- Stores developer-defined dropdown options per development
-- ============================================

CREATE TABLE IF NOT EXISTS kitchen_selection_options (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  development_id UUID NOT NULL REFERENCES developments(id) ON DELETE CASCADE,
  category TEXT NOT NULL CHECK (category IN ('counter', 'units', 'handle', 'wardrobeStyle')),
  option_value TEXT NOT NULL,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(development_id, category, option_value)
);

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_kitchen_options_development 
ON kitchen_selection_options(development_id);

-- ============================================
-- TABLE: kitchen_selections
-- Stores actual selections per unit
-- ============================================

CREATE TABLE IF NOT EXISTS kitchen_selections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  kitchen BOOLEAN, -- Yes = true, No = false, null = not selected yet
  counter TEXT,
  units TEXT,
  handle TEXT,
  wardrobes BOOLEAN, -- Yes = true, No = false, null = not selected yet
  wardrobe_style TEXT,
  is_complete BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(unit_id)
);

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_kitchen_selections_unit 
ON kitchen_selections(unit_id);

CREATE INDEX IF NOT EXISTS idx_kitchen_selections_complete 
ON kitchen_selections(is_complete);

-- ============================================
-- FUNCTION: Calculate if selection is complete
-- ============================================

CREATE OR REPLACE FUNCTION calculate_kitchen_selection_complete()
RETURNS TRIGGER AS $$
BEGIN
  -- Logic: Complete when all required fields are filled
  -- based on the Yes/No selections for Kitchen and Wardrobes
  
  IF NEW.kitchen IS NULL THEN
    -- Kitchen not selected yet, definitely not complete
    NEW.is_complete := FALSE;
    
  ELSIF NEW.kitchen = FALSE AND NEW.wardrobes = FALSE THEN
    -- No kitchen, no wardrobes = complete (nothing to select)
    NEW.is_complete := TRUE;
    
  ELSIF NEW.kitchen = FALSE AND NEW.wardrobes = TRUE AND NEW.wardrobe_style IS NOT NULL THEN
    -- No kitchen, yes wardrobes with style selected = complete
    NEW.is_complete := TRUE;
    
  ELSIF NEW.kitchen = TRUE AND NEW.counter IS NOT NULL AND NEW.units IS NOT NULL AND NEW.handle IS NOT NULL THEN
    -- Yes kitchen with all kitchen options selected
    IF NEW.wardrobes = FALSE THEN
      -- No wardrobes = complete
      NEW.is_complete := TRUE;
    ELSIF NEW.wardrobes = TRUE AND NEW.wardrobe_style IS NOT NULL THEN
      -- Yes wardrobes with style = complete
      NEW.is_complete := TRUE;
    ELSIF NEW.wardrobes IS NULL THEN
      -- Wardrobes not selected yet
      NEW.is_complete := FALSE;
    ELSE
      NEW.is_complete := FALSE;
    END IF;
    
  ELSE
    NEW.is_complete := FALSE;
  END IF;
  
  -- Set completed_at timestamp when becoming complete
  IF NEW.is_complete = TRUE AND (OLD IS NULL OR OLD.is_complete = FALSE) THEN
    NEW.completed_at := NOW();
  ELSIF NEW.is_complete = FALSE THEN
    NEW.completed_at := NULL;
  END IF;
  
  -- Always update the updated_at timestamp
  NEW.updated_at := NOW();
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
DROP TRIGGER IF EXISTS kitchen_selection_complete_trigger ON kitchen_selections;
CREATE TRIGGER kitchen_selection_complete_trigger
BEFORE INSERT OR UPDATE ON kitchen_selections
FOR EACH ROW EXECUTE FUNCTION calculate_kitchen_selection_complete();

-- ============================================
-- FUNCTION: Sync completion to Sales Pipeline
-- Updates units table when kitchen selection is complete
-- ============================================

-- First, add the column to units if it doesn't exist
-- ALTER TABLE units ADD COLUMN IF NOT EXISTS kitchen_complete_date TIMESTAMP WITH TIME ZONE;

CREATE OR REPLACE FUNCTION sync_kitchen_to_pipeline()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.is_complete = TRUE AND (OLD IS NULL OR OLD.is_complete = FALSE) THEN
    -- Selection just became complete - update the unit
    UPDATE units 
    SET kitchen_complete_date = NEW.completed_at
    WHERE id = NEW.unit_id;
    
  ELSIF NEW.is_complete = FALSE AND OLD IS NOT NULL AND OLD.is_complete = TRUE THEN
    -- Selection was uncompleted - clear the date
    UPDATE units 
    SET kitchen_complete_date = NULL
    WHERE id = NEW.unit_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for pipeline sync
DROP TRIGGER IF EXISTS sync_kitchen_pipeline_trigger ON kitchen_selections;
CREATE TRIGGER sync_kitchen_pipeline_trigger
AFTER INSERT OR UPDATE ON kitchen_selections
FOR EACH ROW EXECUTE FUNCTION sync_kitchen_to_pipeline();

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================

ALTER TABLE kitchen_selection_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE kitchen_selections ENABLE ROW LEVEL SECURITY;

-- Policy for kitchen_selection_options: Developers can view their development options
DROP POLICY IF EXISTS "Developers can view their development options" ON kitchen_selection_options;
CREATE POLICY "Developers can view their development options"
ON kitchen_selection_options FOR SELECT
USING (
  development_id IN (
    SELECT id FROM developments WHERE developer_id = auth.uid()
  )
);

-- Policy for kitchen_selection_options: Developers can insert options
DROP POLICY IF EXISTS "Developers can insert options" ON kitchen_selection_options;
CREATE POLICY "Developers can insert options"
ON kitchen_selection_options FOR INSERT
WITH CHECK (
  development_id IN (
    SELECT id FROM developments WHERE developer_id = auth.uid()
  )
);

-- Policy for kitchen_selection_options: Developers can update their options
DROP POLICY IF EXISTS "Developers can update options" ON kitchen_selection_options;
CREATE POLICY "Developers can update options"
ON kitchen_selection_options FOR UPDATE
USING (
  development_id IN (
    SELECT id FROM developments WHERE developer_id = auth.uid()
  )
);

-- Policy for kitchen_selection_options: Developers can delete their options
DROP POLICY IF EXISTS "Developers can delete options" ON kitchen_selection_options;
CREATE POLICY "Developers can delete options"
ON kitchen_selection_options FOR DELETE
USING (
  development_id IN (
    SELECT id FROM developments WHERE developer_id = auth.uid()
  )
);

-- Policy for kitchen_selections: Developers can view their unit selections
DROP POLICY IF EXISTS "Developers can view their unit selections" ON kitchen_selections;
CREATE POLICY "Developers can view their unit selections"
ON kitchen_selections FOR SELECT
USING (
  unit_id IN (
    SELECT u.id FROM units u
    JOIN developments d ON u.development_id = d.id
    WHERE d.developer_id = auth.uid()
  )
);

-- Policy for kitchen_selections: Developers can insert selections
DROP POLICY IF EXISTS "Developers can insert selections" ON kitchen_selections;
CREATE POLICY "Developers can insert selections"
ON kitchen_selections FOR INSERT
WITH CHECK (
  unit_id IN (
    SELECT u.id FROM units u
    JOIN developments d ON u.development_id = d.id
    WHERE d.developer_id = auth.uid()
  )
);

-- Policy for kitchen_selections: Developers can update selections
DROP POLICY IF EXISTS "Developers can update selections" ON kitchen_selections;
CREATE POLICY "Developers can update selections"
ON kitchen_selections FOR UPDATE
USING (
  unit_id IN (
    SELECT u.id FROM units u
    JOIN developments d ON u.development_id = d.id
    WHERE d.developer_id = auth.uid()
  )
);

-- Policy for kitchen_selections: Developers can delete selections
DROP POLICY IF EXISTS "Developers can delete selections" ON kitchen_selections;
CREATE POLICY "Developers can delete selections"
ON kitchen_selections FOR DELETE
USING (
  unit_id IN (
    SELECT u.id FROM units u
    JOIN developments d ON u.development_id = d.id
    WHERE d.developer_id = auth.uid()
  )
);

-- ============================================
-- SEED DATA (Optional - for testing)
-- ============================================

-- Example: Insert default options for a development
-- Replace 'YOUR_DEVELOPMENT_ID' with actual UUID
/*
INSERT INTO kitchen_selection_options (development_id, category, option_value, display_order) VALUES
  ('YOUR_DEVELOPMENT_ID', 'counter', 'Granite', 0),
  ('YOUR_DEVELOPMENT_ID', 'counter', 'Quartz', 1),
  ('YOUR_DEVELOPMENT_ID', 'counter', 'Laminate', 2),
  ('YOUR_DEVELOPMENT_ID', 'units', 'Oak', 0),
  ('YOUR_DEVELOPMENT_ID', 'units', 'White Gloss', 1),
  ('YOUR_DEVELOPMENT_ID', 'units', 'Walnut', 2),
  ('YOUR_DEVELOPMENT_ID', 'handle', 'Brass', 0),
  ('YOUR_DEVELOPMENT_ID', 'handle', 'Chrome', 1),
  ('YOUR_DEVELOPMENT_ID', 'handle', 'Black', 2),
  ('YOUR_DEVELOPMENT_ID', 'wardrobeStyle', 'Walnut', 0),
  ('YOUR_DEVELOPMENT_ID', 'wardrobeStyle', 'Oak', 1),
  ('YOUR_DEVELOPMENT_ID', 'wardrobeStyle', 'Mirror', 2),
  ('YOUR_DEVELOPMENT_ID', 'wardrobeStyle', 'White', 3);
*/
