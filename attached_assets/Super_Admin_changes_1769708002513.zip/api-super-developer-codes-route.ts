// =============================================================================
// API Route: /api/super/developer-codes
// Location: apps/unified-portal/app/api/super/developer-codes/route.ts
// 
// Handles:
// - GET: List all developer codes
// - POST: Create a new developer code
// =============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client with service role for full access
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

// =============================================================================
// Helper: Generate a unique developer code
// Format: [PREFIX]-[YEAR]-[RANDOM]
// Example: CAIRN-2026-X7K
// =============================================================================
function generateCode(tenantName: string): string {
  // Create prefix from tenant name (first 4-6 chars, uppercase, alphanumeric only)
  const prefix = tenantName
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .substring(0, 6) || 'DEV';
  
  // Current year
  const year = new Date().getFullYear();
  
  // Random 3-character suffix (alphanumeric, no confusing chars like 0/O, 1/I/L)
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  let suffix = '';
  for (let i = 0; i < 3; i++) {
    suffix += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return `${prefix}-${year}-${suffix}`;
}

// =============================================================================
// GET: List all developer codes
// =============================================================================
export async function GET(request: NextRequest) {
  try {
    // TODO: Add authentication check for super_admin role
    // For now, this should be protected by middleware
    
    const { data, error } = await supabase
      .from('developer_codes')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching developer codes:', error);
      return NextResponse.json(
        { error: 'Failed to fetch developer codes' },
        { status: 500 }
      );
    }
    
    return NextResponse.json({ codes: data });
    
  } catch (error) {
    console.error('Unexpected error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// =============================================================================
// POST: Create a new developer code
// =============================================================================
export async function POST(request: NextRequest) {
  try {
    // TODO: Add authentication check for super_admin role
    
    const body = await request.json();
    const { tenantName, tenantId, notes, expiresInDays } = body;
    
    if (!tenantName) {
      return NextResponse.json(
        { error: 'Tenant name is required' },
        { status: 400 }
      );
    }
    
    // Generate unique code
    let code = generateCode(tenantName);
    
    // Check for collision (unlikely but possible)
    let attempts = 0;
    while (attempts < 5) {
      const { data: existing } = await supabase
        .from('developer_codes')
        .select('id')
        .eq('code', code)
        .single();
      
      if (!existing) break;
      
      // Collision - generate new code
      code = generateCode(tenantName);
      attempts++;
    }
    
    if (attempts >= 5) {
      return NextResponse.json(
        { error: 'Failed to generate unique code. Please try again.' },
        { status: 500 }
      );
    }
    
    // Calculate expiry date if specified
    let expiresAt = null;
    if (expiresInDays && expiresInDays > 0) {
      const expiry = new Date();
      expiry.setDate(expiry.getDate() + expiresInDays);
      expiresAt = expiry.toISOString();
    }
    
    // Insert the new code
    const { data, error } = await supabase
      .from('developer_codes')
      .insert({
        code,
        tenant_id: tenantId || null,
        tenant_name: tenantName,
        notes: notes || null,
        expires_at: expiresAt,
        is_active: true,
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error creating developer code:', error);
      return NextResponse.json(
        { error: 'Failed to create developer code' },
        { status: 500 }
      );
    }
    
    return NextResponse.json({ 
      success: true, 
      code: data 
    });
    
  } catch (error) {
    console.error('Unexpected error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
