// =============================================================================
// Super Admin Page: Developer Codes
// Location: apps/unified-portal/app/super/developer-codes/page.tsx
// 
// Generates and manages developer invitation codes for onboarding
// =============================================================================

'use client';

import { useState, useEffect } from 'react';
import { 
  Copy, 
  Check, 
  Plus, 
  RefreshCw, 
  Clock, 
  User, 
  Building2,
  AlertCircle 
} from 'lucide-react';

interface DeveloperCode {
  id: string;
  code: string;
  tenant_name: string;
  tenant_id: string | null;
  used_by_email: string | null;
  used_at: string | null;
  expires_at: string | null;
  is_active: boolean;
  notes: string | null;
  created_at: string;
}

export default function DeveloperCodesPage() {
  const [codes, setCodes] = useState<DeveloperCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  
  // Form state
  const [developerName, setDeveloperName] = useState('');
  const [expiresInDays, setExpiresInDays] = useState<number>(30);
  const [notes, setNotes] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch existing codes
  const fetchCodes = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch('/api/super/developer-codes');
      const data = await response.json();
      if (data.codes) {
        setCodes(data.codes);
      } else if (data.error) {
        setError(data.error);
      }
    } catch (err) {
      console.error('Error fetching codes:', err);
      setError('Failed to load developer codes');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCodes();
  }, []);

  // Generate new code
  const generateCode = async () => {
    if (!developerName.trim()) {
      setError('Please enter a developer name');
      return;
    }

    try {
      setGenerating(true);
      setError(null);
      
      const response = await fetch('/api/super/developer-codes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantName: developerName.trim(),
          expiresInDays: expiresInDays > 0 ? expiresInDays : null,
          notes: notes.trim() || null,
        }),
      });

      const data = await response.json();
      
      if (data.success && data.code) {
        setCodes([data.code, ...codes]);
        setDeveloperName('');
        setNotes('');
        setShowForm(false);
        copyToClipboard(data.code.code);
      } else {
        setError(data.error || 'Failed to generate code');
      }
    } catch (err) {
      console.error('Error generating code:', err);
      setError('Failed to generate code');
    } finally {
      setGenerating(false);
    }
  };

  // Copy code to clipboard
  const copyToClipboard = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCode(code);
      setTimeout(() => setCopiedCode(null), 2000);
    } catch (err) {
      console.error('Error copying to clipboard:', err);
    }
  };

  // Format date
  const formatDate = (dateString: string | null) => {
    if (!dateString) return '—';
    return new Date(dateString).toLocaleDateString('en-IE', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  // Get status badge
  const getStatusBadge = (code: DeveloperCode) => {
    if (code.used_at) {
      return (
        <span className="inline-flex items-center gap-1 text-xs bg-emerald-500/10 text-emerald-600 px-2 py-1 rounded-md font-medium">
          <Check className="w-3 h-3" />
          Used
        </span>
      );
    }
    if (!code.is_active) {
      return (
        <span className="inline-flex items-center gap-1 text-xs bg-red-500/10 text-red-600 px-2 py-1 rounded-md font-medium">
          Inactive
        </span>
      );
    }
    if (code.expires_at && new Date(code.expires_at) < new Date()) {
      return (
        <span className="inline-flex items-center gap-1 text-xs bg-amber-500/10 text-amber-600 px-2 py-1 rounded-md font-medium">
          <Clock className="w-3 h-3" />
          Expired
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-xs bg-brand-500/10 text-brand-600 px-2 py-1 rounded-md font-medium">
        Available
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-semibold text-neutral-900">Developer Codes</h1>
            <p className="text-neutral-500 mt-1">
              Generate invitation codes for new developers
            </p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={fetchCodes}
              disabled={loading}
              className="inline-flex items-center justify-center gap-2 font-medium 
                bg-white text-neutral-700 
                border border-neutral-200 
                hover:bg-neutral-50 hover:border-neutral-300 
                focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-neutral-400 
                active:scale-[0.98] 
                disabled:pointer-events-none disabled:opacity-50 
                shadow-sm transition-all duration-150 select-none
                h-10 px-4 text-sm rounded-lg"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            <button
              onClick={() => setShowForm(!showForm)}
              className="inline-flex items-center justify-center gap-2 font-medium 
                bg-brand-500 text-white 
                hover:bg-brand-600 hover:shadow-md 
                focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-brand-500 
                active:scale-[0.98] 
                disabled:pointer-events-none disabled:opacity-50 
                shadow-sm border border-brand-600/20 
                transition-all duration-150 select-none
                h-10 px-5 text-sm rounded-lg"
            >
              <Plus className="w-4 h-4" />
              Generate Code
            </button>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-lg flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
            <p className="text-sm text-red-700">{error}</p>
            <button 
              onClick={() => setError(null)}
              className="ml-auto text-red-400 hover:text-red-600"
            >
              ×
            </button>
          </div>
        )}

        {/* Generate Code Form */}
        {showForm && (
          <div className="mb-8 bg-white border border-gold-100 rounded-lg p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-neutral-900 mb-4">Generate New Code</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-2">
                  Developer Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={developerName}
                  onChange={(e) => setDeveloperName(e.target.value)}
                  placeholder="e.g., Cairn Homes"
                  className="w-full bg-white border border-neutral-200 rounded-lg 
                    h-10 px-3.5 text-sm
                    hover:border-neutral-300 
                    focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none
                    transition-all duration-150 
                    placeholder:text-neutral-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-2">
                  Expires In (days)
                </label>
                <input
                  type="number"
                  value={expiresInDays}
                  onChange={(e) => setExpiresInDays(parseInt(e.target.value) || 0)}
                  placeholder="30"
                  className="w-full bg-white border border-neutral-200 rounded-lg 
                    h-10 px-3.5 text-sm
                    hover:border-neutral-300 
                    focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none
                    transition-all duration-150 
                    placeholder:text-neutral-400"
                />
                <p className="text-xs text-neutral-400 mt-1">Set to 0 for no expiry</p>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-neutral-700 mb-2">
                  Notes (optional)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g., Meeting scheduled for Feb 5th"
                  className="w-full bg-white border border-neutral-200 rounded-lg 
                    h-10 px-3.5 text-sm
                    hover:border-neutral-300 
                    focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none
                    transition-all duration-150 
                    placeholder:text-neutral-400"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-neutral-100">
              <button
                onClick={() => {
                  setShowForm(false);
                  setDeveloperName('');
                  setNotes('');
                }}
                className="inline-flex items-center justify-center gap-2 font-medium 
                  bg-transparent text-neutral-600 
                  hover:bg-neutral-100 hover:text-neutral-900 
                  focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-neutral-400 
                  active:scale-[0.98] 
                  transition-all duration-150 select-none
                  h-10 px-4 text-sm rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={generateCode}
                disabled={generating || !developerName.trim()}
                className="inline-flex items-center justify-center gap-2 font-medium 
                  bg-brand-500 text-white 
                  hover:bg-brand-600 hover:shadow-md 
                  focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-brand-500 
                  active:scale-[0.98] 
                  disabled:pointer-events-none disabled:opacity-50 
                  shadow-sm border border-brand-600/20 
                  transition-all duration-150 select-none
                  h-10 px-5 text-sm rounded-lg"
              >
                {generating ? 'Generating...' : 'Generate & Copy'}
              </button>
            </div>
          </div>
        )}

        {/* Codes Table */}
        <div className="bg-white border border-gold-100 rounded-lg shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-neutral-100 bg-neutral-50/50">
                  <th className="text-left px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Code</th>
                  <th className="text-left px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Developer</th>
                  <th className="text-left px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Status</th>
                  <th className="text-left px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Created</th>
                  <th className="text-left px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Expires</th>
                  <th className="text-left px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Used By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {loading ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <RefreshCw className="w-5 h-5 text-neutral-400 animate-spin" />
                        <span className="text-sm text-neutral-500">Loading codes...</span>
                      </div>
                    </td>
                  </tr>
                ) : codes.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <Building2 className="w-8 h-8 text-neutral-300" />
                        <p className="text-sm text-neutral-500">No codes generated yet</p>
                        <button
                          onClick={() => setShowForm(true)}
                          className="mt-2 text-sm text-brand-500 hover:text-brand-600 font-medium"
                        >
                          Generate your first code →
                        </button>
                      </div>
                    </td>
                  </tr>
                ) : (
                  codes.map((code) => (
                    <tr key={code.id} className="hover:bg-neutral-50/50 transition-colors duration-150">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <code className="text-brand-600 font-mono text-sm bg-brand-500/10 px-2.5 py-1 rounded-md">
                            {code.code}
                          </code>
                          <button
                            onClick={() => copyToClipboard(code.code)}
                            className="p-1.5 text-neutral-400 hover:text-neutral-600 hover:bg-neutral-100 rounded-md transition-all duration-150"
                            title="Copy code"
                          >
                            {copiedCode === code.code ? (
                              <Check className="w-4 h-4 text-emerald-500" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-neutral-400" />
                          <span className="text-sm text-neutral-900">{code.tenant_name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {getStatusBadge(code)}
                      </td>
                      <td className="px-6 py-4 text-sm text-neutral-500">
                        {formatDate(code.created_at)}
                      </td>
                      <td className="px-6 py-4 text-sm text-neutral-500">
                        {formatDate(code.expires_at)}
                      </td>
                      <td className="px-6 py-4">
                        {code.used_by_email ? (
                          <div className="flex items-center gap-2 text-sm">
                            <User className="w-4 h-4 text-neutral-400" />
                            <span className="text-neutral-700">{code.used_by_email}</span>
                          </div>
                        ) : (
                          <span className="text-neutral-300">—</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Instructions */}
        <div className="mt-8 p-6 bg-neutral-50 border border-neutral-100 rounded-lg">
          <h3 className="text-sm font-semibold text-neutral-700 mb-3">How to use</h3>
          <ol className="text-sm text-neutral-600 space-y-2">
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-5 h-5 bg-brand-500/10 text-brand-600 rounded-full flex items-center justify-center text-xs font-medium">1</span>
              <span>Click "Generate Code" and enter the developer's company name</span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-5 h-5 bg-brand-500/10 text-brand-600 rounded-full flex items-center justify-center text-xs font-medium">2</span>
              <span>The code will be copied to your clipboard automatically</span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-5 h-5 bg-brand-500/10 text-brand-600 rounded-full flex items-center justify-center text-xs font-medium">3</span>
              <span>Send the code to the developer (email, WhatsApp, etc.)</span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-5 h-5 bg-brand-500/10 text-brand-600 rounded-full flex items-center justify-center text-xs font-medium">4</span>
              <span>They enter the code when signing up at <code className="text-brand-600 bg-brand-500/10 px-1.5 py-0.5 rounded">portal.openhouseai.ie/login</code></span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-5 h-5 bg-brand-500/10 text-brand-600 rounded-full flex items-center justify-center text-xs font-medium">5</span>
              <span>Once used, the code status changes to "Used" with their email</span>
            </li>
          </ol>
        </div>
      </div>
    </div>
  );
}
