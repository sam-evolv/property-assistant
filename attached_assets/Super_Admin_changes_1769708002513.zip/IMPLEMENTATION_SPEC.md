# Developer Onboarding Codes - Implementation Spec

## Overview

This feature allows Sam to generate unique invitation codes for property developers. When a developer signs up, they enter this code to link their account to their company.

## Database

✅ **ALREADY DONE** - The `developer_codes` table exists in Supabase with this schema:

```sql
CREATE TABLE developer_codes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(30) UNIQUE NOT NULL,        -- e.g., "CAIRN-2026-X7K"
  tenant_id UUID,                          -- Links to tenants table (optional)
  tenant_name TEXT,                        -- Human-readable name
  created_by UUID,                         -- Who created it
  used_by_email VARCHAR(255),              -- Email of person who used it
  used_at TIMESTAMP WITH TIME ZONE,        -- When it was used
  expires_at TIMESTAMP WITH TIME ZONE,     -- Optional expiry
  is_active BOOLEAN DEFAULT true,          -- Can deactivate without deleting
  notes TEXT,                              -- Admin notes
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

---

## Files to Create

### 1. API Route: List & Create Codes
**Location:** `apps/unified-portal/app/api/super/developer-codes/route.ts`

**Functionality:**
- `GET` - Returns all developer codes (for super admin view)
- `POST` - Creates a new code with auto-generated format: `[NAME]-[YEAR]-[XXX]`

**Code Generation Logic:**
```typescript
function generateCode(tenantName: string): string {
  const prefix = tenantName.toUpperCase().replace(/[^A-Z0-9]/g, '').substring(0, 6) || 'DEV';
  const year = new Date().getFullYear();
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // No confusing chars
  let suffix = '';
  for (let i = 0; i < 3; i++) {
    suffix += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `${prefix}-${year}-${suffix}`;
}
```

**Example codes:**
- `CAIRN-2026-X7K`
- `HOLLYB-2026-M3Q`
- `GLENVE-2026-P8N`

---

### 2. API Route: Validate Code (for signup)
**Location:** `apps/unified-portal/app/api/auth/validate-code/route.ts`

**Functionality:**
- `POST` with `{ code }` - Checks if code is valid
- Returns `{ valid: true, tenantName, tenantId }` or `{ valid: false, error }`

**Validation checks:**
1. Code exists
2. Code not already used (`used_at` is null)
3. Code is active (`is_active` is true)
4. Code not expired (if `expires_at` is set)

---

### 3. API Route: Mark Code as Used
**Location:** `apps/unified-portal/app/api/auth/use-code/route.ts`

**Functionality:**
- `POST` with `{ code, email }` - Marks the code as used after successful signup
- Updates `used_by_email` and `used_at` fields

---

### 4. Super Admin Page: Developer Codes
**Location:** `apps/unified-portal/app/super/developer-codes/page.tsx`

**Features:**
- Table showing all codes with status (Available, Used, Expired, Inactive)
- "Generate Code" button opens form
- Form fields: Developer Name (required), Expires In Days, Notes
- Click to copy code to clipboard
- Shows who used each code and when

**Design Requirements:**
- Use OpenHouse design system (gold brand color #D4AF37)
- Use Lucide React icons only
- Follow existing super admin layout patterns

---

## Integration Points

### Modify Signup Flow

The existing `/login` page needs a **Developer Code** input field. The flow should be:

1. User enters email + password + developer code
2. On submit, first call `/api/auth/validate-code` to verify code
3. If valid, proceed with Supabase auth signup
4. On successful signup, call `/api/auth/use-code` to mark code as used
5. Redirect to onboarding or dashboard

**This is a V2 task** - for now, Sam will manually link users after they sign up.

---

## Environment Variables Required

```env
NEXT_PUBLIC_SUPABASE_URL=https://mddxbilpjukwskeefakz.supabase.co
SUPABASE_SERVICE_ROLE_KEY=<service_role_key>
```

---

## Testing Checklist

- [ ] Can generate a new code from super admin
- [ ] Code appears in the table immediately
- [ ] Can copy code to clipboard
- [ ] Code shows correct status (Available)
- [ ] Validate endpoint returns `valid: true` for unused code
- [ ] Validate endpoint returns `valid: false` for used code
- [ ] Use-code endpoint marks code as used
- [ ] Table shows "Used" status with email after code is used

---

## File Structure

```
apps/unified-portal/app/
├── api/
│   ├── auth/
│   │   ├── validate-code/
│   │   │   └── route.ts          # Validate code during signup
│   │   └── use-code/
│   │       └── route.ts          # Mark code as used
│   └── super/
│       └── developer-codes/
│           └── route.ts          # GET list, POST create
└── super/
    └── developer-codes/
        └── page.tsx              # Super admin UI
```

---

## Security Notes

1. The `/api/super/*` routes should check for `super_admin` role
2. All codes are normalized to uppercase before storage/lookup
3. Service role key is used for database operations (not public key)
4. Codes cannot be reused once `used_at` is set

---

## Future Enhancements (V2)

1. Integrate code field into signup form
2. Auto-create tenant record when code is used
3. Email notification to Sam when code is used
4. Bulk code generation
5. Code deactivation from UI
