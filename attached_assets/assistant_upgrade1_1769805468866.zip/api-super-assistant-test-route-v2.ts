// /api/super/assistant/test/route.ts
// Routes test messages through the real chat system so it has access to all documents
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { development_id, message, include_custom_qa } = body;

    if (!development_id || !message) {
      return NextResponse.json({ error: 'development_id and message required' }, { status: 400 });
    }

    // Get the base URL for internal API calls
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 
                    process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : 
                    'http://localhost:3000';

    // Call the real chat API that has access to documents and RAG
    const chatResponse = await fetch(`${baseUrl}/api/chat`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        // Pass through any auth headers if needed
        ...Object.fromEntries(
          [...request.headers.entries()].filter(([key]) => 
            key.toLowerCase() === 'authorization' || 
            key.toLowerCase() === 'cookie'
          )
        )
      },
      body: JSON.stringify({
        development_id,
        message,
        // Flag to include custom Q&A overrides
        include_custom_qa: include_custom_qa ?? true,
        // Flag this as a test message (optional - for analytics)
        is_test: true
      })
    });

    if (!chatResponse.ok) {
      const errorText = await chatResponse.text();
      console.error('Chat API error:', errorText);
      return NextResponse.json(
        { error: 'Failed to get response from assistant' }, 
        { status: chatResponse.status }
      );
    }

    const data = await chatResponse.json();
    
    return NextResponse.json({ 
      response: data.response || data.message || data.content || 'No response generated'
    });
  } catch (err) {
    console.error('Error testing assistant:', err);
    return NextResponse.json({ error: 'Failed to get response' }, { status: 500 });
  }
}
