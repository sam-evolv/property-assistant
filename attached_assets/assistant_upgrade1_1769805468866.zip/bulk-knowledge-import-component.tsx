'use client';

import { useState } from 'react';
import {
  FileText,
  Upload,
  Loader2,
  CheckCircle,
  AlertCircle,
  Sparkles,
  ChevronDown,
  ChevronRight,
  Trash2,
  Save,
  Brain,
  Globe,
  Home,
  Info
} from 'lucide-react';

interface KnowledgeChunk {
  id: string;
  title: string;
  content: string;
  category: string;
  selected: boolean;
}

interface BulkKnowledgeImportProps {
  developmentId?: string;
  developmentName?: string;
  scope: 'development' | 'platform';
  onImportComplete: (count: number) => void;
}

const CATEGORIES = [
  { value: 'general', label: 'General Information' },
  { value: 'warranty', label: 'Warranty & Defects' },
  { value: 'maintenance', label: 'Maintenance' },
  { value: 'facilities', label: 'Facilities & Amenities' },
  { value: 'management', label: 'Management Company' },
  { value: 'legal', label: 'Legal & Compliance' },
  { value: 'local_area', label: 'Local Area Info' },
  { value: 'market', label: 'Property Market' },
  { value: 'energy', label: 'Energy & Sustainability' },
  { value: 'insurance', label: 'Insurance' },
];

export function BulkKnowledgeImport({ 
  developmentId, 
  developmentName,
  scope,
  onImportComplete 
}: BulkKnowledgeImportProps) {
  const [step, setStep] = useState<'input' | 'processing' | 'review' | 'importing' | 'complete'>('input');
  const [rawContent, setRawContent] = useState('');
  const [sourceTitle, setSourceTitle] = useState('');
  const [defaultCategory, setDefaultCategory] = useState('general');
  const [chunks, setChunks] = useState<KnowledgeChunk[]>([]);
  const [processing, setProcessing] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ success: number; failed: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [expandedChunks, setExpandedChunks] = useState<Set<string>>(new Set());

  // Process content with AI to extract knowledge chunks
  const processContent = async () => {
    if (!rawContent.trim()) {
      setError('Please enter some content to process');
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      const response = await fetch('/api/super/assistant/process-knowledge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: rawContent,
          source_title: sourceTitle,
          default_category: defaultCategory,
          scope,
          development_id: developmentId
        })
      });

      if (!response.ok) {
        throw new Error('Failed to process content');
      }

      const data = await response.json();
      
      // Add selection state and unique IDs to chunks
      const processedChunks = (data.chunks || []).map((chunk: any, index: number) => ({
        ...chunk,
        id: `chunk-${index}-${Date.now()}`,
        selected: true
      }));

      setChunks(processedChunks);
      setStep('review');
    } catch (err) {
      setError('Failed to process content. Please try again.');
      console.error('Processing error:', err);
    } finally {
      setProcessing(false);
    }
  };

  // Toggle chunk selection
  const toggleChunk = (id: string) => {
    setChunks(chunks.map(c => 
      c.id === id ? { ...c, selected: !c.selected } : c
    ));
  };

  // Toggle all chunks
  const toggleAll = (selected: boolean) => {
    setChunks(chunks.map(c => ({ ...c, selected })));
  };

  // Update chunk content
  const updateChunk = (id: string, field: 'title' | 'content' | 'category', value: string) => {
    setChunks(chunks.map(c => 
      c.id === id ? { ...c, [field]: value } : c
    ));
  };

  // Delete chunk
  const deleteChunk = (id: string) => {
    setChunks(chunks.filter(c => c.id !== id));
  };

  // Toggle expanded state
  const toggleExpanded = (id: string) => {
    const newExpanded = new Set(expandedChunks);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedChunks(newExpanded);
  };

  // Import selected chunks
  const importChunks = async () => {
    const selectedChunks = chunks.filter(c => c.selected);
    if (selectedChunks.length === 0) {
      setError('Please select at least one chunk to import');
      return;
    }

    setImporting(true);
    setStep('importing');
    setError(null);

    let success = 0;
    let failed = 0;

    for (const chunk of selectedChunks) {
      try {
        const response = await fetch('/api/super/assistant/knowledge', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            development_id: scope === 'development' ? developmentId : null,
            title: chunk.title,
            content: chunk.content,
            category: chunk.category,
            type: 'bulk_import',
            source: sourceTitle || 'Bulk Import',
            is_platform_wide: scope === 'platform'
          })
        });

        if (response.ok) {
          success++;
        } else {
          failed++;
        }
      } catch {
        failed++;
      }
    }

    setImportResult({ success, failed });
    setImporting(false);
    setStep('complete');
    
    if (success > 0) {
      onImportComplete(success);
    }
  };

  // Reset to start
  const reset = () => {
    setStep('input');
    setRawContent('');
    setSourceTitle('');
    setChunks([]);
    setImportResult(null);
    setError(null);
  };

  const selectedCount = chunks.filter(c => c.selected).length;

  return (
    <div className="bg-white border border-gold-100 rounded-lg shadow-sm overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 border-b border-neutral-100 bg-gradient-to-r from-purple-50 to-blue-50">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white rounded-lg shadow-sm">
            <Brain className="w-5 h-5 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold text-neutral-900">Bulk Knowledge Import</h3>
            <p className="text-sm text-neutral-600">
              {scope === 'platform' 
                ? 'Add knowledge that applies across all developments'
                : `Add knowledge specific to ${developmentName || 'this development'}`
              }
            </p>
          </div>
          <div className="ml-auto">
            {scope === 'platform' ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
                <Globe className="w-3.5 h-3.5" />
                Platform-wide
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                <Home className="w-3.5 h-3.5" />
                Development-specific
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Error Display */}
        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700 text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}

        {/* Step 1: Input */}
        {step === 'input' && (
          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="font-medium text-blue-900">AI-Powered Processing</p>
                  <p className="text-sm text-blue-700 mt-1">
                    Paste your research, documentation, or any text. Our AI will automatically:
                  </p>
                  <ul className="text-sm text-blue-700 mt-2 space-y-1 ml-4 list-disc">
                    <li>Break it into digestible knowledge chunks</li>
                    <li>Generate clear titles for each piece</li>
                    <li>Categorize the information</li>
                    <li>Format it for the assistant to use effectively</li>
                  </ul>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">
                Source Title (optional)
              </label>
              <input
                type="text"
                value={sourceTitle}
                onChange={(e) => setSourceTitle(e.target.value)}
                placeholder="e.g., Cork County Council Guidelines 2024, Developer Handbook, etc."
                className="w-full px-4 py-2.5 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">
                Default Category
              </label>
              <select
                value={defaultCategory}
                onChange={(e) => setDefaultCategory(e.target.value)}
                className="w-full px-4 py-2.5 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none"
              >
                {CATEGORIES.map(cat => (
                  <option key={cat.value} value={cat.value}>{cat.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">
                Content to Process
              </label>
              <textarea
                value={rawContent}
                onChange={(e) => setRawContent(e.target.value)}
                rows={12}
                placeholder={`Paste your research, documentation, or any information here...

Example:
"The property market in Cork has seen significant growth in 2024, with average house prices increasing by 8.2% year-over-year. New developments in the suburbs are particularly popular with first-time buyers.

For warranty claims, homeowners should contact the developer within 30 days of discovering any defect. The standard warranty period is 2 years from the handover date, with structural warranties extending to 10 years.

The local council provides weekly bin collection services. Green bins are collected on Mondays, black bins on Thursdays. Recycling centers are located at..."`}
                className="w-full px-4 py-3 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none resize-none font-mono"
              />
              <p className="text-xs text-neutral-500 mt-1">
                {rawContent.length.toLocaleString()} characters
              </p>
            </div>

            <div className="flex justify-end">
              <button
                onClick={processContent}
                disabled={processing || !rawContent.trim()}
                className="px-6 py-2.5 bg-brand-500 text-white rounded-lg font-medium hover:bg-brand-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
              >
                {processing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Processing with AI...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Process Content
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Review Chunks */}
        {step === 'review' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-neutral-900">Review Knowledge Chunks</h4>
                <p className="text-sm text-neutral-500">
                  {chunks.length} chunks extracted • {selectedCount} selected for import
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => toggleAll(true)}
                  className="text-sm text-brand-600 hover:text-brand-700"
                >
                  Select all
                </button>
                <span className="text-neutral-300">|</span>
                <button
                  onClick={() => toggleAll(false)}
                  className="text-sm text-neutral-500 hover:text-neutral-700"
                >
                  Deselect all
                </button>
              </div>
            </div>

            <div className="space-y-3 max-h-[500px] overflow-y-auto">
              {chunks.map((chunk) => {
                const isExpanded = expandedChunks.has(chunk.id);
                return (
                  <div 
                    key={chunk.id} 
                    className={`border rounded-lg transition-colors ${
                      chunk.selected 
                        ? 'border-brand-300 bg-brand-50/30' 
                        : 'border-neutral-200 bg-neutral-50/50'
                    }`}
                  >
                    <div className="p-4">
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          checked={chunk.selected}
                          onChange={() => toggleChunk(chunk.id)}
                          className="mt-1 w-4 h-4 text-brand-500 rounded border-neutral-300 focus:ring-brand-500"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => toggleExpanded(chunk.id)}
                              className="p-0.5 text-neutral-400 hover:text-neutral-600"
                            >
                              {isExpanded ? (
                                <ChevronDown className="w-4 h-4" />
                              ) : (
                                <ChevronRight className="w-4 h-4" />
                              )}
                            </button>
                            <input
                              type="text"
                              value={chunk.title}
                              onChange={(e) => updateChunk(chunk.id, 'title', e.target.value)}
                              className="flex-1 font-medium text-neutral-900 bg-transparent border-none p-0 focus:ring-0 focus:outline-none"
                            />
                            <select
                              value={chunk.category}
                              onChange={(e) => updateChunk(chunk.id, 'category', e.target.value)}
                              className="text-xs px-2 py-1 bg-white border border-neutral-200 rounded text-neutral-600"
                            >
                              {CATEGORIES.map(cat => (
                                <option key={cat.value} value={cat.value}>{cat.label}</option>
                              ))}
                            </select>
                            <button
                              onClick={() => deleteChunk(chunk.id)}
                              className="p-1 text-neutral-400 hover:text-red-500 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                          
                          {!isExpanded && (
                            <p className="text-sm text-neutral-600 mt-1 line-clamp-2 pl-6">
                              {chunk.content}
                            </p>
                          )}
                        </div>
                      </div>

                      {isExpanded && (
                        <div className="mt-3 pl-9">
                          <textarea
                            value={chunk.content}
                            onChange={(e) => updateChunk(chunk.id, 'content', e.target.value)}
                            rows={4}
                            className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-lg focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none resize-none"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-between pt-4 border-t border-neutral-200">
              <button
                onClick={() => setStep('input')}
                className="px-4 py-2 border border-neutral-200 text-neutral-700 rounded-lg text-sm font-medium hover:bg-neutral-50 transition-colors"
              >
                Back to Edit
              </button>
              <button
                onClick={importChunks}
                disabled={selectedCount === 0}
                className="px-6 py-2.5 bg-brand-500 text-white rounded-lg font-medium hover:bg-brand-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Import {selectedCount} Chunk{selectedCount !== 1 ? 's' : ''}
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Importing */}
        {step === 'importing' && (
          <div className="text-center py-12">
            <Loader2 className="w-12 h-12 text-brand-500 animate-spin mx-auto mb-4" />
            <p className="text-lg font-medium text-neutral-900">Importing Knowledge...</p>
            <p className="text-sm text-neutral-500 mt-1">Adding to the assistant's knowledge base</p>
          </div>
        )}

        {/* Step 4: Complete */}
        {step === 'complete' && importResult && (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-emerald-600" />
            </div>
            <h3 className="text-lg font-semibold text-neutral-900">Import Complete!</h3>
            <p className="text-neutral-500 mt-1">
              Successfully imported {importResult.success} knowledge chunk{importResult.success !== 1 ? 's' : ''}
              {importResult.failed > 0 && ` (${importResult.failed} failed)`}
            </p>

            <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg text-left">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="font-medium text-blue-900">Knowledge is now active</p>
                  <p className="text-sm text-blue-700 mt-1">
                    The assistant can now use this information when answering questions. 
                    Test it in the "Test Assistant" tab to see how it responds.
                  </p>
                </div>
              </div>
            </div>

            <button
              onClick={reset}
              className="mt-6 px-6 py-2.5 bg-brand-500 text-white rounded-lg font-medium hover:bg-brand-600 transition-colors"
            >
              Import More Knowledge
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default BulkKnowledgeImport;
