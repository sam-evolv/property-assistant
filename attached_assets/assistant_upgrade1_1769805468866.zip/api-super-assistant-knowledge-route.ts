// /api/super/assistant/knowledge/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

// GET - List knowledge base items
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const developmentId = searchParams.get('development_id');
  const includePlatformWide = searchParams.get('include_platform') !== 'false';

  try {
    let query = supabaseAdmin
      .from('knowledge_base')
      .select('*')
      .eq('active', true)
      .order('created_at', { ascending: false });

    if (developmentId) {
      // Get development-specific AND platform-wide knowledge
      if (includePlatformWide) {
        query = query.or(`development_id.eq.${developmentId},development_id.is.null`);
      } else {
        query = query.eq('development_id', developmentId);
      }
    } else {
      // Only platform-wide knowledge
      query = query.is('development_id', null);
    }

    const { data, error } = await query;

    if (error) throw error;

    return NextResponse.json({ items: data || [] });
  } catch (err) {
    console.error('Error fetching knowledge base:', err);
    return NextResponse.json({ error: 'Failed to fetch knowledge base' }, { status: 500 });
  }
}

// POST - Create new knowledge entry
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      development_id, 
      title, 
      content, 
      category,
      type,
      source,
      is_platform_wide 
    } = body;

    if (!title || !content) {
      return NextResponse.json(
        { error: 'title and content are required' }, 
        { status: 400 }
      );
    }

    // If platform-wide, don't set development_id
    const finalDevelopmentId = is_platform_wide ? null : development_id;

    const { data, error } = await supabaseAdmin
      .from('knowledge_base')
      .insert({
        development_id: finalDevelopmentId,
        title,
        content,
        category: category || 'general',
        type: type || 'manual',
        source_url: source || null,
        active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json({ item: data }, { status: 201 });
  } catch (err) {
    console.error('Error creating knowledge entry:', err);
    return NextResponse.json({ error: 'Failed to create knowledge entry' }, { status: 500 });
  }
}

// DELETE - Remove knowledge entry
export async function DELETE(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');

  if (!id) {
    return NextResponse.json({ error: 'id is required' }, { status: 400 });
  }

  try {
    const { error } = await supabaseAdmin
      .from('knowledge_base')
      .update({ active: false, updated_at: new Date().toISOString() })
      .eq('id', id);

    if (error) throw error;

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error('Error deleting knowledge entry:', err);
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 });
  }
}
