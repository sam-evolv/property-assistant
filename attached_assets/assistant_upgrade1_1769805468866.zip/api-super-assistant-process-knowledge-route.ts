// /api/super/assistant/process-knowledge/route.ts
import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { content, source_title, default_category, scope, development_id } = body;

    if (!content || content.trim().length < 50) {
      return NextResponse.json(
        { error: 'Content must be at least 50 characters' }, 
        { status: 400 }
      );
    }

    // Use GPT to intelligently chunk and categorize the content
    const systemPrompt = `You are a knowledge extraction assistant. Your job is to take raw text content and break it into discrete, useful knowledge chunks that can be used by an AI assistant to answer homeowner questions.

For each chunk, you should:
1. Create a clear, descriptive title (max 100 chars)
2. Extract the relevant content (clean it up, remove redundancy, keep it factual)
3. Assign an appropriate category

Available categories:
- general: General information
- warranty: Warranty & defects information
- maintenance: Maintenance tips and procedures
- facilities: Facilities & amenities info
- management: Management company details
- legal: Legal & compliance information
- local_area: Local area information (shops, schools, transport, etc.)
- market: Property market information
- energy: Energy efficiency, BER, sustainability
- insurance: Insurance information

Guidelines:
- Each chunk should be self-contained and answer a potential question
- Keep chunks between 50-500 words - not too short, not too long
- Remove any sensitive personal information
- Focus on factual, helpful information
- If content includes contact details, preserve them
- If content includes dates/timelines, preserve them
- Group related information together

Respond with a JSON array of chunks in this exact format:
{
  "chunks": [
    {
      "title": "Clear descriptive title",
      "content": "The extracted knowledge content...",
      "category": "category_value"
    }
  ]
}

Only respond with valid JSON, no other text.`;

    const userPrompt = `Source: ${source_title || 'Unknown source'}
Default category if unclear: ${default_category || 'general'}
Scope: ${scope === 'platform' ? 'Platform-wide (applies to all developments)' : 'Development-specific'}

Content to process:
---
${content}
---

Extract knowledge chunks from this content.`;

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      max_tokens: 4096,
      temperature: 0.3, // Lower temperature for more consistent extraction
      response_format: { type: 'json_object' }
    });

    const responseText = response.choices[0]?.message?.content || '{"chunks": []}';
    
    let parsed;
    try {
      parsed = JSON.parse(responseText);
    } catch (parseError) {
      console.error('Failed to parse AI response:', responseText);
      // Fallback: create a single chunk with the original content
      parsed = {
        chunks: [{
          title: source_title || 'Imported Knowledge',
          content: content.substring(0, 2000),
          category: default_category || 'general'
        }]
      };
    }

    // Validate and clean chunks
    const validatedChunks = (parsed.chunks || [])
      .filter((chunk: any) => chunk.title && chunk.content)
      .map((chunk: any) => ({
        title: String(chunk.title).substring(0, 255),
        content: String(chunk.content),
        category: chunk.category || default_category || 'general'
      }));

    return NextResponse.json({ 
      chunks: validatedChunks,
      source: source_title,
      total_extracted: validatedChunks.length
    });

  } catch (err) {
    console.error('Error processing knowledge:', err);
    return NextResponse.json(
      { error: 'Failed to process content' }, 
      { status: 500 }
    );
  }
}
