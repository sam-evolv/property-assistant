import { useState } from "react";
import {
  Home, Building2, Users, Wrench, Shield, ChevronRight, CheckCircle2,
  AlertCircle, Layout, Clock, Star, Settings, MessageSquare, Calendar,
  FileText, Bell, BookOpen, MapPin, Plus, ArrowLeft, Edit, Phone,
  Droplets, Flame, HelpCircle, AlertTriangle, Camera, MoreHorizontal,
  Download, TrendingUp, DollarSign, UserPlus, UserMinus, Dumbbell,
  Sun, BatteryCharging, Bike, Send, Zap
} from "lucide-react";

const G = "#D4AF37";
const GL = "#FEFCE8";
const BD = "#e5e7eb";

const UNITS = [
  { id:"1", a:"Apt 1, Block A", s:"occupied", t:"Sarah Murphy", r:1850, m:0 },
  { id:"2", a:"Apt 2, Block A", s:"occupied", t:"James O'Brien", r:1950, m:1 },
  { id:"3", a:"Apt 3, Block A", s:"void", t:null, r:1900, m:0 },
  { id:"4", a:"Apt 4, Block A", s:"occupied", t:"Emma Walsh", r:2100, m:0 },
  { id:"5", a:"Apt 5, Block A", s:"maintenance", t:"Liam Kelly", r:1850, m:2 },
  { id:"6", a:"Apt 6, Block A", s:"occupied", t:"Aoife Byrne", r:2200, m:0 },
  { id:"7", a:"Apt 7, Block B", s:"occupied", t:"Cian Daly", r:1750, m:1 },
  { id:"8", a:"Apt 8, Block B", s:"vacant", t:null, r:1900, m:0 },
  { id:"9", a:"Apt 9, Block B", s:"occupied", t:"Niamh Flynn", r:2050, m:0 },
  { id:"10", a:"Apt 10, Block B", s:"occupied", t:"Sean Connolly", r:1950, m:0 },
  { id:"11", a:"Apt 11, Block B", s:"occupied", t:"Roisin Doyle", r:2100, m:1 },
  { id:"12", a:"Apt 12, Block B", s:"occupied", t:"Padraig Nolan", r:1800, m:0 },
];

const MT = [
  { id:"m1", u:"Apt 2, Block A", t:"James O'Brien", ti:"Shower draining slowly", c:"plumbing", p:"routine", st:"assigned", v:"Cork Plumbing" },
  { id:"m2", u:"Apt 5, Block A", t:"Liam Kelly", ti:"Heating not reaching temp", c:"heating", p:"urgent", st:"in_progress", v:"Thermal Solutions" },
  { id:"m3", u:"Apt 5, Block A", t:"Liam Kelly", ti:"Extractor fan rattling", c:"appliance", p:"low", st:"submitted", v:null },
  { id:"m4", u:"Apt 7, Block B", t:"Cian Daly", ti:"Door lock sticking", c:"general", p:"routine", st:"scheduled", v:"Secure Locks" },
  { id:"m5", u:"Apt 11, Block B", t:"Roisin Doyle", ti:"Ceiling damp patch", c:"plumbing", p:"urgent", st:"acknowledged", v:null },
];

const CP = [
  { id:"c1", ti:"Fire Safety Inspection", d:"2026-02-15", s:"due_soon", sc:"Building", pr:"FireSafe Ireland" },
  { id:"c2", ti:"Gas Safety Certificate", d:"2026-01-20", s:"overdue", sc:"All units", pr:"Bord Gais" },
  { id:"c3", ti:"BER Cert Renewal", d:"2026-06-30", s:"upcoming", sc:"Building", pr:"Energy Rating" },
  { id:"c4", ti:"Smoke/CO Detectors", d:"2026-03-01", s:"due_soon", sc:"All units", pr:"In-house" },
  { id:"c5", ti:"Electrical (RECI)", d:"2026-08-15", s:"upcoming", sc:"Building", pr:"RECI Certified" },
  { id:"c6", ti:"Insurance Renewal", d:"2026-01-01", s:"completed", sc:"Building", pr:"Zurich" },
  { id:"c7", ti:"RTB Registration Q1", d:"2026-02-28", s:"due_soon", sc:"New tenancies", pr:"RTB.ie" },
];

const AM = [
  { id:"a1", n:"Residents Gym", ty:"gym", bk:24, cp:15 },
  { id:"a2", n:"Meeting Room", ty:"meeting", bk:8, cp:8 },
  { id:"a3", n:"Rooftop Terrace", ty:"roof", bk:12, cp:30 },
  { id:"a4", n:"EV Charging", ty:"ev", bk:18, cp:1 },
  { id:"a5", n:"Bike Storage", ty:"bike", bk:0, cp:24 },
];

const SC = {
  occupied:{ bg:"#ECFDF5", c:"#059669", b:"#A7F3D0", d:"#10B981" },
  vacant:{ bg:"#F9FAFB", c:"#6B7280", b:"#D1D5DB", d:"#9CA3AF" },
  void:{ bg:"#FFFBEB", c:"#D97706", b:"#FDE68A", d:"#F59E0B" },
  maintenance:{ bg:"#FEF2F2", c:"#DC2626", b:"#FECACA", d:"#EF4444" }
};
const PC = {
  emergency:{ bg:"#FEF2F2", c:"#DC2626" },
  urgent:{ bg:"#FFFBEB", c:"#D97706" },
  routine:{ bg:"#EFF6FF", c:"#2563EB" },
  low:{ bg:"#F9FAFB", c:"#6B7280" }
};
const CC = {
  overdue:{ bg:"#FEF2F2", c:"#DC2626", I:AlertCircle },
  due_soon:{ bg:"#FFFBEB", c:"#D97706", I:Clock },
  upcoming:{ bg:"#EFF6FF", c:"#2563EB", I:Calendar },
  completed:{ bg:"#ECFDF5", c:"#059669", I:CheckCircle2 }
};
const AI = { gym:Dumbbell, meeting:Users, roof:Sun, ev:BatteryCharging, bike:Bike };
const CI = { plumbing:Droplets, heating:Flame, appliance:Settings, general:Wrench };
const MSC = { submitted:"#6B7280", acknowledged:"#3B82F6", assigned:"#8B5CF6", in_progress:"#F59E0B", scheduled:"#06B6D4" };

function B({ children, bg, c }) {
  return <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-semibold rounded-full" style={{ backgroundColor:bg, color:c }}>{children}</span>;
}

function St({ icon:I, label, value, sub }) {
  return (
    <div className="bg-white rounded-xl p-4 border" style={{ borderColor:BD }}>
      <div className="w-8 h-8 rounded-lg flex items-center justify-center mb-2" style={{ backgroundColor:GL }}>
        <I className="w-4 h-4" style={{ color:G }} />
      </div>
      <div className="text-2xl font-bold text-gray-900">{value}</div>
      <div className="text-xs text-gray-500">{label}</div>
      {sub && <div className="text-xs text-gray-400">{sub}</div>}
    </div>
  );
}

function Overview() {
  const occ = UNITS.filter(u => u.s === "occupied").length;
  const rr = UNITS.filter(u => u.s === "occupied").reduce((x, u) => x + u.r, 0);
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <St icon={Home} label="Occupancy" value={Math.round(occ/UNITS.length*100)+"%"} sub={occ+" of "+UNITS.length} />
        <St icon={DollarSign} label="Rent Roll" value={"€"+rr.toLocaleString()} sub="Monthly" />
        <St icon={Wrench} label="Open Maint." value={MT.length} sub={MT.filter(m=>m.p==="urgent").length+" urgent"} />
        <St icon={Shield} label="Compliance" value={CP.filter(c=>c.s==="overdue"||c.s==="due_soon").length} sub={CP.filter(c=>c.s==="overdue").length+" overdue"} />
      </div>
      <div>
        <h3 className="font-bold text-gray-900 mb-3" style={{ fontFamily:"Georgia,serif" }}>Units at a Glance</h3>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
          {UNITS.map(u => {
            const s = SC[u.s];
            return (
              <div key={u.id} className="p-3 rounded-xl border hover:shadow-md transition-shadow cursor-pointer" style={{ backgroundColor:s.bg, borderColor:s.b }}>
                <div className="flex items-center gap-1 mb-1">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor:s.d }} />
                  <span className="text-xs font-bold" style={{ color:s.c }}>{u.s}</span>
                </div>
                <div className="text-sm font-semibold text-gray-900 truncate">{u.a}</div>
                <div className="text-xs text-gray-500 truncate">{u.t||"Available"}</div>
                {u.m > 0 && <div className="text-xs text-amber-600 mt-1 flex items-center gap-1"><Wrench className="w-3 h-3"/>{u.m} open</div>}
              </div>
            );
          })}
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl p-4 border" style={{ borderColor:BD }}>
          <h4 className="font-bold text-sm mb-3">Recent Maintenance</h4>
          {MT.slice(0,3).map(m => {
            const p = PC[m.p]; const Ic = CI[m.c]||Wrench;
            return (
              <div key={m.id} className="flex items-center gap-3 p-2 rounded-lg bg-gray-50 mb-2">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor:p.bg }}><Ic className="w-3.5 h-3.5" style={{ color:p.c }}/></div>
                <div className="flex-1 min-w-0"><div className="text-sm font-medium truncate">{m.ti}</div><div className="text-xs text-gray-500">{m.u}</div></div>
                <B bg={p.bg} c={p.c}>{m.p}</B>
              </div>
            );
          })}
        </div>
        <div className="bg-white rounded-xl p-4 border" style={{ borderColor:BD }}>
          <h4 className="font-bold text-sm mb-3">Compliance Alerts</h4>
          {CP.filter(c => c.s==="overdue"||c.s==="due_soon").map(c => {
            const x = CC[c.s]; const Ic = x.I;
            return (
              <div key={c.id} className="flex items-center gap-3 p-2 rounded-lg mb-2" style={{ backgroundColor:x.bg }}>
                <Ic className="w-4 h-4" style={{ color:x.c }}/>
                <div className="flex-1 min-w-0"><div className="text-sm font-medium truncate">{c.ti}</div><div className="text-xs" style={{ color:x.c }}>Due: {new Date(c.d).toLocaleDateString("en-IE",{day:"numeric",month:"short"})}</div></div>
                <B bg={x.bg} c={x.c}>{c.s==="overdue"?"Overdue":"Due Soon"}</B>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function UnitsView() {
  const [sel, setSel] = useState(null);
  if (sel) {
    const u = UNITS.find(x => x.id===sel);
    const um = MT.filter(m => m.u===u.a);
    const s = SC[u.s];
    return (
      <div className="space-y-4">
        <button onClick={()=>setSel(null)} className="text-sm text-gray-500 flex items-center gap-1 hover:text-gray-900"><ArrowLeft className="w-4 h-4"/>Back</button>
        <div className="bg-white rounded-xl border overflow-hidden" style={{ borderColor:BD }}>
          <div className="p-5 border-b" style={{ borderColor:BD }}>
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold">{u.a}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <B bg={s.bg} c={s.c}><div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor:s.d }}/>{u.s}</B>
                  <span className="text-sm text-gray-500">€{u.r}/mo</span>
                </div>
              </div>
              {u.s==="occupied" && <button className="px-3 py-1.5 text-xs font-medium rounded-lg text-red-600 bg-red-50 border border-red-200 flex items-center gap-1"><UserMinus className="w-3.5 h-3.5"/>End Tenancy</button>}
              {(u.s==="vacant"||u.s==="void") && <button className="px-3 py-1.5 text-xs font-medium text-white rounded-lg flex items-center gap-1" style={{ backgroundColor:G }}><UserPlus className="w-3.5 h-3.5"/>New Tenancy</button>}
            </div>
          </div>
          {u.t && (
            <div className="p-5 bg-gray-50 border-b" style={{ borderColor:BD }}>
              <h4 className="text-xs font-semibold text-gray-400 uppercase mb-3">Current Tenant</h4>
              <div className="grid grid-cols-3 gap-4">
                <div><div className="text-xs text-gray-500">Name</div><div className="text-sm font-medium">{u.t}</div></div>
                <div><div className="text-xs text-gray-500">Rent</div><div className="text-sm font-medium">€{u.r}</div></div>
                <div><div className="text-xs text-gray-500">Status</div><div className="text-sm font-medium">Active</div></div>
              </div>
            </div>
          )}
          {um.length>0 && (
            <div className="p-5">
              <h4 className="text-xs font-semibold text-gray-400 uppercase mb-3">Maintenance</h4>
              {um.map(m => { const p=PC[m.p]; const Ic=CI[m.c]||Wrench; return (
                <div key={m.id} className="flex items-center gap-3 p-2 rounded-lg border border-gray-100 mb-2">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor:p.bg }}><Ic className="w-3.5 h-3.5" style={{ color:p.c }}/></div>
                  <div className="flex-1"><div className="text-sm font-medium">{m.ti}</div><div className="text-xs text-gray-500">{m.v||"Unassigned"}</div></div>
                  <B bg={p.bg} c={p.c}>{m.st.replace("_"," ")}</B>
                </div>
              );})}
            </div>
          )}
        </div>
      </div>
    );
  }
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border overflow-hidden" style={{ borderColor:BD }}>
        <table className="w-full">
          <thead><tr className="border-b" style={{ borderColor:BD }}>{["Unit","Status","Tenant","Rent","Maint.",""].map(h=><th key={h} className="text-left text-xs font-semibold text-gray-400 uppercase px-4 py-3">{h}</th>)}</tr></thead>
          <tbody>{UNITS.map(u => { const s=SC[u.s]; return (
            <tr key={u.id} onClick={()=>setSel(u.id)} className="border-b last:border-b-0 hover:bg-gray-50 cursor-pointer" style={{ borderColor:BD }}>
              <td className="px-4 py-3 text-sm font-medium">{u.a}</td>
              <td className="px-4 py-3"><B bg={s.bg} c={s.c}><div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor:s.d }}/>{u.s}</B></td>
              <td className="px-4 py-3 text-sm text-gray-600">{u.t||"—"}</td>
              <td className="px-4 py-3 text-sm font-medium">€{u.r}</td>
              <td className="px-4 py-3">{u.m>0?<span className="text-xs text-amber-600 font-medium">{u.m}</span>:<span className="text-gray-300">—</span>}</td>
              <td className="px-4 py-3"><ChevronRight className="w-4 h-4 text-gray-300"/></td>
            </tr>
          );})}</tbody>
        </table>
      </div>
    </div>
  );
}

function MaintView() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <St icon={Wrench} label="Open" value={MT.length}/><St icon={Clock} label="Avg Resolution" value="3.2d"/><St icon={AlertCircle} label="Urgent" value={MT.filter(m=>m.p==="urgent").length}/><St icon={Star} label="Rating" value="4.6"/>
      </div>
      <div className="bg-white rounded-xl border" style={{ borderColor:BD }}>
        {MT.map((m,i) => { const p=PC[m.p]; const Ic=CI[m.c]||Wrench; const sc=MSC[m.st]||"#6B7280"; return (
          <div key={m.id} className={"flex items-center gap-4 p-4 hover:bg-gray-50 cursor-pointer"+(i<MT.length-1?" border-b":"")} style={{ borderColor:BD }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor:p.bg }}><Ic className="w-4 h-4" style={{ color:p.c }}/></div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2"><span className="text-sm font-semibold">{m.ti}</span><B bg={p.bg} c={p.c}>{m.p}</B></div>
              <div className="text-xs text-gray-500 mt-0.5">{m.u} · {m.t}</div>
            </div>
            <div className="flex items-center gap-3">
              {m.v && <span className="text-xs text-gray-500 hidden md:block">{m.v}</span>}
              <span className="px-2 py-1 rounded-full text-xs font-medium" style={{ backgroundColor:sc+"18", color:sc }}>{m.st.replace("_"," ")}</span>
            </div>
          </div>
        );})}
      </div>
    </div>
  );
}

function CompView() {
  const groups = ["overdue","due_soon","upcoming","completed"];
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {groups.map(s => { const x=CC[s]; const Ic=x.I; const ct=CP.filter(c=>c.s===s).length; return <St key={s} icon={Ic} label={s==="due_soon"?"Due Soon":s.charAt(0).toUpperCase()+s.slice(1)} value={ct}/>; })}
      </div>
      {groups.filter(s=>CP.some(c=>c.s===s)).map(status => {
        const x=CC[status]; const Ic=x.I; const items=CP.filter(c=>c.s===status);
        return (
          <div key={status}>
            <div className="flex items-center gap-2 mb-2"><Ic className="w-4 h-4" style={{ color:x.c }}/><span className="text-sm font-bold" style={{ color:x.c }}>{status==="due_soon"?"Due Soon":status.charAt(0).toUpperCase()+status.slice(1)} ({items.length})</span></div>
            {items.map(c => (
              <div key={c.id} className="flex items-center gap-4 p-4 bg-white rounded-xl border mb-2 hover:shadow-md transition-shadow cursor-pointer" style={{ borderColor:x.c+"40", borderLeftWidth:3, borderLeftColor:x.c }}>
                <div className="flex-1"><div className="text-sm font-semibold">{c.ti}</div><div className="text-xs text-gray-500">{c.sc} · {c.pr}</div></div>
                <div className="text-sm font-medium text-gray-900">{new Date(c.d).toLocaleDateString("en-IE",{day:"numeric",month:"short",year:"numeric"})}</div>
                {status!=="completed" ? <button className="px-2 py-1 text-xs font-medium rounded-lg" style={{ color:x.c, backgroundColor:x.bg }}>{status==="overdue"?"Resolve":"View"}</button> : <CheckCircle2 className="w-5 h-5 text-emerald-500"/>}
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
}

function AmenView() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
      {AM.map(a => { const Ic=AI[a.ty]||MoreHorizontal; return (
        <div key={a.id} className="bg-white rounded-xl p-4 border hover:shadow-md transition-shadow cursor-pointer" style={{ borderColor:BD }}>
          <div className="flex justify-between mb-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor:GL }}><Ic className="w-5 h-5" style={{ color:G }}/></div>
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400"/>
          </div>
          <h4 className="font-bold text-sm">{a.n}</h4>
          <div className="text-xs text-gray-500 mt-1 flex items-center gap-3">
            <span>{a.bk} bookings/mo</span>
            {a.cp>1 && <span>Cap: {a.cp}</span>}
          </div>
          <div className="mt-3 pt-3 border-t flex justify-between items-center" style={{ borderColor:BD }}>
            <span className="text-xs text-gray-400">06:00 — 22:00</span>
            <button className="text-xs font-medium px-2 py-1 rounded-md" style={{ color:G, backgroundColor:GL }}>Manage</button>
          </div>
        </div>
      );})}
    </div>
  );
}

function WelView() {
  const seq = [
    { d:1, ti:"Welcome to your new home!", cat:"essentials", msg:"Wi-Fi, bins, parking, emergency contacts." },
    { d:2, ti:"Your appliances", cat:"appliances", msg:"Guides for heating, oven, dishwasher, washing machine." },
    { d:3, ti:"Local area", cat:"local", msg:"Shops, GP, pharmacy, restaurants, transport." },
    { d:5, ti:"Building amenities", cat:"community", msg:"Gym, meeting room, rooftop — how to book." },
    { d:7, ti:"AI assistant", cat:"general", msg:"I'm here 24/7. Ask me anything about your home!" },
  ];
  const cc = { essentials:"#2563EB", appliances:"#7C3AED", local:"#059669", community:"#D97706", general:G };
  return (
    <div className="bg-white rounded-xl border overflow-hidden" style={{ borderColor:BD }}>
      <div className="p-4 bg-gray-50 border-b flex items-center gap-2" style={{ borderColor:BD }}><Bell className="w-4 h-4" style={{ color:G }}/><span className="text-sm text-gray-600">Auto-sent based on move-in date</span></div>
      <div className="p-4 relative">
        <div className="absolute left-[29px] top-6 bottom-6 w-0.5 bg-gray-200"/>
        {seq.map((s,i) => (
          <div key={i} className="flex gap-4 mb-4 relative">
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-white border-2 flex-shrink-0 z-10 text-sm font-bold" style={{ borderColor:G, color:G }}>D{s.d}</div>
            <div className="flex-1 bg-gray-50 border border-gray-100 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-bold">{s.ti}</span>
                <span className="px-2 py-0.5 rounded-full text-xs font-medium text-white" style={{ backgroundColor:cc[s.cat] }}>{s.cat}</span>
              </div>
              <p className="text-sm text-gray-600">{s.msg}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AppPreview() {
  const [scr, setScr] = useState("home");
  return (
    <div className="flex justify-center">
      <div className="w-[340px] rounded-[28px] border-[5px] border-gray-900 bg-white shadow-2xl overflow-hidden" style={{ height:680 }}>
        <div className="bg-gray-900 text-white px-5 py-1.5 flex justify-between text-xs"><span>9:41</span><span>···</span></div>
        <div className="px-4 py-2.5 flex items-center justify-between border-b" style={{ borderColor:BD }}>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ backgroundColor:G }}><Home className="w-3.5 h-3.5 text-white"/></div>
            <div><div className="text-xs font-bold">Harbour View</div><div className="text-xs text-gray-500">Apt 4, Block A</div></div>
          </div>
          <Bell className="w-4 h-4 text-gray-400"/>
        </div>
        <div style={{ height:510 }} className="overflow-y-auto">
          {scr==="home" && (
            <div className="p-3 space-y-3">
              <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-3 text-white">
                <div className="flex items-center gap-1.5 mb-2"><MessageSquare className="w-3.5 h-3.5" style={{ color:G }}/><span className="text-xs text-gray-300">AI Assistant</span></div>
                <div className="bg-white/10 rounded-lg p-2 mb-1.5"><p className="text-xs text-gray-200">"How do I reset my heating timer?"</p></div>
                <div className="bg-white/5 rounded-lg p-2">
                  <p className="text-xs text-gray-300">Press and hold TIMER on your Daikin remote for 3 seconds until the display flashes...</p>
                  <div className="mt-1.5 pt-1.5 border-t border-white/10"><button className="text-xs flex items-center gap-1" style={{ color:G }}><Wrench className="w-3 h-3"/>Submit a request</button></div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={()=>setScr("maint")} className="bg-white border rounded-xl p-2.5 text-left" style={{ borderColor:BD }}><Wrench className="w-4 h-4 mb-1.5" style={{ color:G }}/><div className="text-xs font-bold">Report Issue</div></button>
                <button onClick={()=>setScr("book")} className="bg-white border rounded-xl p-2.5 text-left" style={{ borderColor:BD }}><Calendar className="w-4 h-4 mb-1.5" style={{ color:G }}/><div className="text-xs font-bold">Book Amenity</div></button>
              </div>
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-2.5">
                <div className="flex items-center gap-1 mb-0.5"><AlertTriangle className="w-3 h-3 text-amber-500"/><span className="text-xs font-bold text-amber-700">Planned Maintenance</span></div>
                <p className="text-xs text-amber-600">Water off Block A, Thu 8 Feb, 10am-2pm.</p>
              </div>
            </div>
          )}
          {scr==="maint" && (
            <div className="p-3 space-y-2.5">
              <button onClick={()=>setScr("home")} className="text-xs text-gray-500 flex items-center gap-1"><ArrowLeft className="w-3 h-3"/>Back</button>
              <h3 className="text-sm font-bold">Report an Issue</h3>
              <input className="w-full px-2.5 py-2 text-xs border rounded-xl" style={{ borderColor:BD }} placeholder="What's the problem?"/>
              <div className="grid grid-cols-3 gap-1.5">
                {[["Plumbing",Droplets],["Electrical",Zap],["Heating",Flame],["Appliance",Settings],["Structural",Building2],["General",HelpCircle]].map(([l,I])=>(
                  <button key={l} className="flex flex-col items-center gap-1 p-2 rounded-xl border" style={l==="Plumbing"?{borderColor:G,backgroundColor:GL}:{borderColor:BD}}>
                    <I className="w-3.5 h-3.5" style={{ color:l==="Plumbing"?G:"#9CA3AF" }}/><span className="text-xs">{l}</span>
                  </button>
                ))}
              </div>
              <textarea className="w-full px-2.5 py-2 text-xs border rounded-xl resize-none" style={{ borderColor:BD }} rows={2} placeholder="Describe..."/>
              <button className="w-16 h-14 rounded-xl border-2 border-dashed flex flex-col items-center justify-center" style={{ borderColor:BD }}><Camera className="w-4 h-4 text-gray-400"/><span className="text-xs text-gray-400">Photo</span></button>
              <button className="w-full py-2.5 text-xs font-semibold text-white rounded-xl" style={{ backgroundColor:G }}>Submit Request</button>
            </div>
          )}
          {scr==="book" && (
            <div className="p-3 space-y-2">
              <button onClick={()=>setScr("home")} className="text-xs text-gray-500 flex items-center gap-1"><ArrowLeft className="w-3 h-3"/>Back</button>
              <h3 className="text-sm font-bold">Book Amenity</h3>
              {AM.map(a => { const Ic=AI[a.ty]||MoreHorizontal; return (
                <button key={a.id} className="w-full flex items-center gap-2.5 p-2.5 bg-white border rounded-xl text-left" style={{ borderColor:BD }}>
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor:GL }}><Ic className="w-4 h-4" style={{ color:G }}/></div>
                  <div className="flex-1"><div className="text-xs font-bold">{a.n}</div><div className="text-xs text-gray-500">06:00—22:00</div></div>
                  <ChevronRight className="w-3.5 h-3.5 text-gray-300"/>
                </button>
              );})}
            </div>
          )}
          {scr==="docs" && (
            <div className="p-3 space-y-2">
              <button onClick={()=>setScr("home")} className="text-xs text-gray-500 flex items-center gap-1"><ArrowLeft className="w-3 h-3"/>Back</button>
              <h3 className="text-sm font-bold">Documents</h3>
              {[["Lease Agreement",FileText],["Condition Report",FileText],["Building Rules",BookOpen],["Emergency Contacts",Phone],["Appliance Manuals",Settings],["Area Guide",MapPin]].map(([n,I],i)=>(
                <button key={i} className="w-full flex items-center gap-2.5 p-2.5 bg-white border rounded-xl text-left" style={{ borderColor:BD }}>
                  <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center"><I className="w-3.5 h-3.5 text-gray-500"/></div>
                  <div className="flex-1 text-xs font-medium">{n}</div>
                  <Download className="w-3.5 h-3.5 text-gray-300"/>
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="h-[72px] border-t bg-white flex items-center px-3 justify-around" style={{ borderColor:BD }}>
          {[["home",Home,"Home"],["maint",Wrench,"Report"],["book",Calendar,"Book"],["docs",FileText,"Docs"]].map(([id,I,l])=>(
            <button key={id} onClick={()=>setScr(id)} className="flex flex-col items-center gap-0.5 px-2 py-1" style={{ color:scr===id?G:"#9CA3AF" }}>
              <I className="w-4.5 h-4.5"/><span className="text-xs font-medium">{l}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

const TABS = [
  { id:"overview", l:"Overview", I:Layout },
  { id:"units", l:"Units", I:Building2 },
  { id:"maint", l:"Maintenance", I:Wrench },
  { id:"comp", l:"Compliance", I:Shield },
  { id:"amen", l:"Amenities", I:Calendar },
  { id:"welcome", l:"Welcome", I:BookOpen },
  { id:"app", l:"Tenant App", I:Phone },
];

export default function BTRPlatform() {
  const [tab, setTab] = useState("overview");
  const [pt, setPt] = useState("btr");

  return (
    <div className="min-h-screen bg-gray-50" style={{ fontFamily:"system-ui,-apple-system,sans-serif" }}>
      <div className="bg-white border-b sticky top-0 z-50" style={{ borderColor:BD }}>
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor:G }}><Home className="w-4 h-4 text-white"/></div>
            <div><h1 className="text-sm font-bold">Harbour View Apartments</h1><p className="text-xs text-gray-500">Cork City · 12 Units</p></div>
          </div>
          <div className="flex bg-gray-100 rounded-lg p-0.5">
            {["bts","btr","mixed"].map(t=>(
              <button key={t} onClick={()=>setPt(t)} className="px-2 py-1 text-xs font-medium rounded-md transition-all" style={pt===t?{backgroundColor:G,color:"#fff"}:{color:"#6B7280"}}>{t.toUpperCase()}</button>
            ))}
          </div>
        </div>
        <div className="max-w-5xl mx-auto px-4">
          <div className="flex gap-0.5 overflow-x-auto -mb-px">
            {TABS.map(t=>(
              <button key={t.id} onClick={()=>setTab(t.id)} className="flex items-center gap-1 px-3 py-2 text-xs font-medium whitespace-nowrap border-b-2 transition-all" style={tab===t.id?{borderColor:G,color:"#111"}:{borderColor:"transparent",color:"#9CA3AF"}}>
                <t.I className="w-3.5 h-3.5"/>{t.l}
              </button>
            ))}
          </div>
        </div>
      </div>
      <div className="max-w-5xl mx-auto px-4 py-6">
        {pt==="bts" ? (
          <div className="text-center py-16">
            <Building2 className="w-12 h-12 text-gray-300 mx-auto mb-3"/>
            <h3 className="text-lg font-bold">Build-to-Sell Mode</h3>
            <p className="text-sm text-gray-500 mt-1 max-w-md mx-auto">Switch to BTR or Mixed to see tenancy management, maintenance, compliance, and amenities. Your BTS features remain unchanged.</p>
          </div>
        ) : (
          <>
            {tab==="overview" && <Overview/>}
            {tab==="units" && <UnitsView/>}
            {tab==="maint" && <MaintView/>}
            {tab==="comp" && <CompView/>}
            {tab==="amen" && <AmenView/>}
            {tab==="welcome" && <WelView/>}
            {tab==="app" && <AppPreview/>}
          </>
        )}
      </div>
    </div>
  );
}
