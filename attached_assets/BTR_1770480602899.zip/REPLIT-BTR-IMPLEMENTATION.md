# OpenHouse AI — BTR Platform Implementation

## Context

OpenHouse AI is a property developer platform built with React + TypeScript, Tailwind CSS, Supabase, and deployed on Vercel. It currently supports Build-to-Sell (BTS) developments. We are adding Build-to-Rent (BTR) support without breaking any existing functionality.

**Critical principle: One flag changes everything.** A single `project_type` field on the `projects` table (`'bts'`, `'btr'`, `'mixed'`) drives the entire platform behaviour. Every component checks this flag and renders accordingly.

## Files Provided

1. `001_btr_migration.sql` — Run this in Supabase SQL Editor FIRST. Creates all new tables.
2. `btr-types.ts` — TypeScript type definitions. Place in `src/types/btr.ts`
3. `openhouse-btr-platform-prototype.jsx` — Interactive visual reference showing every screen

## What to Build

### Phase 1: Database & Configuration (Run migration first)

The SQL migration creates:
- `project_type` column on `projects` table (bts/btr/mixed)
- `unit_status` and `current_tenancy_id` columns on `units` table
- `unit_mode` column on `units` table (sale/rent for mixed developments)
- `tenancies` table — tracks tenant occupancy per unit
- `maintenance_requests` table — full lifecycle from submission to resolution
- `compliance_schedule` table — statutory obligations with auto-recurrence
- `amenities` table — shared facilities configuration
- `amenity_bookings` table — booking management with conflict prevention
- `welcome_sequences` table — automated move-in drip campaign
- All RLS policies, indexes, and triggers

### Phase 2: Developer Dashboard — BTR Views

Add new navigation items that appear when `project_type` is `'btr'` or `'mixed'`. When `project_type` is `'bts'`, the existing dashboard remains completely unchanged.

#### 2a. Project Settings — Type Selector
- Add a select dropdown to the existing project settings form
- Options: Build-to-Sell, Build-to-Rent, Mixed
- Stored as `projects.project_type`
- When 'mixed' is selected, show additional UI to tag individual units as `sale` or `rent`

#### 2b. BTR Overview Dashboard
**Route:** `/developer/[developmentId]/overview` (or adapt to existing routing)

Shows:
- **Stats row:** Occupancy rate (%), Monthly rent roll (€), Open maintenance count, Compliance alerts count
- **Unit status grid:** Visual card per unit showing status (occupied/vacant/void/maintenance), tenant name, open maintenance count. Colour-coded: green=occupied, amber=void, red=maintenance, grey=vacant
- **Recent maintenance panel:** Latest 3-5 requests with priority badges
- **Compliance alerts panel:** Overdue and due-soon items with traffic light colours

Design: Follow OpenHouse design system exactly — gold (#D4AF37) accents, white cards with light borders, Source Serif 4 headings, Inter body text.

#### 2c. Unit Management Table
**Route:** `/developer/[developmentId]/units`

- Full table of all units with columns: Unit address, Status (badge), Tenant name, Rent, Move-in date, Maintenance count
- Filter buttons: All, Occupied, Vacant, Void, Maintenance
- Click unit → detail view with:
  - Unit info and status
  - Current tenant details (name, email, phone, lease dates, rent)
  - **"End Tenancy" button** (sets tenancy.move_out_date, revokes access code, sets unit to void)
  - **"New Tenancy" button** (creates tenancy record, generates access code, sets unit to occupied)
  - Maintenance history for this unit
  - Compliance items for this unit

#### 2d. Maintenance Dashboard
**Route:** `/developer/[developmentId]/maintenance`

- Stats: Open count, Avg resolution time, Urgent count, Satisfaction rating
- List of all requests sorted by priority then date
- Each row shows: Category icon, Title, Priority badge, Unit, Tenant, Status pill, Assigned vendor
- Click request → detail view where operator can:
  - Update status (submitted → acknowledged → assigned → in_progress → resolved → closed)
  - Assign vendor/contractor
  - Schedule date
  - Add resolution notes and cost
  - View photos submitted by tenant
  - View AI diagnosis (if available)

**Status colours:**
- submitted: grey
- acknowledged: blue
- assigned: purple
- in_progress: amber
- scheduled: cyan
- resolved: green
- closed: dark green

**Priority colours:**
- emergency: red
- urgent: amber
- routine: blue
- low: grey

#### 2e. Compliance Calendar
**Route:** `/developer/[developmentId]/compliance`

- Stats: Overdue, Due Soon, Upcoming, Completed
- Grouped sections by status with appropriate colours:
  - Overdue: red left border, red alert icon
  - Due Soon: amber left border, clock icon
  - Upcoming: blue left border, calendar icon
  - Completed: green checkmark
- Each item shows: Title, Scope (building-wide or unit-specific), Provider, Due date
- "Mark Complete" button sets completed_date and auto-triggers next recurrence (via database trigger)
- "Add Item" button with form: type (dropdown), title, description, due date, recurrence months, provider, scope

#### 2f. Amenities Manager
**Route:** `/developer/[developmentId]/amenities`

- Grid of amenity cards showing: Icon, Name, Booking count this month, Capacity, Availability status
- Click card → manage amenity settings: name, type, booking rules (max duration, advance days, active bookings), availability hours/days, capacity
- View bookings calendar showing upcoming bookings per amenity
- "Add Amenity" button with full configuration form

#### 2g. Welcome Sequence Editor
**Route:** `/developer/[developmentId]/welcome`

- Timeline view showing day-by-day sequence
- Each item: Day number, Title, Message, Category (essentials/appliances/local_area/community/general)
- Drag to reorder
- Edit inline or in modal
- Add new items
- Toggle items active/inactive

#### 2h. Communications Hub
**Route:** `/developer/[developmentId]/communications`

**Left panel — AI Query Analytics:**
- Top questions asked by tenants in last 30 days
- Grouped by question topic from messages table
- Trend indicator (rising/falling)
- Insight: "Rising questions may indicate knowledge gaps in property docs"

**Right panel — Send Announcement:**
- Category selector: General, Urgent, Maintenance, Community
- Recipient selector: All Tenants, Block A, Block B, Specific Unit
- Message text area
- Send button
- Uses existing noticeboard_posts table with new `category` and `priority` fields

### Phase 3: Tenant App — BTR Adaptations

The resident-facing app (PWA + iOS) needs role-based UI based on `project_type`.

#### 3a. AI Assistant — BTR System Prompt
When the development is BTR, use this system prompt template instead of the BTS one:

```
You are the AI property assistant for [DEVELOPMENT_NAME], a residential apartment building. You help tenants with practical questions about their home and building.

Key behaviours:
- Focus on practical how-to answers for appliances, heating, building systems
- When you detect a maintenance issue you can't solve, offer: "Would you like me to help you submit a maintenance request for this?"
- Never share information about other tenants, rent amounts, or confidential building data
- Be warm, helpful, and knowledgeable about the specific property
- Reference the building's amenities and community features when relevant
```

#### 3b. Maintenance Request Submission Screen
**New screen in tenant app:**
- Title input
- Category selector: 6 category buttons with icons (Plumbing, Electrical, Heating, Appliance, Structural, General)
- Description textarea
- Photo upload (camera or gallery, stored in Supabase storage `maintenance-photos` bucket)
- Submit button → creates maintenance_requests row
- After submission: show confirmation with tracking number
- My requests list: show status of all submitted requests with real-time updates

#### 3c. Amenity Booking Screen
**New screen in tenant app:**
- List of available amenities with icons
- Click amenity → calendar view showing available slots
- Select date and time slot → confirm booking
- My bookings section showing upcoming and past bookings
- Cancel booking option

#### 3d. Enhanced Noticeboard
- Categories: General (grey), Urgent (red/amber), Maintenance (blue), Community (green)
- Urgent announcements pinned to top with alert icon
- Push notification for urgent priority items

#### 3e. Document Access
- Add `visible_to` field to existing document system: 'all', 'operator_only', 'tenant'
- BTR tenants only see documents tagged 'tenant' or 'all'
- Operator dashboard controls visibility per document
- Typical tenant docs: Lease summary, House rules, Emergency contacts, Building manual, Area guide, Appliance manuals

#### 3f. Welcome Sequence Notifications
- On tenancy.move_in_date, trigger the welcome sequence
- Day 1: Essentials (Wi-Fi, bins, parking, emergency contacts)
- Day 2: Appliance guides
- Day 3: Local area guide
- Day 5: Amenities & booking
- Day 7: AI assistant introduction
- Delivered via in-app notification and/or push notification

### Phase 4: Conditional Rendering Logic

The entire platform adapts based on one flag. Here's the logic:

```typescript
// Read project type
const projectType = project.project_type; // 'bts' | 'btr' | 'mixed'

// Dashboard navigation
if (projectType === 'bts') {
  // Show: Sales Pipeline, Kitchen Selection, Compliance Docs (existing)
  // Hide: Units (BTR), Maintenance, Amenities, Welcome Sequence
}

if (projectType === 'btr') {
  // Show: Units, Maintenance, Compliance, Amenities, Welcome Sequence, Communications
  // Hide: Sales Pipeline, Kitchen Selection
}

if (projectType === 'mixed') {
  // Show EVERYTHING
  // Units table shows unit_mode column (sale/rent)
  // BTS units link to sales pipeline
  // BTR units link to tenancy management
}

// Tenant app
if (projectType === 'bts') {
  // Show: AI Assistant, Documents, Noticeboard (existing homeowner experience)
  // Hide: Maintenance requests, Amenity booking
}

if (projectType === 'btr' || projectType === 'mixed') {
  // Show: AI Assistant (BTR prompt), Maintenance, Amenity Booking, Documents, Noticeboard
  // Hide: Kitchen selection, Handover journey
}

// Language adaptation
if (projectType === 'btr') {
  // "Purchaser" → "Tenant" / "Resident"
  // "Homeowner" → "Tenant" / "Resident"
  // "Handover" → "Move-in"
  // "Property" → "Apartment" / "Unit"
}
```

## Design System Reminders

- Primary gold: #D4AF37
- Headings: 'Source Serif 4', Georgia, serif
- Body: 'Inter', system-ui, sans-serif
- Cards: bg-white, border border-gold-100, rounded-xl, shadow-sm
- Buttons: bg-brand-500 text-white, hover:bg-brand-600, active:scale-[0.98]
- Icons: Lucide React only, w-4 h-4 default
- Transitions: transition-all duration-150
- Never use emoji, FontAwesome, purple/blue gradients, or generic AI aesthetics
- All interactive elements need hover, focus, active, and disabled states

## Testing Checklist

After implementation, verify:

- [ ] BTS developments work exactly as before (zero regression)
- [ ] BTR development shows all BTR features
- [ ] Mixed development shows both BTS and BTR features
- [ ] Unit status board renders correctly with all states
- [ ] Tenancy creation generates unique access code
- [ ] Tenancy end revokes access and sets unit to void
- [ ] Maintenance request submission with photo upload works
- [ ] Maintenance status workflow transitions correctly
- [ ] Compliance auto-recurrence creates next item on completion
- [ ] Amenity booking prevents double-booking
- [ ] Welcome sequence triggers on move-in date
- [ ] AI assistant uses BTR prompt for BTR developments
- [ ] Tenant app shows correct features based on project_type
- [ ] RLS policies work: developers see own data, tenants see own data
- [ ] All screens match OpenHouse design system
