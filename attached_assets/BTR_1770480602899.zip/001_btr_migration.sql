-- ============================================================
-- OpenHouse AI — BTR Migration
-- Run this in Supabase SQL Editor
-- SAFE: All changes are additive. Zero impact on existing BTS.
-- ============================================================

-- ─── 1. ADD project_type TO projects ────────────────────────
-- This single flag drives the entire platform behaviour
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'projects' AND column_name = 'project_type'
  ) THEN
    ALTER TABLE public.projects
      ADD COLUMN project_type TEXT NOT NULL DEFAULT 'bts'
      CHECK (project_type IN ('bts', 'btr', 'mixed'));
  END IF;
END $$;

COMMENT ON COLUMN public.projects.project_type IS 
  'Development type: bts (Build-to-Sell), btr (Build-to-Rent), mixed (both)';


-- ─── 2. ADD unit lifecycle fields TO units ──────────────────
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'units' AND column_name = 'unit_status'
  ) THEN
    ALTER TABLE public.units
      ADD COLUMN unit_status TEXT DEFAULT 'available'
      CHECK (unit_status IN ('available', 'occupied', 'vacant', 'void', 'maintenance'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'units' AND column_name = 'current_tenancy_id'
  ) THEN
    ALTER TABLE public.units
      ADD COLUMN current_tenancy_id UUID;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'units' AND column_name = 'unit_mode'
  ) THEN
    ALTER TABLE public.units
      ADD COLUMN unit_mode TEXT DEFAULT 'sale'
      CHECK (unit_mode IN ('sale', 'rent'));
  END IF;
END $$;

COMMENT ON COLUMN public.units.unit_status IS 
  'BTR lifecycle status. NULL/available for BTS units.';
COMMENT ON COLUMN public.units.unit_mode IS 
  'For mixed developments: whether this specific unit is sale or rent.';


-- ─── 3. CREATE tenancies TABLE ──────────────────────────────
CREATE TABLE IF NOT EXISTS public.tenancies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  unit_id UUID NOT NULL REFERENCES public.units(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  tenant_id UUID REFERENCES public.tenants(id),
  
  -- Tenant info
  tenant_name TEXT NOT NULL,
  tenant_email TEXT,
  tenant_phone TEXT,
  
  -- Tenancy dates
  lease_start DATE NOT NULL,
  lease_end DATE,
  move_in_date DATE,
  move_out_date DATE,
  
  -- Status
  status TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('pending', 'active', 'notice_given', 'ended', 'cancelled')),
  
  -- Access
  access_code TEXT UNIQUE,
  user_id UUID REFERENCES auth.users(id),
  
  -- Condition reporting
  condition_report_in JSONB DEFAULT '{}',
  condition_report_out JSONB DEFAULT '{}',
  
  -- Rent
  monthly_rent NUMERIC(10,2),
  deposit_amount NUMERIC(10,2),
  deposit_held BOOLEAN DEFAULT false,
  
  -- Notes
  notes TEXT,
  
  -- Timestamps
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tenancies_unit ON public.tenancies(unit_id);
CREATE INDEX IF NOT EXISTS idx_tenancies_project ON public.tenancies(project_id);
CREATE INDEX IF NOT EXISTS idx_tenancies_status ON public.tenancies(status);
CREATE INDEX IF NOT EXISTS idx_tenancies_access_code ON public.tenancies(access_code);

ALTER TABLE public.tenancies ENABLE ROW LEVEL SECURITY;

-- RLS: Developers can see tenancies for their projects
CREATE POLICY IF NOT EXISTS "Developers can view own tenancies"
  ON public.tenancies FOR SELECT
  USING (
    project_id IN (
      SELECT id FROM public.projects WHERE tenant_id IN (
        SELECT tenant_id FROM public.admins WHERE user_id = auth.uid()
      )
    )
  );

CREATE POLICY IF NOT EXISTS "Developers can manage own tenancies"
  ON public.tenancies FOR ALL
  USING (
    project_id IN (
      SELECT id FROM public.projects WHERE tenant_id IN (
        SELECT tenant_id FROM public.admins WHERE user_id = auth.uid()
      )
    )
  );

-- RLS: Tenants can see their own tenancy
CREATE POLICY IF NOT EXISTS "Tenants can view own tenancy"
  ON public.tenancies FOR SELECT
  USING (user_id = auth.uid());


-- ─── 4. CREATE maintenance_requests TABLE ───────────────────
CREATE TABLE IF NOT EXISTS public.maintenance_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Relationships
  unit_id UUID NOT NULL REFERENCES public.units(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  tenancy_id UUID REFERENCES public.tenancies(id),
  
  -- Request details
  category TEXT NOT NULL
    CHECK (category IN ('plumbing', 'electrical', 'heating', 'structural', 'appliance', 'pest', 'exterior', 'common_area', 'general')),
  priority TEXT NOT NULL DEFAULT 'routine'
    CHECK (priority IN ('emergency', 'urgent', 'routine', 'low')),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  
  -- Photos
  photos TEXT[] DEFAULT '{}',
  
  -- Status workflow
  status TEXT NOT NULL DEFAULT 'submitted'
    CHECK (status IN ('submitted', 'acknowledged', 'assigned', 'in_progress', 'awaiting_parts', 'scheduled', 'resolved', 'closed', 'cancelled')),
  
  -- Assignment
  assigned_to TEXT,
  assigned_vendor TEXT,
  scheduled_date DATE,
  scheduled_time_slot TEXT,
  
  -- Resolution
  resolved_at TIMESTAMPTZ,
  resolution_notes TEXT,
  resolution_cost NUMERIC(10,2),
  
  -- Tenant feedback
  tenant_rating INTEGER CHECK (tenant_rating >= 1 AND tenant_rating <= 5),
  tenant_feedback TEXT,
  
  -- AI triage
  ai_diagnosis TEXT,
  ai_suggested_category TEXT,
  ai_suggested_priority TEXT,
  
  -- Flags
  is_warranty_claim BOOLEAN DEFAULT false,
  is_recurring BOOLEAN DEFAULT false,
  related_request_id UUID REFERENCES public.maintenance_requests(id),
  
  -- Timestamps
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  acknowledged_at TIMESTAMPTZ,
  first_response_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_maintenance_unit ON public.maintenance_requests(unit_id);
CREATE INDEX IF NOT EXISTS idx_maintenance_project ON public.maintenance_requests(project_id);
CREATE INDEX IF NOT EXISTS idx_maintenance_status ON public.maintenance_requests(status);
CREATE INDEX IF NOT EXISTS idx_maintenance_priority ON public.maintenance_requests(priority);
CREATE INDEX IF NOT EXISTS idx_maintenance_category ON public.maintenance_requests(category);

ALTER TABLE public.maintenance_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY IF NOT EXISTS "Developers can manage maintenance"
  ON public.maintenance_requests FOR ALL
  USING (
    project_id IN (
      SELECT id FROM public.projects WHERE tenant_id IN (
        SELECT tenant_id FROM public.admins WHERE user_id = auth.uid()
      )
    )
  );

CREATE POLICY IF NOT EXISTS "Tenants can view own maintenance"
  ON public.maintenance_requests FOR SELECT
  USING (
    tenancy_id IN (
      SELECT id FROM public.tenancies WHERE user_id = auth.uid()
    )
  );

CREATE POLICY IF NOT EXISTS "Tenants can create maintenance"
  ON public.maintenance_requests FOR INSERT
  WITH CHECK (
    tenancy_id IN (
      SELECT id FROM public.tenancies WHERE user_id = auth.uid()
    )
  );


-- ─── 5. CREATE compliance_schedule TABLE ────────────────────
CREATE TABLE IF NOT EXISTS public.compliance_schedule (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Relationships
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  unit_id UUID REFERENCES public.units(id) ON DELETE CASCADE,
  
  -- Compliance item
  type TEXT NOT NULL
    CHECK (type IN ('fire_safety', 'gas_safety', 'electrical', 'ber_cert', 'smoke_co_detectors', 'legionella', 'lift_inspection', 'insurance', 'rtu_registration', 'custom')),
  title TEXT NOT NULL,
  description TEXT,
  
  -- Scheduling
  due_date DATE NOT NULL,
  completed_date DATE,
  recurrence_months INTEGER,
  
  -- Status
  status TEXT NOT NULL DEFAULT 'upcoming'
    CHECK (status IN ('upcoming', 'due_soon', 'overdue', 'completed', 'not_applicable')),
  
  -- Documents
  document_url TEXT,
  certificate_number TEXT,
  
  -- Provider
  provider_name TEXT,
  provider_contact TEXT,
  cost NUMERIC(10,2),
  
  -- Notes
  notes TEXT,
  
  -- Timestamps
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_compliance_project ON public.compliance_schedule(project_id);
CREATE INDEX IF NOT EXISTS idx_compliance_due ON public.compliance_schedule(due_date);
CREATE INDEX IF NOT EXISTS idx_compliance_status ON public.compliance_schedule(status);

ALTER TABLE public.compliance_schedule ENABLE ROW LEVEL SECURITY;

CREATE POLICY IF NOT EXISTS "Developers can manage compliance"
  ON public.compliance_schedule FOR ALL
  USING (
    project_id IN (
      SELECT id FROM public.projects WHERE tenant_id IN (
        SELECT tenant_id FROM public.admins WHERE user_id = auth.uid()
      )
    )
  );


-- ─── 6. CREATE amenities TABLE ──────────────────────────────
CREATE TABLE IF NOT EXISTS public.amenities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  
  name TEXT NOT NULL,
  type TEXT NOT NULL
    CHECK (type IN ('gym', 'meeting_room', 'rooftop', 'bbq', 'ev_charger', 'parking', 'bike_storage', 'cinema', 'pool', 'co_working', 'laundry', 'other')),
  description TEXT,
  location TEXT,
  
  -- Booking rules
  is_bookable BOOLEAN DEFAULT true,
  max_duration_hours INTEGER DEFAULT 2,
  max_advance_days INTEGER DEFAULT 14,
  max_active_bookings INTEGER DEFAULT 2,
  requires_deposit BOOLEAN DEFAULT false,
  deposit_amount NUMERIC(10,2),
  
  -- Availability
  available_from TIME DEFAULT '06:00',
  available_until TIME DEFAULT '22:00',
  available_days INTEGER[] DEFAULT '{1,2,3,4,5,6,7}',
  
  -- Capacity
  capacity INTEGER,
  
  -- Media
  photo_url TEXT,
  rules TEXT,
  
  -- Status
  is_active BOOLEAN DEFAULT true,
  
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.amenities ENABLE ROW LEVEL SECURITY;

CREATE POLICY IF NOT EXISTS "Developers can manage amenities"
  ON public.amenities FOR ALL
  USING (
    project_id IN (
      SELECT id FROM public.projects WHERE tenant_id IN (
        SELECT tenant_id FROM public.admins WHERE user_id = auth.uid()
      )
    )
  );

CREATE POLICY IF NOT EXISTS "Tenants can view amenities"
  ON public.amenities FOR SELECT
  USING (
    project_id IN (
      SELECT p.id FROM public.projects p
      JOIN public.units u ON u.project_id = p.id
      JOIN public.tenancies t ON t.unit_id = u.id
      WHERE t.user_id = auth.uid() AND t.status = 'active'
    )
  );


-- ─── 7. CREATE amenity_bookings TABLE ───────────────────────
CREATE TABLE IF NOT EXISTS public.amenity_bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  amenity_id UUID NOT NULL REFERENCES public.amenities(id) ON DELETE CASCADE,
  tenancy_id UUID NOT NULL REFERENCES public.tenancies(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  
  booking_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  
  status TEXT NOT NULL DEFAULT 'confirmed'
    CHECK (status IN ('confirmed', 'cancelled', 'completed', 'no_show')),
  
  notes TEXT,
  
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  
  -- Prevent double-booking
  UNIQUE (amenity_id, booking_date, start_time)
);

ALTER TABLE public.amenity_bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY IF NOT EXISTS "Developers can view all bookings"
  ON public.amenity_bookings FOR SELECT
  USING (
    project_id IN (
      SELECT id FROM public.projects WHERE tenant_id IN (
        SELECT tenant_id FROM public.admins WHERE user_id = auth.uid()
      )
    )
  );

CREATE POLICY IF NOT EXISTS "Tenants can manage own bookings"
  ON public.amenity_bookings FOR ALL
  USING (
    tenancy_id IN (
      SELECT id FROM public.tenancies WHERE user_id = auth.uid()
    )
  );


-- ─── 8. CREATE welcome_sequences TABLE ──────────────────────
CREATE TABLE IF NOT EXISTS public.welcome_sequences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  
  day_number INTEGER NOT NULL DEFAULT 1,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  category TEXT DEFAULT 'general'
    CHECK (category IN ('essentials', 'appliances', 'local_area', 'community', 'general')),
  
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.welcome_sequences ENABLE ROW LEVEL SECURITY;

CREATE POLICY IF NOT EXISTS "Developers can manage sequences"
  ON public.welcome_sequences FOR ALL
  USING (
    project_id IN (
      SELECT id FROM public.projects WHERE tenant_id IN (
        SELECT tenant_id FROM public.admins WHERE user_id = auth.uid()
      )
    )
  );


-- ─── 9. HELPER FUNCTIONS ────────────────────────────────────

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to all new tables
DO $$
DECLARE
  tbl TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY[
    'tenancies', 'maintenance_requests', 'compliance_schedule',
    'amenities', 'amenity_bookings', 'welcome_sequences'
  ] LOOP
    IF NOT EXISTS (
      SELECT 1 FROM pg_trigger WHERE tgname = 'set_updated_at_' || tbl
    ) THEN
      EXECUTE format(
        'CREATE TRIGGER set_updated_at_%s BEFORE UPDATE ON public.%s
         FOR EACH ROW EXECUTE FUNCTION update_updated_at()',
        tbl, tbl
      );
    END IF;
  END LOOP;
END $$;

-- Auto-recurrence for compliance items
CREATE OR REPLACE FUNCTION auto_recur_compliance()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.completed_date IS NOT NULL 
     AND OLD.completed_date IS NULL 
     AND NEW.recurrence_months IS NOT NULL THEN
    INSERT INTO public.compliance_schedule (
      project_id, unit_id, type, title, description,
      due_date, recurrence_months, provider_name, provider_contact
    ) VALUES (
      NEW.project_id, NEW.unit_id, NEW.type, NEW.title, NEW.description,
      NEW.completed_date + (NEW.recurrence_months || ' months')::INTERVAL,
      NEW.recurrence_months, NEW.provider_name, NEW.provider_contact
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS compliance_auto_recur ON public.compliance_schedule;
CREATE TRIGGER compliance_auto_recur
  AFTER UPDATE ON public.compliance_schedule
  FOR EACH ROW EXECUTE FUNCTION auto_recur_compliance();


-- ─── 10. STORAGE BUCKET ─────────────────────────────────────
INSERT INTO storage.buckets (id, name, public)
VALUES ('maintenance-photos', 'maintenance-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policy
CREATE POLICY IF NOT EXISTS "Anyone can upload maintenance photos"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'maintenance-photos');

CREATE POLICY IF NOT EXISTS "Anyone can view maintenance photos"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'maintenance-photos');


-- ============================================================
-- DONE. All existing BTS data is untouched.
-- New BTR features activate when project_type = 'btr' or 'mixed'
-- ============================================================
