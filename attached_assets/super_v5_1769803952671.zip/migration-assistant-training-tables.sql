-- Database migration for Assistant Training & R&D Analytics features

-- Custom Q&A table for development-specific question overrides
CREATE TABLE IF NOT EXISTS custom_qa (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  development_id UUID NOT NULL REFERENCES developments(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  category VARCHAR(50) DEFAULT 'general',
  active BOOLEAN DEFAULT true,
  priority INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast lookups by development
CREATE INDEX IF NOT EXISTS idx_custom_qa_development ON custom_qa(development_id, active);

-- Knowledge base table for additional development information
CREATE TABLE IF NOT EXISTS knowledge_base (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  development_id UUID NOT NULL REFERENCES developments(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  type VARCHAR(50) DEFAULT 'manual', -- 'manual', 'extracted', 'generated'
  source_url TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_knowledge_base_development ON knowledge_base(development_id, active);

-- Question analytics table for R&D insights
CREATE TABLE IF NOT EXISTS question_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  development_id UUID REFERENCES developments(id) ON DELETE SET NULL,
  question TEXT NOT NULL,
  question_hash VARCHAR(64), -- For deduplication
  category VARCHAR(50),
  confidence_score DECIMAL(3,2), -- 0.00 to 1.00
  answered BOOLEAN DEFAULT true,
  response_time_ms INTEGER,
  session_id VARCHAR(100),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for analytics queries
CREATE INDEX IF NOT EXISTS idx_question_analytics_development ON question_analytics(development_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_question_analytics_category ON question_analytics(category, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_question_analytics_hash ON question_analytics(question_hash);

-- Platform insights table for AI-generated insights
CREATE TABLE IF NOT EXISTS platform_insights (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type VARCHAR(50) NOT NULL, -- 'opportunity', 'concern', 'trend', 'recommendation'
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  metric VARCHAR(50),
  action TEXT,
  development_id UUID REFERENCES developments(id) ON DELETE SET NULL, -- NULL = platform-wide
  priority INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT true,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add new columns to developments table if not exists
ALTER TABLE developments ADD COLUMN IF NOT EXISTS system_instructions TEXT;
ALTER TABLE developments ADD COLUMN IF NOT EXISTS sidebar_logo_url TEXT;
ALTER TABLE developments ADD COLUMN IF NOT EXISTS assistant_logo_url TEXT;
ALTER TABLE developments ADD COLUMN IF NOT EXISTS toolbar_logo_url TEXT;

-- Row Level Security (if using Supabase RLS)
ALTER TABLE custom_qa ENABLE ROW LEVEL SECURITY;
ALTER TABLE knowledge_base ENABLE ROW LEVEL SECURITY;
ALTER TABLE question_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_insights ENABLE ROW LEVEL SECURITY;

-- Policies for super_admin access
CREATE POLICY "Super admins can manage custom_qa" ON custom_qa
  FOR ALL USING (true); -- Adjust based on your auth setup

CREATE POLICY "Super admins can manage knowledge_base" ON knowledge_base
  FOR ALL USING (true);

CREATE POLICY "Super admins can view question_analytics" ON question_analytics
  FOR SELECT USING (true);

CREATE POLICY "Super admins can manage platform_insights" ON platform_insights
  FOR ALL USING (true);
