// /api/super/assistant/qa/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

// GET - List custom Q&As for a development
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const developmentId = searchParams.get('development_id');

  if (!developmentId) {
    return NextResponse.json({ error: 'development_id required' }, { status: 400 });
  }

  try {
    const { data, error } = await supabaseAdmin
      .from('custom_qa')
      .select('*')
      .eq('development_id', developmentId)
      .eq('active', true)
      .order('created_at', { ascending: false });

    if (error) throw error;

    return NextResponse.json({ items: data || [] });
  } catch (err) {
    console.error('Error fetching Q&As:', err);
    return NextResponse.json({ error: 'Failed to fetch Q&As' }, { status: 500 });
  }
}

// POST - Create new custom Q&A
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { development_id, question, answer, category } = body;

    if (!development_id || !question || !answer) {
      return NextResponse.json({ error: 'development_id, question, and answer required' }, { status: 400 });
    }

    const { data, error } = await supabaseAdmin
      .from('custom_qa')
      .insert({
        development_id,
        question,
        answer,
        category: category || 'general',
        active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json({ item: data }, { status: 201 });
  } catch (err) {
    console.error('Error creating Q&A:', err);
    return NextResponse.json({ error: 'Failed to create Q&A' }, { status: 500 });
  }
}
