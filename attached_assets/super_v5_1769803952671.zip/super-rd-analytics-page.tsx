'use client';

import { useState, useEffect } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Users,
  MessageSquare,
  Home,
  Building2,
  MapPin,
  Calendar,
  Clock,
  AlertCircle,
  CheckCircle,
  ChevronDown,
  Download,
  RefreshCw,
  Loader2,
  BarChart3,
  PieChart,
  Activity,
  Zap,
  Target,
  Lightbulb,
  Globe,
  FileText,
  Search,
  Filter,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles
} from 'lucide-react';

interface NationalStats {
  totalQuestions: number;
  totalDevelopments: number;
  totalUnits: number;
  totalHomeowners: number;
  avgQuestionsPerUnit: number;
  avgResponseTime: string;
  satisfactionRate: number;
}

interface TrendData {
  date: string;
  questions: number;
  signups: number;
}

interface TopicBreakdown {
  topic: string;
  count: number;
  percentage: number;
  trend: 'up' | 'down' | 'stable';
  trendValue: number;
}

interface RegionalData {
  county: string;
  developments: number;
  units: number;
  questions: number;
  avgSatisfaction: number;
}

interface TrendingQuestion {
  question: string;
  count: number;
  developments: string[];
  isNew: boolean;
}

interface Insight {
  id: string;
  type: 'opportunity' | 'concern' | 'trend' | 'recommendation';
  title: string;
  description: string;
  metric?: string;
  action?: string;
}

export default function RDAnalyticsDashboard() {
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | '1y'>('30d');
  const [activeSection, setActiveSection] = useState<'overview' | 'trends' | 'regional' | 'topics' | 'insights'>('overview');
  
  const [nationalStats, setNationalStats] = useState<NationalStats | null>(null);
  const [trendData, setTrendData] = useState<TrendData[]>([]);
  const [topicBreakdown, setTopicBreakdown] = useState<TopicBreakdown[]>([]);
  const [regionalData, setRegionalData] = useState<RegionalData[]>([]);
  const [trendingQuestions, setTrendingQuestions] = useState<TrendingQuestion[]>([]);
  const [insights, setInsights] = useState<Insight[]>([]);

  useEffect(() => {
    fetchAllData();
  }, [timeRange]);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/super/rd-analytics?range=${timeRange}`);
      if (res.ok) {
        const data = await res.json();
        setNationalStats(data.nationalStats);
        setTrendData(data.trends || []);
        setTopicBreakdown(data.topicBreakdown || []);
        setRegionalData(data.regionalData || []);
        setTrendingQuestions(data.trendingQuestions || []);
        setInsights(data.insights || []);
      }
    } catch (err) {
      console.error('Failed to fetch R&D analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  const insightIcons = {
    opportunity: Lightbulb,
    concern: AlertCircle,
    trend: TrendingUp,
    recommendation: Target
  };

  const insightColors = {
    opportunity: 'bg-emerald-50 border-emerald-200 text-emerald-800',
    concern: 'bg-amber-50 border-amber-200 text-amber-800',
    trend: 'bg-blue-50 border-blue-200 text-blue-800',
    recommendation: 'bg-purple-50 border-purple-200 text-purple-800'
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-semibold text-neutral-900">R&D Analytics</h1>
            <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs font-medium rounded-full">
              Platform Intelligence
            </span>
          </div>
          <p className="text-neutral-500 mt-1">National trends, insights, and continuous improvement data</p>
        </div>
        
        <div className="flex items-center gap-3">
          {/* Time Range */}
          <div className="flex bg-neutral-100 rounded-lg p-1">
            {[
              { value: '7d', label: '7D' },
              { value: '30d', label: '30D' },
              { value: '90d', label: '90D' },
              { value: '1y', label: '1Y' }
            ].map((option) => (
              <button
                key={option.value}
                onClick={() => setTimeRange(option.value as any)}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-all ${
                  timeRange === option.value
                    ? 'bg-white text-neutral-900 shadow-sm'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
          
          <button className="p-2 bg-white border border-neutral-200 rounded-lg text-neutral-600 hover:bg-neutral-50 transition-colors">
            <Download className="w-4 h-4" />
          </button>
          
          <button
            onClick={fetchAllData}
            className="p-2 bg-white border border-neutral-200 rounded-lg text-neutral-600 hover:bg-neutral-50 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* National Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <Globe className="w-5 h-5 text-brand-500" />
            <span className="text-xs font-medium text-emerald-600 flex items-center">
              <ArrowUpRight className="w-3 h-3 mr-0.5" />
              12%
            </span>
          </div>
          <p className="text-3xl font-bold text-neutral-900">{nationalStats?.totalQuestions?.toLocaleString() || 0}</p>
          <p className="text-sm text-neutral-500">Total Questions Nationwide</p>
        </div>

        <div className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <Building2 className="w-5 h-5 text-blue-500" />
          </div>
          <p className="text-3xl font-bold text-neutral-900">{nationalStats?.totalDevelopments || 0}</p>
          <p className="text-sm text-neutral-500">Active Developments</p>
        </div>

        <div className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <Home className="w-5 h-5 text-emerald-500" />
          </div>
          <p className="text-3xl font-bold text-neutral-900">{nationalStats?.totalUnits?.toLocaleString() || 0}</p>
          <p className="text-sm text-neutral-500">Units Managed</p>
        </div>

        <div className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <Zap className="w-5 h-5 text-purple-500" />
          </div>
          <p className="text-3xl font-bold text-neutral-900">{nationalStats?.avgQuestionsPerUnit?.toFixed(1) || 0}</p>
          <p className="text-sm text-neutral-500">Avg Questions/Unit</p>
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-lg p-6">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-purple-600" />
          <h2 className="font-semibold text-neutral-900">AI-Generated Insights</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {insights.slice(0, 4).map((insight) => {
            const Icon = insightIcons[insight.type];
            return (
              <div key={insight.id} className={`p-4 rounded-lg border ${insightColors[insight.type]}`}>
                <div className="flex items-center gap-2 mb-2">
                  <Icon className="w-4 h-4" />
                  <span className="text-xs font-medium uppercase">{insight.type}</span>
                </div>
                <p className="text-sm font-medium">{insight.title}</p>
                <p className="text-xs mt-1 opacity-80">{insight.description}</p>
                {insight.metric && (
                  <p className="text-lg font-bold mt-2">{insight.metric}</p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Section Tabs */}
      <div className="bg-white border border-gold-100 rounded-lg shadow-sm">
        <div className="border-b border-neutral-200">
          <div className="flex overflow-x-auto">
            {[
              { id: 'overview', label: 'Topic Analysis', icon: PieChart },
              { id: 'trends', label: 'Trending Questions', icon: TrendingUp },
              { id: 'regional', label: 'Regional Breakdown', icon: MapPin },
              { id: 'topics', label: 'Knowledge Gaps', icon: AlertCircle },
              { id: 'insights', label: 'All Insights', icon: Lightbulb }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveSection(tab.id as any)}
                  className={`flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                    activeSection === tab.id
                      ? 'border-brand-500 text-brand-600 bg-brand-50/50'
                      : 'border-transparent text-neutral-500 hover:text-neutral-700 hover:bg-neutral-50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="p-6">
          {/* Topic Analysis */}
          {activeSection === 'overview' && (
            <div className="space-y-6">
              <h3 className="font-semibold text-neutral-900">What Homeowners Ask About</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Topic Bars */}
                <div className="space-y-4">
                  {topicBreakdown.map((topic, i) => (
                    <div key={i}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium text-neutral-700">{topic.topic}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-neutral-900 font-medium">{topic.count}</span>
                          {topic.trend !== 'stable' && (
                            <span className={`text-xs flex items-center ${
                              topic.trend === 'up' ? 'text-emerald-600' : 'text-red-600'
                            }`}>
                              {topic.trend === 'up' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                              {topic.trendValue}%
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="h-3 bg-neutral-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-brand-500 rounded-full transition-all duration-500"
                          style={{ width: `${topic.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Quick Stats */}
                <div className="space-y-4">
                  <div className="bg-neutral-50 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-neutral-700 mb-3">Response Quality</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-2xl font-bold text-emerald-600">{nationalStats?.satisfactionRate || 94}%</p>
                        <p className="text-xs text-neutral-500">Satisfaction Rate</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-neutral-900">{nationalStats?.avgResponseTime || '< 1s'}</p>
                        <p className="text-xs text-neutral-500">Avg Response Time</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-blue-50 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-blue-900 mb-2">Top Recommendation</h4>
                    <p className="text-sm text-blue-700">
                      {insights.find(i => i.type === 'recommendation')?.description || 
                       'Consider adding more warranty information - it\'s the most common topic.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Trending Questions */}
          {activeSection === 'trends' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-neutral-900">Trending Questions Nationwide</h3>
                <span className="text-sm text-neutral-500">Last {timeRange === '7d' ? '7 days' : timeRange === '30d' ? '30 days' : timeRange === '90d' ? '90 days' : 'year'}</span>
              </div>
              
              <div className="space-y-3">
                {trendingQuestions.map((q, i) => (
                  <div key={i} className="border border-neutral-200 rounded-lg p-4 hover:border-neutral-300 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-lg font-bold text-brand-600">#{i + 1}</span>
                          {q.isNew && (
                            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 text-xs font-medium rounded-full">
                              New
                            </span>
                          )}
                        </div>
                        <p className="text-neutral-900">{q.question}</p>
                        <p className="text-sm text-neutral-500 mt-1">
                          Asked in: {q.developments.slice(0, 3).join(', ')}
                          {q.developments.length > 3 && ` +${q.developments.length - 3} more`}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold text-neutral-900">{q.count}</p>
                        <p className="text-xs text-neutral-500">times asked</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Regional Breakdown */}
          {activeSection === 'regional' && (
            <div className="space-y-4">
              <h3 className="font-semibold text-neutral-900">Regional Activity</h3>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-neutral-200">
                      <th className="text-left py-3 px-4 text-xs font-semibold text-neutral-500 uppercase">County</th>
                      <th className="text-right py-3 px-4 text-xs font-semibold text-neutral-500 uppercase">Developments</th>
                      <th className="text-right py-3 px-4 text-xs font-semibold text-neutral-500 uppercase">Units</th>
                      <th className="text-right py-3 px-4 text-xs font-semibold text-neutral-500 uppercase">Questions</th>
                      <th className="text-right py-3 px-4 text-xs font-semibold text-neutral-500 uppercase">Satisfaction</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {regionalData.map((region, i) => (
                      <tr key={i} className="hover:bg-neutral-50">
                        <td className="py-3 px-4 font-medium text-neutral-900">{region.county}</td>
                        <td className="py-3 px-4 text-right text-neutral-700">{region.developments}</td>
                        <td className="py-3 px-4 text-right text-neutral-700">{region.units}</td>
                        <td className="py-3 px-4 text-right text-neutral-700">{region.questions}</td>
                        <td className="py-3 px-4 text-right">
                          <span className={`font-medium ${region.avgSatisfaction >= 90 ? 'text-emerald-600' : 'text-amber-600'}`}>
                            {region.avgSatisfaction}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Knowledge Gaps */}
          {activeSection === 'topics' && (
            <div className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-amber-900">Knowledge Gap Detection</p>
                    <p className="text-sm text-amber-700 mt-1">
                      These topics are frequently asked but have low answer confidence. Consider adding documentation or custom Q&As.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                {[
                  { topic: 'Warranty Extension Process', frequency: 156, confidence: 62, suggestion: 'Add detailed warranty extension procedures' },
                  { topic: 'Management Fee Breakdown', frequency: 134, confidence: 58, suggestion: 'Include management fee structure in docs' },
                  { topic: 'Parking Visitor Rules', frequency: 98, confidence: 45, suggestion: 'Create parking policy document' },
                  { topic: 'Pet Policy Details', frequency: 87, confidence: 52, suggestion: 'Add pet policy to development rules' },
                  { topic: 'Bin Collection Schedule', frequency: 76, confidence: 68, suggestion: 'Include local council waste info' }
                ].map((gap, i) => (
                  <div key={i} className="border border-neutral-200 rounded-lg p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium text-neutral-900">{gap.topic}</h4>
                        <p className="text-sm text-neutral-500 mt-1">{gap.suggestion}</p>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-neutral-500">{gap.frequency} questions</span>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            gap.confidence < 50 ? 'bg-red-100 text-red-700' :
                            gap.confidence < 70 ? 'bg-amber-100 text-amber-700' :
                            'bg-emerald-100 text-emerald-700'
                          }`}>
                            {gap.confidence}% confidence
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* All Insights */}
          {activeSection === 'insights' && (
            <div className="space-y-4">
              <h3 className="font-semibold text-neutral-900">All Platform Insights</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {insights.map((insight) => {
                  const Icon = insightIcons[insight.type];
                  return (
                    <div key={insight.id} className={`p-4 rounded-lg border ${insightColors[insight.type]}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <Icon className="w-4 h-4" />
                        <span className="text-xs font-medium uppercase">{insight.type}</span>
                      </div>
                      <h4 className="font-medium">{insight.title}</h4>
                      <p className="text-sm mt-1 opacity-80">{insight.description}</p>
                      {insight.metric && (
                        <p className="text-lg font-bold mt-2">{insight.metric}</p>
                      )}
                      {insight.action && (
                        <button className="mt-3 text-sm font-medium underline hover:no-underline">
                          {insight.action} →
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
