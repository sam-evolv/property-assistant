'use client';

import { useState, useEffect, useRef } from 'react';
import {
  Brain,
  MessageSquare,
  Plus,
  Send,
  Trash2,
  Save,
  RefreshCw,
  Loader2,
  CheckCircle,
  AlertCircle,
  ChevronDown,
  Sparkles,
  FileText,
  Settings,
  TestTube,
  BookOpen,
  Lightbulb,
  ArrowRight,
  Edit,
  X,
  Copy
} from 'lucide-react';

interface Development {
  id: string;
  name: string;
  tenant_name: string;
}

interface CustomQA {
  id: string;
  question: string;
  answer: string;
  category: string;
  active: boolean;
  created_at: string;
}

interface TestMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function AssistantTrainingPage() {
  const [developments, setDevelopments] = useState<Development[]>([]);
  const [selectedDev, setSelectedDev] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'test' | 'qa' | 'instructions' | 'knowledge'>('test');
  const [loading, setLoading] = useState(true);
  
  // Test Chat State
  const [testMessages, setTestMessages] = useState<TestMessage[]>([]);
  const [testInput, setTestInput] = useState('');
  const [testing, setTesting] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  
  // Custom Q&A State
  const [customQAs, setCustomQAs] = useState<CustomQA[]>([]);
  const [editingQA, setEditingQA] = useState<CustomQA | null>(null);
  const [newQuestion, setNewQuestion] = useState('');
  const [newAnswer, setNewAnswer] = useState('');
  const [newCategory, setNewCategory] = useState('general');
  const [savingQA, setSavingQA] = useState(false);
  
  // System Instructions State
  const [systemInstructions, setSystemInstructions] = useState('');
  const [savingInstructions, setSavingInstructions] = useState(false);
  const [instructionsSaved, setInstructionsSaved] = useState(false);
  
  // Knowledge Base State
  const [knowledgeItems, setKnowledgeItems] = useState<Array<{ id: string; title: string; content: string; type: string }>>([]);
  const [newKnowledgeTitle, setNewKnowledgeTitle] = useState('');
  const [newKnowledgeContent, setNewKnowledgeContent] = useState('');

  useEffect(() => {
    fetchDevelopments();
  }, []);

  useEffect(() => {
    if (selectedDev) {
      fetchDevData();
    }
  }, [selectedDev]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [testMessages]);

  const fetchDevelopments = async () => {
    try {
      const res = await fetch('/api/super/developments');
      if (res.ok) {
        const data = await res.json();
        setDevelopments(data.developments || []);
        if (data.developments?.length > 0) {
          setSelectedDev(data.developments[0].id);
        }
      }
    } catch (err) {
      console.error('Failed to fetch developments:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchDevData = async () => {
    // Fetch custom Q&As
    try {
      const qaRes = await fetch(`/api/super/assistant/qa?development_id=${selectedDev}`);
      if (qaRes.ok) {
        const data = await qaRes.json();
        setCustomQAs(data.items || []);
      }
    } catch {}

    // Fetch system instructions
    try {
      const devRes = await fetch(`/api/super/developments/${selectedDev}`);
      if (devRes.ok) {
        const data = await devRes.json();
        setSystemInstructions(data.development?.system_instructions || '');
      }
    } catch {}

    // Fetch knowledge base
    try {
      const kbRes = await fetch(`/api/super/assistant/knowledge?development_id=${selectedDev}`);
      if (kbRes.ok) {
        const data = await kbRes.json();
        setKnowledgeItems(data.items || []);
      }
    } catch {}
  };

  // Test the assistant
  const sendTestMessage = async () => {
    if (!testInput.trim() || testing) return;
    
    const userMessage: TestMessage = {
      role: 'user',
      content: testInput,
      timestamp: new Date()
    };
    
    setTestMessages(prev => [...prev, userMessage]);
    setTestInput('');
    setTesting(true);

    try {
      const res = await fetch('/api/super/assistant/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          development_id: selectedDev,
          message: userMessage.content,
          include_custom_qa: true
        })
      });

      if (res.ok) {
        const data = await res.json();
        const assistantMessage: TestMessage = {
          role: 'assistant',
          content: data.response,
          timestamp: new Date()
        };
        setTestMessages(prev => [...prev, assistantMessage]);
      } else {
        throw new Error('Failed to get response');
      }
    } catch (err) {
      const errorMessage: TestMessage = {
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.',
        timestamp: new Date()
      };
      setTestMessages(prev => [...prev, errorMessage]);
    } finally {
      setTesting(false);
    }
  };

  // Save custom Q&A
  const saveCustomQA = async () => {
    if (!newQuestion.trim() || !newAnswer.trim()) return;
    
    setSavingQA(true);
    try {
      const res = await fetch('/api/super/assistant/qa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          development_id: selectedDev,
          question: newQuestion,
          answer: newAnswer,
          category: newCategory
        })
      });

      if (res.ok) {
        const data = await res.json();
        setCustomQAs(prev => [...prev, data.item]);
        setNewQuestion('');
        setNewAnswer('');
        setNewCategory('general');
      }
    } catch (err) {
      alert('Failed to save Q&A');
    } finally {
      setSavingQA(false);
    }
  };

  // Delete custom Q&A
  const deleteQA = async (id: string) => {
    try {
      await fetch(`/api/super/assistant/qa/${id}`, { method: 'DELETE' });
      setCustomQAs(prev => prev.filter(qa => qa.id !== id));
    } catch {}
  };

  // Save system instructions
  const saveInstructions = async () => {
    setSavingInstructions(true);
    try {
      const res = await fetch(`/api/super/developments/${selectedDev}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ system_instructions: systemInstructions })
      });

      if (res.ok) {
        setInstructionsSaved(true);
        setTimeout(() => setInstructionsSaved(false), 3000);
      }
    } catch (err) {
      alert('Failed to save instructions');
    } finally {
      setSavingInstructions(false);
    }
  };

  // Add knowledge item
  const addKnowledgeItem = async () => {
    if (!newKnowledgeTitle.trim() || !newKnowledgeContent.trim()) return;
    
    try {
      const res = await fetch('/api/super/assistant/knowledge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          development_id: selectedDev,
          title: newKnowledgeTitle,
          content: newKnowledgeContent,
          type: 'manual'
        })
      });

      if (res.ok) {
        const data = await res.json();
        setKnowledgeItems(prev => [...prev, data.item]);
        setNewKnowledgeTitle('');
        setNewKnowledgeContent('');
      }
    } catch {}
  };

  const selectedDevName = developments.find(d => d.id === selectedDev)?.name || 'Select Development';

  const categories = [
    { value: 'general', label: 'General' },
    { value: 'warranty', label: 'Warranty' },
    { value: 'maintenance', label: 'Maintenance' },
    { value: 'documents', label: 'Documents' },
    { value: 'contacts', label: 'Contacts' },
    { value: 'facilities', label: 'Facilities' }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-900">Assistant Training</h1>
          <p className="text-neutral-500 mt-1">Test, train, and customize the AI assistant</p>
        </div>
        
        {/* Development Selector */}
        <div className="relative">
          <select
            value={selectedDev}
            onChange={(e) => setSelectedDev(e.target.value)}
            className="appearance-none pl-4 pr-10 py-2.5 bg-white border border-neutral-200 rounded-lg text-sm font-medium focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none min-w-[200px]"
          >
            <option value="">Select Development</option>
            {developments.map(dev => (
              <option key={dev.id} value={dev.id}>{dev.name}</option>
            ))}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 pointer-events-none" />
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border border-gold-100 rounded-lg shadow-sm">
        <div className="border-b border-neutral-200">
          <div className="flex">
            {[
              { id: 'test', label: 'Test Assistant', icon: TestTube },
              { id: 'qa', label: 'Custom Q&A', icon: MessageSquare },
              { id: 'instructions', label: 'System Instructions', icon: Settings },
              { id: 'knowledge', label: 'Knowledge Base', icon: BookOpen }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-brand-500 text-brand-600 bg-brand-50/50'
                      : 'border-transparent text-neutral-500 hover:text-neutral-700 hover:bg-neutral-50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="p-6">
          {/* Test Assistant Tab */}
          {activeTab === 'test' && (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Lightbulb className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-blue-900">Test Mode</p>
                    <p className="text-sm text-blue-700 mt-1">
                      Ask questions as if you were a homeowner. The assistant will use this development's documents, custom Q&As, and instructions.
                    </p>
                  </div>
                </div>
              </div>

              {/* Chat Area */}
              <div className="border border-neutral-200 rounded-lg h-96 flex flex-col">
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {testMessages.length === 0 ? (
                    <div className="text-center text-neutral-400 py-12">
                      <Brain className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Start a conversation to test the assistant</p>
                      <p className="text-sm mt-1">Try asking about warranty, maintenance, or documents</p>
                    </div>
                  ) : (
                    testMessages.map((msg, i) => (
                      <div
                        key={i}
                        className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[80%] px-4 py-3 rounded-2xl ${
                            msg.role === 'user'
                              ? 'bg-brand-500 text-white rounded-br-md'
                              : 'bg-neutral-100 text-neutral-900 rounded-bl-md'
                          }`}
                        >
                          <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                        </div>
                      </div>
                    ))
                  )}
                  {testing && (
                    <div className="flex justify-start">
                      <div className="bg-neutral-100 px-4 py-3 rounded-2xl rounded-bl-md">
                        <Loader2 className="w-5 h-5 animate-spin text-neutral-500" />
                      </div>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </div>

                {/* Input */}
                <div className="border-t border-neutral-200 p-3">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={testInput}
                      onChange={(e) => setTestInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && sendTestMessage()}
                      placeholder="Ask a question..."
                      className="flex-1 px-4 py-2.5 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none"
                      disabled={testing || !selectedDev}
                    />
                    <button
                      onClick={sendTestMessage}
                      disabled={testing || !testInput.trim() || !selectedDev}
                      className="px-4 py-2.5 bg-brand-500 text-white rounded-lg hover:bg-brand-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={() => setTestMessages([])}
                  className="text-sm text-neutral-500 hover:text-neutral-700"
                >
                  Clear conversation
                </button>
              </div>
            </div>
          )}

          {/* Custom Q&A Tab */}
          {activeTab === 'qa' && (
            <div className="space-y-6">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Sparkles className="w-5 h-5 text-amber-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-amber-900">Custom Q&A Override</p>
                    <p className="text-sm text-amber-700 mt-1">
                      Add specific questions and answers. These take priority over AI-generated responses.
                    </p>
                  </div>
                </div>
              </div>

              {/* Add New Q&A */}
              <div className="border border-neutral-200 rounded-lg p-4 space-y-4">
                <h3 className="font-medium text-neutral-900">Add New Q&A</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-neutral-700 mb-1">Question</label>
                    <input
                      type="text"
                      value={newQuestion}
                      onChange={(e) => setNewQuestion(e.target.value)}
                      placeholder="e.g., What is the warranty period?"
                      className="w-full px-4 py-2.5 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-neutral-700 mb-1">Answer</label>
                    <textarea
                      value={newAnswer}
                      onChange={(e) => setNewAnswer(e.target.value)}
                      placeholder="The warranty period is 2 years from handover..."
                      rows={3}
                      className="w-full px-4 py-3 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none resize-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-1">Category</label>
                    <select
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      className="w-full px-4 py-2.5 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none"
                    >
                      {categories.map(c => (
                        <option key={c.value} value={c.value}>{c.label}</option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-end">
                    <button
                      onClick={saveCustomQA}
                      disabled={savingQA || !newQuestion.trim() || !newAnswer.trim()}
                      className="px-6 py-2.5 bg-brand-500 text-white rounded-lg font-medium hover:bg-brand-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
                    >
                      {savingQA ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                      Add Q&A
                    </button>
                  </div>
                </div>
              </div>

              {/* Existing Q&As */}
              <div className="space-y-3">
                <h3 className="font-medium text-neutral-900">{customQAs.length} Custom Q&As</h3>
                {customQAs.length === 0 ? (
                  <div className="text-center py-8 text-neutral-500">
                    <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No custom Q&As yet</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {customQAs.map((qa) => (
                      <div key={qa.id} className="border border-neutral-200 rounded-lg p-4 hover:border-neutral-300 transition-colors">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-medium text-brand-600 bg-brand-50 px-2 py-0.5 rounded-full">
                                {qa.category}
                              </span>
                            </div>
                            <p className="font-medium text-neutral-900">{qa.question}</p>
                            <p className="text-sm text-neutral-600 mt-1">{qa.answer}</p>
                          </div>
                          <button
                            onClick={() => deleteQA(qa.id)}
                            className="p-2 text-neutral-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* System Instructions Tab */}
          {activeTab === 'instructions' && (
            <div className="space-y-4">
              <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-4">
                <p className="text-sm text-neutral-600">
                  These instructions are prepended to every AI response for this development. Use them to set tone, add specific rules, or include important context.
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-2">
                  Custom System Instructions
                </label>
                <textarea
                  value={systemInstructions}
                  onChange={(e) => setSystemInstructions(e.target.value)}
                  rows={12}
                  placeholder={`Example instructions:

- Always mention that the management company is ABC Property Management (contact: info@abc.ie)
- The warranty period is 2 years from the handover date
- For maintenance issues, homeowners should first check the Home User Guide
- Be friendly and helpful, but direct homeowners to contact the developer for complex issues
- The BER certificate is included in the legal documents folder`}
                  className="w-full px-4 py-3 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none resize-none font-mono"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  {instructionsSaved && (
                    <span className="text-sm text-emerald-600 flex items-center gap-1">
                      <CheckCircle className="w-4 h-4" />
                      Saved successfully
                    </span>
                  )}
                </div>
                <button
                  onClick={saveInstructions}
                  disabled={savingInstructions}
                  className="px-6 py-2.5 bg-brand-500 text-white rounded-lg font-medium hover:bg-brand-600 disabled:opacity-50 transition-colors flex items-center gap-2"
                >
                  {savingInstructions ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  Save Instructions
                </button>
              </div>
            </div>
          )}

          {/* Knowledge Base Tab */}
          {activeTab === 'knowledge' && (
            <div className="space-y-6">
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <BookOpen className="w-5 h-5 text-purple-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-purple-900">Knowledge Base</p>
                    <p className="text-sm text-purple-700 mt-1">
                      Add additional information that the assistant can reference. This supplements the uploaded documents.
                    </p>
                  </div>
                </div>
              </div>

              {/* Add Knowledge */}
              <div className="border border-neutral-200 rounded-lg p-4 space-y-4">
                <h3 className="font-medium text-neutral-900">Add Knowledge Entry</h3>
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1">Title</label>
                  <input
                    type="text"
                    value={newKnowledgeTitle}
                    onChange={(e) => setNewKnowledgeTitle(e.target.value)}
                    placeholder="e.g., Management Company Contact"
                    className="w-full px-4 py-2.5 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1">Content</label>
                  <textarea
                    value={newKnowledgeContent}
                    onChange={(e) => setNewKnowledgeContent(e.target.value)}
                    placeholder="The management company for this development is..."
                    rows={4}
                    className="w-full px-4 py-3 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none resize-none"
                  />
                </div>
                <button
                  onClick={addKnowledgeItem}
                  disabled={!newKnowledgeTitle.trim() || !newKnowledgeContent.trim()}
                  className="px-6 py-2.5 bg-brand-500 text-white rounded-lg font-medium hover:bg-brand-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add Entry
                </button>
              </div>

              {/* Knowledge Items */}
              <div className="space-y-3">
                <h3 className="font-medium text-neutral-900">{knowledgeItems.length} Knowledge Entries</h3>
                {knowledgeItems.length === 0 ? (
                  <div className="text-center py-8 text-neutral-500">
                    <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No knowledge entries yet</p>
                  </div>
                ) : (
                  <div className="grid gap-3">
                    {knowledgeItems.map((item) => (
                      <div key={item.id} className="border border-neutral-200 rounded-lg p-4">
                        <h4 className="font-medium text-neutral-900">{item.title}</h4>
                        <p className="text-sm text-neutral-600 mt-1 line-clamp-2">{item.content}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
