// /api/chat/stream/route.ts
// STREAMING VERSION - Shows response as it generates (feels instant)
import { NextRequest } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

// Cache for development data
const devCache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { development_id, message, unit_id } = body;

    if (!development_id || !message) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Get development (with cache)
    let development = devCache.get(development_id)?.data;
    if (!development || Date.now() - (devCache.get(development_id)?.timestamp || 0) > CACHE_TTL) {
      const { data } = await supabaseAdmin
        .from('developments')
        .select('id, name, system_instructions')
        .eq('id', development_id)
        .single();
      development = data;
      if (data) devCache.set(development_id, { data, timestamp: Date.now() });
    }

    if (!development) {
      return new Response(JSON.stringify({ error: 'Development not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Parallel fetch: custom Q&A + knowledge (skip slow vector search for streaming)
    const [qaResult, kbResult] = await Promise.all([
      supabaseAdmin
        .from('custom_qa')
        .select('question, answer')
        .eq('development_id', development_id)
        .eq('active', true)
        .limit(10),
      supabaseAdmin
        .from('knowledge_base')
        .select('title, content')
        .or(`development_id.eq.${development_id},development_id.is.null`)
        .eq('active', true)
        .limit(5)
    ]);

    // Build concise context
    let context = '';
    if (qaResult.data?.length) {
      context += '\nQ&A:\n' + qaResult.data.map((q: any) => `Q:${q.question} A:${q.answer}`).join('\n');
    }
    if (kbResult.data?.length) {
      context += '\nInfo:\n' + kbResult.data.map((k: any) => `${k.title}:${k.content}`).join('\n');
    }

    const systemPrompt = `You're the assistant for ${development.name}. Be helpful and concise.
${development.system_instructions || ''}
${context}`;

    // STREAMING RESPONSE
    const stream = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ],
      max_tokens: 512,
      temperature: 0.5,
      stream: true, // Enable streaming
    });

    // Create a readable stream for the response
    const encoder = new TextEncoder();
    const readable = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of stream) {
            const content = chunk.choices[0]?.delta?.content || '';
            if (content) {
              controller.enqueue(encoder.encode(`data: ${JSON.stringify({ content })}\n\n`));
            }
          }
          controller.enqueue(encoder.encode('data: [DONE]\n\n'));
          controller.close();
        } catch (err) {
          controller.error(err);
        }
      }
    });

    return new Response(readable, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      }
    });
  } catch (err) {
    console.error('[Stream Chat] Error:', err);
    return new Response(JSON.stringify({ error: 'Failed to process request' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
