// /api/super/assistant/test/route.ts
// OPTIMIZED: Parallel queries, optional vector search, faster model
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

// Simple in-memory cache for development details (reduces DB calls)
const devCache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

export async function POST(request: NextRequest) {
  const startTime = Date.now();
  
  try {
    const body = await request.json();
    const { development_id, message, include_custom_qa, skip_vector_search } = body;

    if (!development_id || !message) {
      return NextResponse.json({ 
        error: 'development_id and message required'
      }, { status: 400 });
    }

    // Check cache for development details
    let development = null;
    const cached = devCache.get(development_id);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      development = cached.data;
    } else {
      const { data } = await supabaseAdmin
        .from('developments')
        .select('id, name, system_instructions, address, county')
        .eq('id', development_id)
        .single();
      
      if (data) {
        development = data;
        devCache.set(development_id, { data, timestamp: Date.now() });
      }
    }

    if (!development) {
      return NextResponse.json({ error: 'Development not found' }, { status: 404 });
    }

    // OPTIMIZATION 1: Run all data fetches in PARALLEL
    const [customQAResult, knowledgeResult, documentResult] = await Promise.all([
      // Fetch custom Q&As
      include_custom_qa !== false 
        ? supabaseAdmin
            .from('custom_qa')
            .select('question, answer')
            .eq('development_id', development.id)
            .eq('active', true)
        : Promise.resolve({ data: null }),
      
      // Fetch knowledge base
      supabaseAdmin
        .from('knowledge_base')
        .select('title, content, category')
        .or(`development_id.eq.${development.id},development_id.is.null`)
        .eq('active', true)
        .limit(10), // Limit to prevent huge context
      
      // Vector search (OPTIONAL - skip for speed if not needed)
      skip_vector_search 
        ? Promise.resolve({ chunks: [] })
        : searchDocuments(message, development.id)
    ]);

    // Build context strings
    let customQAContext = '';
    if (customQAResult.data?.length) {
      customQAContext = '\n\n## Custom Q&A:\n' +
        customQAResult.data.map((qa: any) => `Q: ${qa.question}\nA: ${qa.answer}`).join('\n\n');
    }

    let knowledgeContext = '';
    if (knowledgeResult.data?.length) {
      knowledgeContext = '\n\n## Knowledge Base:\n' +
        knowledgeResult.data.slice(0, 5).map((k: any) => `${k.title}: ${k.content}`).join('\n\n');
    }

    let documentContext = '';
    if (documentResult.chunks?.length) {
      documentContext = '\n\n## Documents:\n' +
        documentResult.chunks.slice(0, 3).map((c: any) => c.content).join('\n---\n');
    }

    // OPTIMIZATION 2: Shorter, focused system prompt
    const systemPrompt = `You are a helpful assistant for ${development.name} residential development.
${development.system_instructions || ''}
${customQAContext}
${knowledgeContext}
${documentContext}

Be concise and helpful. If you don't have specific info, say so.`;

    // OPTIMIZATION 3: Use gpt-4o-mini with lower max_tokens for faster response
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ],
      max_tokens: 512, // Reduced from 1024 - faster completion
      temperature: 0.5, // Lower = faster, more deterministic
    });

    const assistantResponse = response.choices[0]?.message?.content || 
      'I apologize, I could not generate a response.';

    const duration = Date.now() - startTime;
    console.log(`[Test Assistant] Response in ${duration}ms`);

    return NextResponse.json({ 
      response: assistantResponse,
      timing: {
        total_ms: duration
      }
    });
  } catch (err) {
    console.error('[Test Assistant] Error:', err);
    return NextResponse.json({ 
      error: 'Failed to get response',
      details: err instanceof Error ? err.message : 'Unknown error'
    }, { status: 500 });
  }
}

// Separate function for vector search with timeout
async function searchDocuments(message: string, developmentId: string): Promise<{ chunks: any[] }> {
  try {
    // Set a timeout for vector search - don't let it block
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2000); // 2s timeout

    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-ada-002',
      input: message,
    });
    
    clearTimeout(timeout);
    const queryEmbedding = embeddingResponse.data[0].embedding;

    const { data: chunks } = await supabaseAdmin
      .rpc('match_document_sections', {
        query_embedding: queryEmbedding,
        match_threshold: 0.75, // Higher threshold = fewer, more relevant results
        match_count: 3, // Reduced from 5
        p_development_id: developmentId
      });

    return { chunks: chunks || [] };
  } catch (err) {
    console.log('[Vector Search] Skipped or failed:', err);
    return { chunks: [] };
  }
}
