'use client';

import { useState, useEffect } from 'react';
import { 
  FileText, 
  Download, 
  Eye, 
  Calendar, 
  Building2, 
  MapPin, 
  Users, 
  Link as LinkIcon,
  Loader2,
  RefreshCw,
  CheckCircle,
  Clock,
  XCircle
} from 'lucide-react';

interface OnboardingSubmission {
  id: string;
  tenant_id: string;
  developer_id: string;
  developer_email: string;
  development_name: string;
  development_address: string;
  county: string;
  estimated_units: number;
  expected_handover_date: string | null;
  planning_reference: string | null;
  planning_pack_url: string | null;
  master_spreadsheet_url: string | null;
  supporting_documents_urls: string[] | null;
  notes: string | null;
  status: 'pending' | 'in_review' | 'completed' | 'rejected';
  created_at: string;
  updated_at: string;
}

export default function OnboardingSubmissionsPage() {
  const [submissions, setSubmissions] = useState<OnboardingSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedSubmission, setSelectedSubmission] = useState<OnboardingSubmission | null>(null);
  const [filter, setFilter] = useState<'all' | 'pending' | 'in_review' | 'completed'>('all');

  useEffect(() => {
    fetchSubmissions();
  }, []);

  const fetchSubmissions = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/super/onboarding-submissions');
      if (!res.ok) throw new Error('Failed to fetch submissions');
      const data = await res.json();
      setSubmissions(data.submissions || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load submissions');
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/super/onboarding-submissions/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (!res.ok) throw new Error('Failed to update status');
      fetchSubmissions();
    } catch (err) {
      alert('Failed to update status');
    }
  };

  const filteredSubmissions = submissions.filter(s => 
    filter === 'all' ? true : s.status === filter
  );

  const statusConfig = {
    pending: { label: 'Pending', color: 'bg-amber-100 text-amber-700', icon: Clock },
    in_review: { label: 'In Review', color: 'bg-blue-100 text-blue-700', icon: Eye },
    completed: { label: 'Completed', color: 'bg-emerald-100 text-emerald-700', icon: CheckCircle },
    rejected: { label: 'Rejected', color: 'bg-red-100 text-red-700', icon: XCircle }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-IE', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-900">Onboarding Submissions</h1>
          <p className="text-neutral-500 mt-1">Review and process new developer applications</p>
        </div>
        <button
          onClick={fetchSubmissions}
          className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-neutral-200 rounded-lg text-sm font-medium text-neutral-700 hover:bg-neutral-50 transition-all duration-150"
        >
          <RefreshCw className="w-4 h-4" />
          Refresh
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Submissions', value: submissions.length, color: 'border-brand-500' },
          { label: 'Pending Review', value: submissions.filter(s => s.status === 'pending').length, color: 'border-amber-500' },
          { label: 'In Review', value: submissions.filter(s => s.status === 'in_review').length, color: 'border-blue-500' },
          { label: 'Completed', value: submissions.filter(s => s.status === 'completed').length, color: 'border-emerald-500' }
        ].map((stat, i) => (
          <div key={i} className={`bg-white border-l-4 ${stat.color} rounded-lg p-4 shadow-sm`}>
            <p className="text-sm text-neutral-500">{stat.label}</p>
            <p className="text-2xl font-semibold text-neutral-900 mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 border-b border-neutral-200 pb-4">
        {['all', 'pending', 'in_review', 'completed'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f as any)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150 ${
              filter === f 
                ? 'bg-brand-500 text-white' 
                : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
            }`}
          >
            {f === 'all' ? 'All' : f === 'in_review' ? 'In Review' : f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {/* Loading State */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}

      {/* Empty State */}
      {!loading && !error && filteredSubmissions.length === 0 && (
        <div className="bg-white border border-gold-100 rounded-lg p-12 text-center">
          <FileText className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-neutral-900">No submissions yet</h3>
          <p className="text-neutral-500 mt-1">New developer applications will appear here</p>
        </div>
      )}

      {/* Submissions Table */}
      {!loading && !error && filteredSubmissions.length > 0 && (
        <div className="bg-white border border-gold-100 rounded-lg shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-neutral-50 border-b border-neutral-200">
              <tr>
                <th className="text-left px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Developer</th>
                <th className="text-left px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Development</th>
                <th className="text-left px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Units</th>
                <th className="text-left px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Status</th>
                <th className="text-left px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Submitted</th>
                <th className="text-right px-6 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {filteredSubmissions.map((submission) => {
                const StatusIcon = statusConfig[submission.status].icon;
                return (
                  <tr key={submission.id} className="hover:bg-neutral-50 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-medium text-neutral-900">{submission.developer_email}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-medium text-neutral-900">{submission.development_name}</p>
                        <p className="text-sm text-neutral-500">{submission.county}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-neutral-900">{submission.estimated_units}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${statusConfig[submission.status].color}`}>
                        <StatusIcon className="w-3.5 h-3.5" />
                        {statusConfig[submission.status].label}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-neutral-500">
                      {formatDate(submission.created_at)}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => setSelectedSubmission(submission)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-brand-600 hover:bg-brand-50 rounded-lg transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                        View
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Detail Modal */}
      {selectedSubmission && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-neutral-200">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-neutral-900">{selectedSubmission.development_name}</h2>
                  <p className="text-neutral-500 mt-1">{selectedSubmission.developer_email}</p>
                </div>
                <button
                  onClick={() => setSelectedSubmission(null)}
                  className="text-neutral-400 hover:text-neutral-600 p-1"
                >
                  <XCircle className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Development Details */}
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-neutral-400 mt-0.5" />
                  <div>
                    <p className="text-sm text-neutral-500">Address</p>
                    <p className="font-medium">{selectedSubmission.development_address}</p>
                    <p className="text-sm text-neutral-500">{selectedSubmission.county}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Users className="w-5 h-5 text-neutral-400 mt-0.5" />
                  <div>
                    <p className="text-sm text-neutral-500">Estimated Units</p>
                    <p className="font-medium">{selectedSubmission.estimated_units}</p>
                  </div>
                </div>
                {selectedSubmission.expected_handover_date && (
                  <div className="flex items-start gap-3">
                    <Calendar className="w-5 h-5 text-neutral-400 mt-0.5" />
                    <div>
                      <p className="text-sm text-neutral-500">Expected Handover</p>
                      <p className="font-medium">{new Date(selectedSubmission.expected_handover_date).toLocaleDateString('en-IE')}</p>
                    </div>
                  </div>
                )}
                {selectedSubmission.planning_reference && (
                  <div className="flex items-start gap-3">
                    <FileText className="w-5 h-5 text-neutral-400 mt-0.5" />
                    <div>
                      <p className="text-sm text-neutral-500">Planning Reference</p>
                      <p className="font-medium">{selectedSubmission.planning_reference}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Links */}
              {selectedSubmission.planning_pack_url && (
                <div className="flex items-center gap-3 p-3 bg-neutral-50 rounded-lg">
                  <LinkIcon className="w-5 h-5 text-neutral-400" />
                  <div className="flex-1">
                    <p className="text-sm text-neutral-500">Planning Pack URL</p>
                    <a href={selectedSubmission.planning_pack_url} target="_blank" rel="noopener noreferrer" className="text-brand-600 hover:underline truncate block">
                      {selectedSubmission.planning_pack_url}
                    </a>
                  </div>
                </div>
              )}

              {/* Files */}
              {selectedSubmission.master_spreadsheet_url && (
                <div className="flex items-center gap-3 p-3 bg-neutral-50 rounded-lg">
                  <Download className="w-5 h-5 text-neutral-400" />
                  <div className="flex-1">
                    <p className="text-sm text-neutral-500">Master Spreadsheet</p>
                    <a href={selectedSubmission.master_spreadsheet_url} target="_blank" rel="noopener noreferrer" className="text-brand-600 hover:underline">
                      Download File
                    </a>
                  </div>
                </div>
              )}

              {/* Notes */}
              {selectedSubmission.notes && (
                <div>
                  <p className="text-sm text-neutral-500 mb-2">Notes</p>
                  <p className="text-neutral-700 bg-neutral-50 p-3 rounded-lg">{selectedSubmission.notes}</p>
                </div>
              )}

              {/* Status Update */}
              <div className="border-t border-neutral-200 pt-6">
                <p className="text-sm font-medium text-neutral-700 mb-3">Update Status</p>
                <div className="flex gap-2 flex-wrap">
                  {['pending', 'in_review', 'completed', 'rejected'].map((status) => (
                    <button
                      key={status}
                      onClick={() => {
                        updateStatus(selectedSubmission.id, status);
                        setSelectedSubmission({ ...selectedSubmission, status: status as any });
                      }}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150 ${
                        selectedSubmission.status === status
                          ? 'bg-brand-500 text-white'
                          : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
                      }`}
                    >
                      {status === 'in_review' ? 'In Review' : status.charAt(0).toUpperCase() + status.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-neutral-200 bg-neutral-50 flex justify-end gap-3">
              <button
                onClick={() => setSelectedSubmission(null)}
                className="px-4 py-2 text-sm font-medium text-neutral-600 hover:bg-neutral-100 rounded-lg transition-colors"
              >
                Close
              </button>
              <button
                className="px-4 py-2 bg-brand-500 text-white text-sm font-medium rounded-lg hover:bg-brand-600 transition-colors"
              >
                Create Development
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
