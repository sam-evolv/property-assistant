import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

// GET - List all tenants with aggregated stats
export async function GET(request: NextRequest) {
  try {
    // Get all tenants
    const { data: tenants, error: tenantsError } = await supabaseAdmin
      .from('tenants')
      .select('*')
      .order('created_at', { ascending: false });

    if (tenantsError) {
      console.error('Error fetching tenants:', tenantsError);
      return NextResponse.json({ error: tenantsError.message }, { status: 500 });
    }

    // Get admin counts per tenant
    const { data: adminCounts, error: adminError } = await supabaseAdmin
      .from('admins')
      .select('tenant_id');

    // Get development counts per tenant
    const { data: developments, error: devError } = await supabaseAdmin
      .from('developments')
      .select('tenant_id');

    // Get unit counts per tenant
    const { data: units, error: unitError } = await supabaseAdmin
      .from('units')
      .select('tenant_id');

    // Aggregate counts
    const tenantsWithStats = tenants?.map(tenant => {
      const adminCount = adminCounts?.filter(a => a.tenant_id === tenant.id).length || 0;
      const developmentCount = developments?.filter(d => d.tenant_id === tenant.id).length || 0;
      const unitCount = units?.filter(u => u.tenant_id === tenant.id).length || 0;

      return {
        ...tenant,
        admin_count: adminCount,
        development_count: developmentCount,
        unit_count: unitCount
      };
    }) || [];

    return NextResponse.json({ tenants: tenantsWithStats });
  } catch (err) {
    console.error('Server error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST - Create a new tenant
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name } = body;

    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      return NextResponse.json({ error: 'Company name is required' }, { status: 400 });
    }

    // Check if tenant with same name already exists
    const { data: existing } = await supabaseAdmin
      .from('tenants')
      .select('id')
      .ilike('name', name.trim())
      .single();

    if (existing) {
      return NextResponse.json({ error: 'A developer with this name already exists' }, { status: 409 });
    }

    // Create new tenant
    const { data: tenant, error } = await supabaseAdmin
      .from('tenants')
      .insert({
        name: name.trim(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) {
      console.error('Error creating tenant:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ tenant }, { status: 201 });
  } catch (err) {
    console.error('Server error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
