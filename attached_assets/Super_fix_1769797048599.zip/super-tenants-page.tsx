'use client';

import { useState, useEffect } from 'react';
import { 
  Building2, 
  Plus, 
  Search, 
  Users, 
  Home,
  FileText,
  Loader2,
  RefreshCw,
  MoreVertical,
  Edit,
  Trash2,
  CheckCircle,
  XCircle
} from 'lucide-react';

interface Tenant {
  id: string;
  name: string;
  created_at: string;
  updated_at: string;
  // Aggregated data
  admin_count?: number;
  development_count?: number;
  unit_count?: number;
}

export default function TenantsPage() {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTenantName, setNewTenantName] = useState('');
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    fetchTenants();
  }, []);

  const fetchTenants = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/super/tenants');
      if (!res.ok) throw new Error('Failed to fetch tenants');
      const data = await res.json();
      setTenants(data.tenants || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load tenants');
    } finally {
      setLoading(false);
    }
  };

  const createTenant = async () => {
    if (!newTenantName.trim()) return;
    
    setCreating(true);
    try {
      const res = await fetch('/api/super/tenants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newTenantName.trim() })
      });
      
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to create tenant');
      }
      
      setNewTenantName('');
      setShowCreateModal(false);
      fetchTenants();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Failed to create tenant');
    } finally {
      setCreating(false);
    }
  };

  const filteredTenants = tenants.filter(t => 
    t.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-IE', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-900">Developer Companies</h1>
          <p className="text-neutral-500 mt-1">Manage developer accounts and their access</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={fetchTenants}
            className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-neutral-200 rounded-lg text-sm font-medium text-neutral-700 hover:bg-neutral-50 transition-all duration-150"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-brand-500 text-white rounded-lg text-sm font-medium hover:bg-brand-600 shadow-sm transition-all duration-150"
          >
            <Plus className="w-4 h-4" />
            Add Developer
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-brand-50 rounded-lg">
              <Building2 className="w-5 h-5 text-brand-600" />
            </div>
            <div>
              <p className="text-sm text-neutral-500">Total Developers</p>
              <p className="text-2xl font-semibold text-neutral-900">{tenants.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-50 rounded-lg">
              <Home className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm text-neutral-500">Total Developments</p>
              <p className="text-2xl font-semibold text-neutral-900">
                {tenants.reduce((sum, t) => sum + (t.development_count || 0), 0)}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-neutral-500">Total Users</p>
              <p className="text-2xl font-semibold text-neutral-900">
                {tenants.reduce((sum, t) => sum + (t.admin_count || 0), 0)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
        <input
          type="text"
          placeholder="Search developers..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none transition-all duration-150"
        />
      </div>

      {/* Loading State */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}

      {/* Empty State */}
      {!loading && !error && filteredTenants.length === 0 && (
        <div className="bg-white border border-gold-100 rounded-lg p-12 text-center">
          <Building2 className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-neutral-900">No developers yet</h3>
          <p className="text-neutral-500 mt-1 mb-4">Add your first developer company to get started</p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-brand-500 text-white rounded-lg text-sm font-medium hover:bg-brand-600 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Developer
          </button>
        </div>
      )}

      {/* Tenants Grid */}
      {!loading && !error && filteredTenants.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTenants.map((tenant) => (
            <div
              key={tenant.id}
              className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-brand-100 rounded-lg flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-brand-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-neutral-900">{tenant.name}</h3>
                    <p className="text-sm text-neutral-500">Added {formatDate(tenant.created_at)}</p>
                  </div>
                </div>
                <button className="p-1.5 text-neutral-400 hover:text-neutral-600 hover:bg-neutral-100 rounded-lg transition-colors">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </div>
              
              <div className="grid grid-cols-3 gap-3 pt-4 border-t border-neutral-100">
                <div className="text-center">
                  <p className="text-lg font-semibold text-neutral-900">{tenant.development_count || 0}</p>
                  <p className="text-xs text-neutral-500">Developments</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-semibold text-neutral-900">{tenant.unit_count || 0}</p>
                  <p className="text-xs text-neutral-500">Units</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-semibold text-neutral-900">{tenant.admin_count || 0}</p>
                  <p className="text-xs text-neutral-500">Users</p>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-neutral-100 flex gap-2">
                <button className="flex-1 px-3 py-1.5 text-sm font-medium text-neutral-600 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors">
                  View Details
                </button>
                <button className="flex-1 px-3 py-1.5 text-sm font-medium text-brand-600 bg-brand-50 hover:bg-brand-100 rounded-lg transition-colors">
                  Manage
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6 border-b border-neutral-200">
              <h2 className="text-xl font-semibold text-neutral-900">Add New Developer</h2>
              <p className="text-neutral-500 mt-1">Create a new developer company account</p>
            </div>
            
            <div className="p-6">
              <label className="block text-sm font-medium text-neutral-700 mb-2">
                Company Name *
              </label>
              <input
                type="text"
                value={newTenantName}
                onChange={(e) => setNewTenantName(e.target.value)}
                placeholder="e.g., Cairn Homes"
                className="w-full px-4 py-2.5 bg-white border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none transition-all duration-150"
                autoFocus
              />
            </div>

            <div className="p-6 border-t border-neutral-200 bg-neutral-50 rounded-b-xl flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowCreateModal(false);
                  setNewTenantName('');
                }}
                className="px-4 py-2 text-sm font-medium text-neutral-600 hover:bg-neutral-100 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={createTenant}
                disabled={!newTenantName.trim() || creating}
                className="px-4 py-2 bg-brand-500 text-white text-sm font-medium rounded-lg hover:bg-brand-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors inline-flex items-center gap-2"
              >
                {creating && <Loader2 className="w-4 h-4 animate-spin" />}
                {creating ? 'Creating...' : 'Create Developer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
