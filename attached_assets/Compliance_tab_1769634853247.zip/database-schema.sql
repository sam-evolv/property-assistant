-- ============================================
-- Compliance Documents Database Schema
-- ============================================
-- Run this in your Supabase SQL Editor
-- Prerequisites: You should already have 'developments' and 'units' tables

-- ============================================
-- 1. Document Types Table
-- ============================================
-- Defines what documents are required per development
-- e.g. "BER Certificate", "Fire Safety", etc.

CREATE TABLE IF NOT EXISTS compliance_document_types (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  development_id UUID NOT NULL REFERENCES developments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Certification',
  required BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  
  -- Ensure unique document type names per development
  UNIQUE(development_id, name)
);

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_compliance_doc_types_development 
  ON compliance_document_types(development_id);

-- ============================================
-- 2. Compliance Documents Table
-- ============================================
-- Links units to document types (junction table)
-- One record per unit + document type combination

CREATE TABLE IF NOT EXISTS compliance_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  document_type_id UUID NOT NULL REFERENCES compliance_document_types(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  
  -- Each unit can only have one compliance document per type
  UNIQUE(unit_id, document_type_id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_compliance_docs_unit 
  ON compliance_documents(unit_id);
CREATE INDEX IF NOT EXISTS idx_compliance_docs_type 
  ON compliance_documents(document_type_id);

-- ============================================
-- 3. Compliance Files Table
-- ============================================
-- Actual uploaded files (multiple files per document)

CREATE TABLE IF NOT EXISTS compliance_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  compliance_document_id UUID NOT NULL REFERENCES compliance_documents(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_url TEXT NOT NULL,
  file_size INTEGER,
  mime_type TEXT,
  uploaded_by UUID REFERENCES auth.users(id),
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_compliance_files_document 
  ON compliance_files(compliance_document_id);

-- ============================================
-- 4. Updated At Triggers
-- ============================================

-- Function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for compliance_document_types
DROP TRIGGER IF EXISTS update_compliance_document_types_updated_at ON compliance_document_types;
CREATE TRIGGER update_compliance_document_types_updated_at
  BEFORE UPDATE ON compliance_document_types
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger for compliance_documents
DROP TRIGGER IF EXISTS update_compliance_documents_updated_at ON compliance_documents;
CREATE TRIGGER update_compliance_documents_updated_at
  BEFORE UPDATE ON compliance_documents
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- 5. Row Level Security (RLS)
-- ============================================

-- Enable RLS on all tables
ALTER TABLE compliance_document_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE compliance_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE compliance_files ENABLE ROW LEVEL SECURITY;

-- Policy: Users can only access document types for developments they own
CREATE POLICY "Users can view own development document types"
  ON compliance_document_types FOR SELECT
  USING (
    development_id IN (
      SELECT id FROM developments WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own development document types"
  ON compliance_document_types FOR INSERT
  WITH CHECK (
    development_id IN (
      SELECT id FROM developments WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own development document types"
  ON compliance_document_types FOR UPDATE
  USING (
    development_id IN (
      SELECT id FROM developments WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own development document types"
  ON compliance_document_types FOR DELETE
  USING (
    development_id IN (
      SELECT id FROM developments WHERE owner_id = auth.uid()
    )
  );

-- Policy: Users can access compliance documents for their units
CREATE POLICY "Users can view own compliance documents"
  ON compliance_documents FOR SELECT
  USING (
    unit_id IN (
      SELECT u.id FROM units u
      JOIN developments d ON u.development_id = d.id
      WHERE d.owner_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own compliance documents"
  ON compliance_documents FOR INSERT
  WITH CHECK (
    unit_id IN (
      SELECT u.id FROM units u
      JOIN developments d ON u.development_id = d.id
      WHERE d.owner_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own compliance documents"
  ON compliance_documents FOR UPDATE
  USING (
    unit_id IN (
      SELECT u.id FROM units u
      JOIN developments d ON u.development_id = d.id
      WHERE d.owner_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own compliance documents"
  ON compliance_documents FOR DELETE
  USING (
    unit_id IN (
      SELECT u.id FROM units u
      JOIN developments d ON u.development_id = d.id
      WHERE d.owner_id = auth.uid()
    )
  );

-- Policy: Users can access compliance files for their documents
CREATE POLICY "Users can view own compliance files"
  ON compliance_files FOR SELECT
  USING (
    compliance_document_id IN (
      SELECT cd.id FROM compliance_documents cd
      JOIN units u ON cd.unit_id = u.id
      JOIN developments d ON u.development_id = d.id
      WHERE d.owner_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own compliance files"
  ON compliance_files FOR INSERT
  WITH CHECK (
    compliance_document_id IN (
      SELECT cd.id FROM compliance_documents cd
      JOIN units u ON cd.unit_id = u.id
      JOIN developments d ON u.development_id = d.id
      WHERE d.owner_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own compliance files"
  ON compliance_files FOR DELETE
  USING (
    compliance_document_id IN (
      SELECT cd.id FROM compliance_documents cd
      JOIN units u ON cd.unit_id = u.id
      JOIN developments d ON u.development_id = d.id
      WHERE d.owner_id = auth.uid()
    )
  );

-- ============================================
-- 6. Storage Bucket
-- ============================================
-- Run this separately or via Supabase dashboard

-- Create storage bucket for compliance documents
INSERT INTO storage.buckets (id, name, public)
VALUES ('compliance-documents', 'compliance-documents', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policy: Allow authenticated users to upload
CREATE POLICY "Authenticated users can upload compliance files"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'compliance-documents');

-- Storage policy: Allow public read access
CREATE POLICY "Public read access for compliance files"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'compliance-documents');

-- Storage policy: Allow users to delete their own uploads
CREATE POLICY "Users can delete own compliance files"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'compliance-documents');

-- ============================================
-- 7. Seed Default Document Types (Optional)
-- ============================================
-- Run this to add common document types to a development
-- Replace 'YOUR_DEVELOPMENT_ID' with actual UUID

/*
INSERT INTO compliance_document_types (development_id, name, category, required) VALUES
  ('YOUR_DEVELOPMENT_ID', 'BER Certificate', 'Certification', true),
  ('YOUR_DEVELOPMENT_ID', 'Fire Safety Certificate', 'Safety', true),
  ('YOUR_DEVELOPMENT_ID', 'Gas Safety Certificate', 'Safety', true),
  ('YOUR_DEVELOPMENT_ID', 'Electrical Certificate', 'Certification', true),
  ('YOUR_DEVELOPMENT_ID', 'HomeBond Registration', 'Registration', true),
  ('YOUR_DEVELOPMENT_ID', 'Planning Permission', 'Planning', true),
  ('YOUR_DEVELOPMENT_ID', 'Structural Warranty', 'Warranty', true)
ON CONFLICT (development_id, name) DO NOTHING;
*/
