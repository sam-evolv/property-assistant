# Compliance Documents - Replit Integration Guide

## Overview

This package provides a complete compliance documents management feature:
- View all units in a development with their compliance status
- Upload documents (single or multiple files per document type)
- "Apply to all units" option for estate-wide documents
- Add custom document types that apply to all units
- Progress tracking per unit

## File Structure

```
compliance-replit/
├── components/
│   ├── CompliancePage.tsx          # Main page component
│   └── compliance/
│       ├── index.ts                # Exports
│       ├── UnitAccordion.tsx       # Expandable unit card
│       ├── DocumentRow.tsx         # Single document row
│       ├── UploadModal.tsx         # File upload modal
│       ├── AddDocTypeModal.tsx     # Add document type modal
│       └── Badges.tsx              # TypeBadge, CategoryBadge
├── hooks/
│   ├── useComplianceDocuments.ts   # Main data hook
│   └── useDocumentTypes.ts         # Document types CRUD
├── types/
│   └── compliance.ts               # TypeScript interfaces
└── database-schema.sql             # Supabase schema
```

## Installation Steps

### 1. Run Database Schema

Open Supabase SQL Editor and run `database-schema.sql`. This creates:
- `compliance_document_types` - What documents are required
- `compliance_documents` - Links units to document types  
- `compliance_files` - Actual uploaded files
- Storage bucket `compliance-documents`
- RLS policies for security

### 2. Copy Component Files

Copy the following into your project:

```
src/
├── components/
│   ├── CompliancePage.tsx
│   └── compliance/
│       ├── index.ts
│       ├── UnitAccordion.tsx
│       ├── DocumentRow.tsx
│       ├── UploadModal.tsx
│       ├── AddDocTypeModal.tsx
│       └── Badges.tsx
├── hooks/
│   ├── useComplianceDocuments.ts
│   └── useDocumentTypes.ts
└── types/
    └── compliance.ts
```

### 3. Fix Import Paths

Update these imports in the hook files to match your project:

```typescript
// In useComplianceDocuments.ts and useDocumentTypes.ts
import { supabase } from '../lib/supabase'; // <- Adjust to your path
```

### 4. Add Route

Add the compliance page to your router:

```tsx
// In your router/pages
import { CompliancePage } from '@/components/CompliancePage';

// Route example
<Route 
  path="/developer/compliance" 
  element={
    <CompliancePage 
      developmentId={currentDevelopmentId} 
      developmentName="Longview Park"
    />
  } 
/>
```

### 5. Seed Default Document Types (Optional)

Add common document types for a development:

```sql
INSERT INTO compliance_document_types (development_id, name, category, required) VALUES
  ('YOUR_DEV_ID', 'BER Certificate', 'Certification', true),
  ('YOUR_DEV_ID', 'Fire Safety Certificate', 'Safety', true),
  ('YOUR_DEV_ID', 'Gas Safety Certificate', 'Safety', true),
  ('YOUR_DEV_ID', 'Electrical Certificate', 'Certification', true),
  ('YOUR_DEV_ID', 'HomeBond Registration', 'Registration', true);
```

## Dependencies

Make sure you have these installed:
- `lucide-react` - Icons
- `@supabase/supabase-js` - Supabase client

```bash
npm install lucide-react @supabase/supabase-js
```

## Styling

The components use Tailwind CSS with these specific colors:
- Primary gold: `amber-500` (#f59e0b)
- Hover gold: `amber-600` (#d97706)  
- Success: `emerald-500` (#10b981)
- Borders: `gray-200`, `gray-300`
- Text: `gray-900`, `gray-700`, `gray-500`

All styling matches the existing OpenHouse site design.

## Component Props

### CompliancePage

```tsx
interface CompliancePageProps {
  developmentId: string;      // Required - UUID of the development
  developmentName?: string;   // Optional - Display name
}
```

### UnitAccordion

```tsx
interface UnitAccordionProps {
  unit: Unit;
  isOpen: boolean;
  onToggle: () => void;
  onUpload: (doc: ComplianceDocument) => void;
}
```

## Database Tables

### compliance_document_types
| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key |
| development_id | UUID | FK to developments |
| name | TEXT | e.g. "BER Certificate" |
| category | TEXT | e.g. "Certification", "Safety" |
| required | BOOLEAN | Is this required? |

### compliance_documents
| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key |
| unit_id | UUID | FK to units |
| document_type_id | UUID | FK to compliance_document_types |

### compliance_files
| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key |
| compliance_document_id | UUID | FK to compliance_documents |
| file_name | TEXT | Original filename |
| file_url | TEXT | Supabase Storage URL |
| file_size | INTEGER | Size in bytes |
| mime_type | TEXT | e.g. "application/pdf" |
| uploaded_at | TIMESTAMPTZ | When uploaded |

## Key Features

### 1. Auto-sorting
- Units missing documents appear first
- Within each unit, missing documents appear first

### 2. Apply to All Units
- When uploading, check "Apply to all units"
- The file uploads to every unit in the development

### 3. Multiple Files
- Each document type can have multiple files
- Click "+" to add more files to an existing document

### 4. Custom Document Types
- Click "Add Document Type" to create new requirements
- Automatically added to all units in the development

## Troubleshooting

### Files not uploading
1. Check the `compliance-documents` storage bucket exists
2. Verify storage policies are set up
3. Check browser console for errors

### Documents not showing
1. Verify `compliance_document_types` has entries for the development
2. Check the development_id is correct
3. Verify RLS policies aren't blocking access

### "Permission denied" errors
1. Make sure user is authenticated
2. Check the user owns the development
3. Verify RLS policies in `database-schema.sql`

## Questions?

The code is designed to drop in and work. If you need adjustments:
1. Check import paths match your project structure
2. Verify Supabase client is exported correctly
3. Make sure all dependencies are installed
