'use client';

import { useState, useEffect } from 'react';
import { 
  Home, 
  Search, 
  Filter, 
  Download, 
  Upload,
  RefreshCw,
  Loader2,
  User,
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle,
  Phone,
  Mail,
  MapPin,
  ChevronDown,
  ChevronRight,
  FileText,
  QrCode,
  MoreVertical,
  Eye,
  Edit,
  ExternalLink
} from 'lucide-react';

interface Unit {
  id: string;
  address: string;
  unit_number: string;
  unit_type: string;
  development_id: string;
  development_name: string;
  tenant_name: string;
  // Purchaser info
  purchaser_name: string | null;
  purchaser_email: string | null;
  purchaser_phone: string | null;
  // Status
  status: 'available' | 'reserved' | 'sold' | 'handed_over';
  handover_date: string | null;
  handover_scheduled: boolean;
  // Metadata
  created_at: string;
  last_activity: string | null;
  documents_count: number;
  questions_count: number;
}

interface FilterState {
  development: string;
  status: string;
  search: string;
}

export default function UnitsExplorerPage() {
  const [units, setUnits] = useState<Unit[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [filters, setFilters] = useState<FilterState>({
    development: 'all',
    status: 'all',
    search: ''
  });
  const [developments, setDevelopments] = useState<Array<{ id: string; name: string }>>([]);

  // Stats
  const stats = {
    total: units.length,
    withPurchaser: units.filter(u => u.purchaser_name).length,
    handedOver: units.filter(u => u.status === 'handed_over').length,
    pending: units.filter(u => u.status === 'sold' && !u.handover_date).length
  };

  useEffect(() => {
    fetchUnits();
    fetchDevelopments();
  }, []);

  const fetchUnits = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/super/units');
      if (!res.ok) throw new Error('Failed to load');
      const data = await res.json();
      setUnits(data.units || []);
    } catch (err) {
      setError('Failed to load units');
    } finally {
      setLoading(false);
    }
  };

  const fetchDevelopments = async () => {
    try {
      const res = await fetch('/api/super/developments');
      if (!res.ok) return;
      const data = await res.json();
      setDevelopments(data.developments?.map((d: any) => ({ id: d.id, name: d.name })) || []);
    } catch {}
  };

  const filteredUnits = units.filter(unit => {
    if (filters.development !== 'all' && unit.development_id !== filters.development) return false;
    if (filters.status !== 'all' && unit.status !== filters.status) return false;
    if (filters.search) {
      const search = filters.search.toLowerCase();
      return (
        unit.address?.toLowerCase().includes(search) ||
        unit.unit_number?.toLowerCase().includes(search) ||
        unit.purchaser_name?.toLowerCase().includes(search) ||
        unit.purchaser_email?.toLowerCase().includes(search)
      );
    }
    return true;
  });

  const statusConfig = {
    available: { label: 'Available', color: 'bg-neutral-100 text-neutral-600', dot: 'bg-neutral-400' },
    reserved: { label: 'Reserved', color: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500' },
    sold: { label: 'Sold', color: 'bg-blue-100 text-blue-700', dot: 'bg-blue-500' },
    handed_over: { label: 'Handed Over', color: 'bg-emerald-100 text-emerald-700', dot: 'bg-emerald-500' }
  };

  const formatDate = (date: string | null) => {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('en-IE', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-900">Units Explorer</h1>
          <p className="text-neutral-500 mt-1">Manage all units across developments</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-neutral-200 rounded-lg text-sm font-medium text-neutral-700 hover:bg-neutral-50 transition-all">
            <Download className="w-4 h-4" />
            Export
          </button>
          <button className="inline-flex items-center gap-2 px-4 py-2 bg-brand-500 text-white rounded-lg text-sm font-medium hover:bg-brand-600 shadow-sm transition-all">
            <Upload className="w-4 h-4" />
            Import Units
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
          <p className="text-sm text-neutral-500">Total Units</p>
          <p className="text-2xl font-bold text-neutral-900 mt-1">{stats.total}</p>
        </div>
        <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
          <p className="text-sm text-neutral-500">With Purchaser</p>
          <p className="text-2xl font-bold text-neutral-900 mt-1">{stats.withPurchaser}</p>
          <p className="text-xs text-neutral-400">{stats.total > 0 ? Math.round(stats.withPurchaser / stats.total * 100) : 0}% assigned</p>
        </div>
        <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
          <p className="text-sm text-neutral-500">Handed Over</p>
          <p className="text-2xl font-bold text-emerald-600 mt-1">{stats.handedOver}</p>
        </div>
        <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
          <p className="text-sm text-neutral-500">Pending Handover</p>
          <p className="text-2xl font-bold text-amber-600 mt-1">{stats.pending}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <input
              type="text"
              placeholder="Search by address, unit number, or purchaser..."
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              className="w-full pl-10 pr-4 py-2.5 bg-neutral-50 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none transition-all"
            />
          </div>

          {/* Development Filter */}
          <select
            value={filters.development}
            onChange={(e) => setFilters({ ...filters, development: e.target.value })}
            className="px-4 py-2.5 bg-white border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none"
          >
            <option value="all">All Developments</option>
            {developments.map(d => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value })}
            className="px-4 py-2.5 bg-white border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="available">Available</option>
            <option value="reserved">Reserved</option>
            <option value="sold">Sold</option>
            <option value="handed_over">Handed Over</option>
          </select>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}

      {/* Units Table */}
      {!loading && !error && (
        <div className="bg-white border border-gold-100 rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-neutral-100 flex items-center justify-between">
            <div>
              <span className="font-medium text-neutral-900">{filteredUnits.length}</span>
              <span className="text-neutral-500 ml-1">units found</span>
            </div>
            <button
              onClick={fetchUnits}
              className="p-2 text-neutral-400 hover:text-neutral-600 hover:bg-neutral-100 rounded-lg transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          {filteredUnits.length === 0 ? (
            <div className="p-12 text-center">
              <Home className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
              <p className="text-neutral-500">No units found</p>
            </div>
          ) : (
            <div className="divide-y divide-neutral-100">
              {filteredUnits.map((unit) => {
                const isExpanded = expandedId === unit.id;
                const status = statusConfig[unit.status] || statusConfig.available;

                return (
                  <div key={unit.id}>
                    {/* Main Row */}
                    <div 
                      className="px-6 py-4 hover:bg-neutral-50 transition-colors cursor-pointer"
                      onClick={() => setExpandedId(isExpanded ? null : unit.id)}
                    >
                      <div className="flex items-center gap-4">
                        {/* Expand Icon */}
                        <button className="p-1 text-neutral-400">
                          {isExpanded ? (
                            <ChevronDown className="w-4 h-4" />
                          ) : (
                            <ChevronRight className="w-4 h-4" />
                          )}
                        </button>

                        {/* Unit Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-neutral-900">{unit.unit_number || unit.address}</span>
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${status.color}`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${status.dot}`} />
                              {status.label}
                            </span>
                          </div>
                          <p className="text-sm text-neutral-500 mt-0.5">{unit.development_name}</p>
                        </div>

                        {/* Purchaser */}
                        <div className="hidden md:block w-48">
                          {unit.purchaser_name ? (
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 bg-brand-100 rounded-full flex items-center justify-center">
                                <User className="w-4 h-4 text-brand-600" />
                              </div>
                              <div className="min-w-0">
                                <p className="text-sm font-medium text-neutral-900 truncate">{unit.purchaser_name}</p>
                                <p className="text-xs text-neutral-500 truncate">{unit.purchaser_email}</p>
                              </div>
                            </div>
                          ) : (
                            <span className="text-sm text-neutral-400">No purchaser</span>
                          )}
                        </div>

                        {/* Handover Date */}
                        <div className="hidden lg:block w-32 text-right">
                          {unit.handover_date ? (
                            <div>
                              <p className="text-sm font-medium text-neutral-900">{formatDate(unit.handover_date)}</p>
                              <p className="text-xs text-neutral-500">Handover</p>
                            </div>
                          ) : (
                            <span className="text-sm text-neutral-400">Not scheduled</span>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2">
                          <button 
                            className="p-2 text-neutral-400 hover:text-brand-600 hover:bg-brand-50 rounded-lg transition-colors"
                            onClick={(e) => {
                              e.stopPropagation();
                              // Open unit detail
                            }}
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button 
                            className="p-2 text-neutral-400 hover:text-neutral-600 hover:bg-neutral-100 rounded-lg transition-colors"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Expanded Details */}
                    {isExpanded && (
                      <div className="px-6 py-4 bg-neutral-50 border-t border-neutral-100">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pl-9">
                          {/* Contact Details */}
                          <div className="space-y-3">
                            <h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Contact</h4>
                            {unit.purchaser_name ? (
                              <div className="space-y-2">
                                <div className="flex items-center gap-2 text-sm">
                                  <User className="w-4 h-4 text-neutral-400" />
                                  <span className="text-neutral-900">{unit.purchaser_name}</span>
                                </div>
                                {unit.purchaser_email && (
                                  <a href={`mailto:${unit.purchaser_email}`} className="flex items-center gap-2 text-sm text-brand-600 hover:text-brand-700">
                                    <Mail className="w-4 h-4" />
                                    <span>{unit.purchaser_email}</span>
                                  </a>
                                )}
                                {unit.purchaser_phone && (
                                  <a href={`tel:${unit.purchaser_phone}`} className="flex items-center gap-2 text-sm text-brand-600 hover:text-brand-700">
                                    <Phone className="w-4 h-4" />
                                    <span>{unit.purchaser_phone}</span>
                                  </a>
                                )}
                              </div>
                            ) : (
                              <p className="text-sm text-neutral-400">No purchaser assigned</p>
                            )}
                          </div>

                          {/* Timeline */}
                          <div className="space-y-3">
                            <h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Timeline</h4>
                            <div className="space-y-2">
                              <div className="flex items-center gap-2 text-sm">
                                <Calendar className="w-4 h-4 text-neutral-400" />
                                <span className="text-neutral-500">Created:</span>
                                <span className="text-neutral-900">{formatDate(unit.created_at)}</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm">
                                <Clock className="w-4 h-4 text-neutral-400" />
                                <span className="text-neutral-500">Handover:</span>
                                <span className={unit.handover_date ? 'text-neutral-900' : 'text-neutral-400'}>
                                  {formatDate(unit.handover_date) || 'Not scheduled'}
                                </span>
                              </div>
                              {unit.last_activity && (
                                <div className="flex items-center gap-2 text-sm">
                                  <CheckCircle className="w-4 h-4 text-neutral-400" />
                                  <span className="text-neutral-500">Last activity:</span>
                                  <span className="text-neutral-900">{formatDate(unit.last_activity)}</span>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Quick Stats & Actions */}
                          <div className="space-y-3">
                            <h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Activity</h4>
                            <div className="flex gap-4">
                              <div className="text-center">
                                <p className="text-xl font-bold text-neutral-900">{unit.documents_count || 0}</p>
                                <p className="text-xs text-neutral-500">Documents</p>
                              </div>
                              <div className="text-center">
                                <p className="text-xl font-bold text-neutral-900">{unit.questions_count || 0}</p>
                                <p className="text-xs text-neutral-500">Questions</p>
                              </div>
                            </div>
                            <div className="flex gap-2 pt-2">
                              <button className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-white border border-neutral-200 rounded-lg text-xs font-medium text-neutral-700 hover:bg-neutral-50 transition-colors">
                                <FileText className="w-3.5 h-3.5" />
                                Documents
                              </button>
                              <button className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-white border border-neutral-200 rounded-lg text-xs font-medium text-neutral-700 hover:bg-neutral-50 transition-colors">
                                <QrCode className="w-3.5 h-3.5" />
                                QR Code
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
