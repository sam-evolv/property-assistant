import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function GET(request: NextRequest) {
  try {
    // Get all units with purchaser information
    // In this system, "homeowners" are purchasers who have been assigned to units
    const { data: units, error } = await supabaseAdmin
      .from('units')
      .select(`
        id,
        address,
        unit_number,
        unit_type,
        purchaser_name,
        purchaser_email,
        purchaser_phone,
        handover_date,
        status,
        created_at,
        development_id,
        tenant_id,
        developments(name),
        tenants(name)
      `)
      .not('purchaser_name', 'is', null)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching homeowners:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    // Transform units into homeowner records
    const homeowners = (units || []).map(unit => {
      // Determine status based on handover and last activity
      let status: 'active' | 'inactive' | 'pending' = 'pending';
      
      if (unit.handover_date) {
        const handoverDate = new Date(unit.handover_date);
        if (handoverDate <= new Date()) {
          status = 'active'; // Handed over, assume active
        }
      }

      return {
        id: unit.id,
        name: unit.purchaser_name,
        email: unit.purchaser_email,
        phone: unit.purchaser_phone,
        unit_id: unit.id,
        unit_address: unit.address,
        unit_number: unit.unit_number,
        development_name: (unit as any).developments?.name || 'Unknown',
        tenant_name: (unit as any).tenants?.name || 'Unknown',
        last_login: null, // Would come from auth/sessions table
        questions_asked: 0, // Would come from messages table
        documents_viewed: 0, // Would come from analytics
        status,
        handover_date: unit.handover_date,
        created_at: unit.created_at
      };
    });

    return NextResponse.json({ homeowners });
  } catch (err) {
    console.error('Server error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
