'use client';

import { useState, useEffect } from 'react';
import { 
  MessageSquare, 
  Users, 
  TrendingUp, 
  TrendingDown,
  Clock,
  AlertCircle,
  CheckCircle,
  Search,
  Filter,
  Download,
  RefreshCw,
  Loader2,
  BarChart3,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  HelpCircle,
  Lightbulb
} from 'lucide-react';

interface AnalyticsData {
  summary: {
    totalQuestions: number;
    questionsThisWeek: number;
    weekOverWeekChange: number;
    avgResponseTime: string;
    satisfactionRate: number;
    unansweredCount: number;
  };
  topQuestions: Array<{
    question: string;
    count: number;
    development: string;
  }>;
  questionsByDevelopment: Array<{
    name: string;
    count: number;
    percentage: number;
  }>;
  questionsByCategory: Array<{
    category: string;
    count: number;
    color: string;
  }>;
  recentQuestions: Array<{
    id: string;
    question: string;
    development: string;
    timestamp: string;
    answered: boolean;
  }>;
  knowledgeGaps: Array<{
    topic: string;
    frequency: number;
    suggestion: string;
  }>;
}

export default function PlatformAnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');
  const [activeTab, setActiveTab] = useState<'overview' | 'questions' | 'gaps'>('overview');

  useEffect(() => {
    fetchAnalytics();
  }, [timeRange]);

  const fetchAnalytics = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/super/analytics?range=${timeRange}`);
      if (!res.ok) throw new Error('Failed to load analytics');
      const result = await res.json();
      setData(result);
    } catch (err) {
      setError('Unable to load analytics. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
        <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-2" />
        <p className="text-red-700">{error}</p>
        <button 
          onClick={fetchAnalytics}
          className="mt-3 px-4 py-2 bg-red-100 text-red-700 rounded-lg text-sm font-medium hover:bg-red-200 transition-colors"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-900">Platform Analytics</h1>
          <p className="text-neutral-500 mt-1">Understand how homeowners use the AI assistant</p>
        </div>
        <div className="flex items-center gap-3">
          {/* Time Range Selector */}
          <div className="flex bg-neutral-100 rounded-lg p-1">
            {[
              { value: '7d', label: '7 days' },
              { value: '30d', label: '30 days' },
              { value: '90d', label: '90 days' }
            ].map((option) => (
              <button
                key={option.value}
                onClick={() => setTimeRange(option.value as any)}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-all ${
                  timeRange === option.value
                    ? 'bg-white text-neutral-900 shadow-sm'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
          <button
            onClick={fetchAnalytics}
            className="p-2 bg-white border border-neutral-200 rounded-lg text-neutral-600 hover:bg-neutral-50 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <MessageSquare className="w-5 h-5 text-brand-500" />
            {data?.summary.weekOverWeekChange !== undefined && (
              <span className={`flex items-center text-xs font-medium ${
                data.summary.weekOverWeekChange >= 0 ? 'text-emerald-600' : 'text-red-600'
              }`}>
                {data.summary.weekOverWeekChange >= 0 ? (
                  <ArrowUpRight className="w-3 h-3 mr-0.5" />
                ) : (
                  <ArrowDownRight className="w-3 h-3 mr-0.5" />
                )}
                {Math.abs(data.summary.weekOverWeekChange)}%
              </span>
            )}
          </div>
          <p className="text-3xl font-bold text-neutral-900">{data?.summary.totalQuestions || 0}</p>
          <p className="text-sm text-neutral-500">Total Questions</p>
        </div>

        <div className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <Clock className="w-5 h-5 text-blue-500" />
          </div>
          <p className="text-3xl font-bold text-neutral-900">{data?.summary.avgResponseTime || '< 1s'}</p>
          <p className="text-sm text-neutral-500">Avg Response Time</p>
        </div>

        <div className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle className="w-5 h-5 text-emerald-500" />
          </div>
          <p className="text-3xl font-bold text-neutral-900">{data?.summary.satisfactionRate || 0}%</p>
          <p className="text-sm text-neutral-500">Answer Accuracy</p>
        </div>

        <div className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <HelpCircle className="w-5 h-5 text-amber-500" />
          </div>
          <p className="text-3xl font-bold text-neutral-900">{data?.summary.unansweredCount || 0}</p>
          <p className="text-sm text-neutral-500">Need Attention</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-neutral-200">
        <div className="flex gap-6">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'questions', label: 'Recent Questions', icon: MessageSquare },
            { id: 'gaps', label: 'Knowledge Gaps', icon: Lightbulb }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 pb-3 px-1 border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-brand-500 text-brand-600'
                    : 'border-transparent text-neutral-500 hover:text-neutral-700'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-sm font-medium">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Top Questions */}
          <div className="bg-white border border-gold-100 rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold text-neutral-900 mb-4">Most Asked Questions</h3>
            {data?.topQuestions && data.topQuestions.length > 0 ? (
              <div className="space-y-3">
                {data.topQuestions.slice(0, 5).map((item, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-brand-100 text-brand-700 rounded-full text-xs font-medium flex items-center justify-center">
                      {i + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-neutral-900 line-clamp-2">{item.question}</p>
                      <p className="text-xs text-neutral-500 mt-0.5">{item.development} · {item.count} times</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-neutral-500 text-center py-8">No questions yet</p>
            )}
          </div>

          {/* Questions by Development */}
          <div className="bg-white border border-gold-100 rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold text-neutral-900 mb-4">Questions by Development</h3>
            {data?.questionsByDevelopment && data.questionsByDevelopment.length > 0 ? (
              <div className="space-y-3">
                {data.questionsByDevelopment.map((item, i) => (
                  <div key={i}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-neutral-700">{item.name}</span>
                      <span className="text-sm font-medium text-neutral-900">{item.count}</span>
                    </div>
                    <div className="h-2 bg-neutral-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-brand-500 rounded-full transition-all duration-500"
                        style={{ width: `${item.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-neutral-500 text-center py-8">No data available</p>
            )}
          </div>
        </div>
      )}

      {activeTab === 'questions' && (
        <div className="bg-white border border-gold-100 rounded-lg shadow-sm overflow-hidden">
          <div className="p-4 border-b border-neutral-100">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
              <input
                type="text"
                placeholder="Search questions..."
                className="w-full pl-10 pr-4 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none transition-all"
              />
            </div>
          </div>
          
          {data?.recentQuestions && data.recentQuestions.length > 0 ? (
            <div className="divide-y divide-neutral-100">
              {data.recentQuestions.map((q) => (
                <div key={q.id} className="p-4 hover:bg-neutral-50 transition-colors">
                  <div className="flex items-start gap-3">
                    <div className={`p-1.5 rounded-full ${q.answered ? 'bg-emerald-100' : 'bg-amber-100'}`}>
                      {q.answered ? (
                        <CheckCircle className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <HelpCircle className="w-4 h-4 text-amber-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-neutral-900">{q.question}</p>
                      <p className="text-xs text-neutral-500 mt-1">
                        {q.development} · {new Date(q.timestamp).toLocaleDateString('en-IE', { 
                          day: 'numeric', 
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-12 text-center">
              <MessageSquare className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
              <p className="text-sm text-neutral-500">No questions in this period</p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'gaps' && (
        <div className="space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Lightbulb className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-900">Knowledge Gap Detection</h4>
                <p className="text-sm text-blue-700 mt-1">
                  These topics are frequently asked but may not be fully covered in the property documentation.
                  Consider adding more information to improve answer accuracy.
                </p>
              </div>
            </div>
          </div>

          {data?.knowledgeGaps && data.knowledgeGaps.length > 0 ? (
            <div className="bg-white border border-gold-100 rounded-lg shadow-sm divide-y divide-neutral-100">
              {data.knowledgeGaps.map((gap, i) => (
                <div key={i} className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-medium text-neutral-900">{gap.topic}</h4>
                      <p className="text-sm text-neutral-500 mt-1">{gap.suggestion}</p>
                    </div>
                    <span className="text-xs font-medium text-amber-600 bg-amber-50 px-2 py-1 rounded-full">
                      {gap.frequency} questions
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white border border-gold-100 rounded-lg p-12 text-center">
              <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
              <p className="text-sm text-neutral-500">No knowledge gaps detected</p>
              <p className="text-xs text-neutral-400 mt-1">Your documentation is covering questions well!</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
