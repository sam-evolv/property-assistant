import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function GET(request: NextRequest) {
  try {
    // Get tenant counts
    const { count: tenantCount } = await supabaseAdmin
      .from('tenants')
      .select('*', { count: 'exact', head: true });

    // Get new tenants this month
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);
    
    const { count: newTenantsCount } = await supabaseAdmin
      .from('tenants')
      .select('*', { count: 'exact', head: true })
      .gte('created_at', startOfMonth.toISOString());

    // Get development counts
    const { data: developments } = await supabaseAdmin
      .from('developments')
      .select('id, status');
    
    const devTotal = developments?.length || 0;
    const devActive = developments?.filter(d => d.status === 'active').length || 0;

    // Get unit counts
    const { data: units } = await supabaseAdmin
      .from('units')
      .select('id, purchaser_name, handover_date');
    
    const unitTotal = units?.length || 0;
    const unitWithPurchaser = units?.filter(u => u.purchaser_name).length || 0;
    const unitHandedOver = units?.filter(u => u.handover_date && new Date(u.handover_date) <= new Date()).length || 0;

    // Get question counts (from messages table if exists)
    let questionTotal = 0;
    let questionThisWeek = 0;
    let questionUnanswered = 0;
    
    try {
      const { count: totalQ } = await supabaseAdmin
        .from('messages')
        .select('*', { count: 'exact', head: true })
        .eq('role', 'user');
      questionTotal = totalQ || 0;

      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      
      const { count: weekQ } = await supabaseAdmin
        .from('messages')
        .select('*', { count: 'exact', head: true })
        .eq('role', 'user')
        .gte('created_at', weekAgo.toISOString());
      questionThisWeek = weekQ || 0;
    } catch {
      // Messages table might not exist
    }

    // Get onboarding submission counts
    const { data: submissions } = await supabaseAdmin
      .from('onboarding_submissions')
      .select('status');
    
    const pendingCount = submissions?.filter(s => s.status === 'pending').length || 0;
    const inReviewCount = submissions?.filter(s => s.status === 'in_review').length || 0;

    // Get recent activity
    const recentActivity: any[] = [];
    
    // Recent onboarding submissions
    const { data: recentSubmissions } = await supabaseAdmin
      .from('onboarding_submissions')
      .select('id, development_name, developer_email, created_at')
      .order('created_at', { ascending: false })
      .limit(3);
    
    recentSubmissions?.forEach(s => {
      recentActivity.push({
        id: s.id,
        type: 'onboarding',
        title: `New submission: ${s.development_name}`,
        subtitle: s.developer_email,
        timestamp: s.created_at
      });
    });

    // Recent units added
    const { data: recentUnits } = await supabaseAdmin
      .from('units')
      .select('id, address, created_at')
      .order('created_at', { ascending: false })
      .limit(2);
    
    recentUnits?.forEach(u => {
      recentActivity.push({
        id: u.id,
        type: 'signup',
        title: `Unit added: ${u.address}`,
        subtitle: 'New unit registered',
        timestamp: u.created_at
      });
    });

    // Sort by timestamp
    recentActivity.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    return NextResponse.json({
      stats: {
        tenants: {
          total: tenantCount || 0,
          newThisMonth: newTenantsCount || 0
        },
        developments: {
          total: devTotal,
          active: devActive
        },
        units: {
          total: unitTotal,
          withPurchaser: unitWithPurchaser,
          handedOver: unitHandedOver
        },
        homeowners: {
          total: 0, // Will be populated when homeowners table exists
          activeThisWeek: 0
        },
        questions: {
          total: questionTotal,
          thisWeek: questionThisWeek,
          unanswered: questionUnanswered
        },
        onboarding: {
          pending: pendingCount,
          inReview: inReviewCount
        }
      },
      recentActivity: recentActivity.slice(0, 5)
    });
  } catch (err) {
    console.error('Dashboard stats error:', err);
    return NextResponse.json({ error: 'Failed to load dashboard stats' }, { status: 500 });
  }
}
