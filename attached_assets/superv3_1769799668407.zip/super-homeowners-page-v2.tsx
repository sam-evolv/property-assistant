'use client';

import { useState, useEffect } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  Download, 
  RefreshCw,
  Loader2,
  User,
  Mail,
  Phone,
  Home,
  Calendar,
  MessageSquare,
  FileText,
  Clock,
  CheckCircle,
  ExternalLink,
  MoreVertical,
  ChevronDown,
  ChevronRight,
  Activity
} from 'lucide-react';

interface Homeowner {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  // Unit info
  unit_id: string;
  unit_address: string;
  unit_number: string;
  development_name: string;
  tenant_name: string;
  // Engagement
  last_login: string | null;
  questions_asked: number;
  documents_viewed: number;
  // Status
  status: 'active' | 'inactive' | 'pending';
  handover_date: string | null;
  created_at: string;
}

export default function HomeownersPage() {
  const [homeowners, setHomeowners] = useState<Homeowner[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive' | 'pending'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    fetchHomeowners();
  }, []);

  const fetchHomeowners = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/super/homeowners');
      if (!res.ok) throw new Error('Failed to load homeowners');
      const data = await res.json();
      setHomeowners(data.homeowners || []);
    } catch (err) {
      setError('Failed to load homeowners. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const filteredHomeowners = homeowners.filter(h => {
    if (statusFilter !== 'all' && h.status !== statusFilter) return false;
    if (search) {
      const s = search.toLowerCase();
      return (
        h.name?.toLowerCase().includes(s) ||
        h.email?.toLowerCase().includes(s) ||
        h.unit_address?.toLowerCase().includes(s) ||
        h.development_name?.toLowerCase().includes(s)
      );
    }
    return true;
  });

  const stats = {
    total: homeowners.length,
    active: homeowners.filter(h => h.status === 'active').length,
    inactive: homeowners.filter(h => h.status === 'inactive').length,
    pending: homeowners.filter(h => h.status === 'pending').length
  };

  const statusConfig = {
    active: { label: 'Active', color: 'bg-emerald-100 text-emerald-700', dot: 'bg-emerald-500' },
    inactive: { label: 'Inactive', color: 'bg-neutral-100 text-neutral-600', dot: 'bg-neutral-400' },
    pending: { label: 'Pending', color: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500' }
  };

  const formatDate = (date: string | null) => {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('en-IE', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  const formatLastSeen = (date: string | null) => {
    if (!date) return 'Never';
    const diff = Date.now() - new Date(date).getTime();
    const days = Math.floor(diff / 86400000);
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    if (days < 30) return `${Math.floor(days / 7)} weeks ago`;
    return formatDate(date);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-900">Homeowners</h1>
          <p className="text-neutral-500 mt-1">Manage homeowner accounts and engagement</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-neutral-200 rounded-lg text-sm font-medium text-neutral-700 hover:bg-neutral-50 transition-all">
            <Download className="w-4 h-4" />
            Export
          </button>
          <button
            onClick={fetchHomeowners}
            className="p-2 bg-white border border-neutral-200 rounded-lg text-neutral-600 hover:bg-neutral-50 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-brand-50 rounded-lg">
              <Users className="w-5 h-5 text-brand-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-neutral-900">{stats.total}</p>
              <p className="text-sm text-neutral-500">Total Homeowners</p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-50 rounded-lg">
              <Activity className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-emerald-600">{stats.active}</p>
              <p className="text-sm text-neutral-500">Active (7 days)</p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-neutral-100 rounded-lg">
              <Clock className="w-5 h-5 text-neutral-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-neutral-600">{stats.inactive}</p>
              <p className="text-sm text-neutral-500">Inactive</p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-50 rounded-lg">
              <User className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-amber-600">{stats.pending}</p>
              <p className="text-sm text-neutral-500">Pending Setup</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border border-gold-100 rounded-lg p-4 shadow-sm">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <input
              type="text"
              placeholder="Search by name, email, or address..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-neutral-50 border border-neutral-200 rounded-lg text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none transition-all"
            />
          </div>
          <div className="flex gap-2">
            {(['all', 'active', 'inactive', 'pending'] as const).map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  statusFilter === status
                    ? 'bg-neutral-900 text-white'
                    : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                {status === 'all' ? 'All' : status.charAt(0).toUpperCase() + status.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <p className="text-red-700">{error}</p>
          <button
            onClick={fetchHomeowners}
            className="mt-3 px-4 py-2 bg-red-100 text-red-700 rounded-lg text-sm font-medium hover:bg-red-200 transition-colors"
          >
            Try Again
          </button>
        </div>
      )}

      {/* Homeowners List */}
      {!loading && !error && (
        <div className="bg-white border border-gold-100 rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-neutral-100">
            <span className="font-medium text-neutral-900">{filteredHomeowners.length}</span>
            <span className="text-neutral-500 ml-1">homeowners found</span>
          </div>

          {filteredHomeowners.length === 0 ? (
            <div className="p-12 text-center">
              <Users className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
              <p className="text-neutral-500">No homeowners found</p>
            </div>
          ) : (
            <div className="divide-y divide-neutral-100">
              {filteredHomeowners.map((homeowner) => {
                const isExpanded = expandedId === homeowner.id;
                const status = statusConfig[homeowner.status] || statusConfig.pending;

                return (
                  <div key={homeowner.id}>
                    <div
                      className="px-6 py-4 hover:bg-neutral-50 transition-colors cursor-pointer"
                      onClick={() => setExpandedId(isExpanded ? null : homeowner.id)}
                    >
                      <div className="flex items-center gap-4">
                        {/* Expand */}
                        <button className="p-1 text-neutral-400">
                          {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                        </button>

                        {/* Avatar & Name */}
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className="w-10 h-10 bg-brand-100 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-brand-700 font-semibold text-sm">
                              {homeowner.name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || '?'}
                            </span>
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-medium text-neutral-900 truncate">{homeowner.name}</p>
                              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${status.color}`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${status.dot}`} />
                                {status.label}
                              </span>
                            </div>
                            <p className="text-sm text-neutral-500 truncate">{homeowner.email}</p>
                          </div>
                        </div>

                        {/* Property */}
                        <div className="hidden md:block w-48">
                          <p className="text-sm font-medium text-neutral-900 truncate">{homeowner.unit_number || homeowner.unit_address}</p>
                          <p className="text-xs text-neutral-500 truncate">{homeowner.development_name}</p>
                        </div>

                        {/* Last Seen */}
                        <div className="hidden lg:block w-24 text-right">
                          <p className="text-sm text-neutral-500">{formatLastSeen(homeowner.last_login)}</p>
                        </div>

                        {/* Engagement */}
                        <div className="hidden lg:flex items-center gap-4 w-32">
                          <div className="text-center">
                            <p className="text-sm font-medium text-neutral-900">{homeowner.questions_asked}</p>
                            <p className="text-xs text-neutral-500">Q&A</p>
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-medium text-neutral-900">{homeowner.documents_viewed}</p>
                            <p className="text-xs text-neutral-500">Docs</p>
                          </div>
                        </div>

                        {/* Actions */}
                        <button
                          className="p-2 text-neutral-400 hover:text-neutral-600 hover:bg-neutral-100 rounded-lg transition-colors"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Expanded */}
                    {isExpanded && (
                      <div className="px-6 py-4 bg-neutral-50 border-t border-neutral-100">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pl-9">
                          {/* Contact */}
                          <div className="space-y-3">
                            <h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Contact</h4>
                            <div className="space-y-2">
                              <a href={`mailto:${homeowner.email}`} className="flex items-center gap-2 text-sm text-brand-600 hover:text-brand-700">
                                <Mail className="w-4 h-4" />
                                {homeowner.email}
                              </a>
                              {homeowner.phone && (
                                <a href={`tel:${homeowner.phone}`} className="flex items-center gap-2 text-sm text-brand-600 hover:text-brand-700">
                                  <Phone className="w-4 h-4" />
                                  {homeowner.phone}
                                </a>
                              )}
                            </div>
                          </div>

                          {/* Property */}
                          <div className="space-y-3">
                            <h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Property</h4>
                            <div className="space-y-2 text-sm">
                              <div className="flex items-center gap-2">
                                <Home className="w-4 h-4 text-neutral-400" />
                                <span className="text-neutral-900">{homeowner.unit_address}</span>
                              </div>
                              <p className="text-neutral-500 pl-6">{homeowner.development_name}</p>
                              {homeowner.handover_date && (
                                <div className="flex items-center gap-2">
                                  <Calendar className="w-4 h-4 text-neutral-400" />
                                  <span className="text-neutral-500">Handover:</span>
                                  <span className="text-neutral-900">{formatDate(homeowner.handover_date)}</span>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Actions */}
                          <div className="space-y-3">
                            <h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">Quick Actions</h4>
                            <div className="flex flex-wrap gap-2">
                              <button className="inline-flex items-center gap-1.5 px-3 py-2 bg-white border border-neutral-200 rounded-lg text-xs font-medium text-neutral-700 hover:bg-neutral-50 transition-colors">
                                <MessageSquare className="w-3.5 h-3.5" />
                                View Questions
                              </button>
                              <button className="inline-flex items-center gap-1.5 px-3 py-2 bg-white border border-neutral-200 rounded-lg text-xs font-medium text-neutral-700 hover:bg-neutral-50 transition-colors">
                                <FileText className="w-3.5 h-3.5" />
                                Documents
                              </button>
                              <button className="inline-flex items-center gap-1.5 px-3 py-2 bg-white border border-neutral-200 rounded-lg text-xs font-medium text-neutral-700 hover:bg-neutral-50 transition-colors">
                                <ExternalLink className="w-3.5 h-3.5" />
                                View Portal
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
