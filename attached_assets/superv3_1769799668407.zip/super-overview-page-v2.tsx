'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { 
  Building2, 
  Users, 
  Home, 
  FileText, 
  TrendingUp,
  TrendingDown,
  MessageSquare,
  Clock,
  CheckCircle,
  AlertTriangle,
  ArrowRight,
  RefreshCw,
  Loader2,
  Calendar,
  Activity,
  Zap
} from 'lucide-react';

interface DashboardStats {
  tenants: { total: number; newThisMonth: number };
  developments: { total: number; active: number };
  units: { total: number; withPurchaser: number; handedOver: number };
  homeowners: { total: number; activeThisWeek: number };
  questions: { total: number; thisWeek: number; unanswered: number };
  onboarding: { pending: number; inReview: number };
}

interface RecentActivity {
  id: string;
  type: 'question' | 'signup' | 'handover' | 'document' | 'onboarding';
  title: string;
  subtitle: string;
  timestamp: string;
  development?: string;
}

export default function SuperAdminOverview() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [activity, setActivity] = useState<RecentActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/super/dashboard-stats');
      if (!res.ok) throw new Error('Failed to load');
      const data = await res.json();
      setStats(data.stats);
      setActivity(data.recentActivity || []);
    } catch (err) {
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const diff = Date.now() - new Date(timestamp).getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (mins < 60) return `${mins}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const activityIcons = {
    question: MessageSquare,
    signup: Users,
    handover: CheckCircle,
    document: FileText,
    onboarding: Building2
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-brand-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-900">Dashboard</h1>
          <p className="text-neutral-500 mt-1">Platform overview and key metrics</p>
        </div>
        <button
          onClick={fetchDashboardData}
          className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-neutral-200 rounded-lg text-sm font-medium text-neutral-700 hover:bg-neutral-50 transition-all duration-150"
        >
          <RefreshCw className="w-4 h-4" />
          Refresh
        </button>
      </div>

      {/* Action Required Banner */}
      {stats && (stats.onboarding.pending > 0 || stats.questions.unanswered > 0) && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-medium text-amber-900">Action Required</h3>
              <div className="mt-1 space-y-1">
                {stats.onboarding.pending > 0 && (
                  <p className="text-sm text-amber-700">
                    {stats.onboarding.pending} onboarding submission{stats.onboarding.pending !== 1 ? 's' : ''} awaiting review
                    <Link href="/super/onboarding-submissions" className="ml-2 underline hover:no-underline">
                      Review now →
                    </Link>
                  </p>
                )}
                {stats.questions.unanswered > 0 && (
                  <p className="text-sm text-amber-700">
                    {stats.questions.unanswered} question{stats.questions.unanswered !== 1 ? 's' : ''} need attention
                    <Link href="/super/analytics/questions" className="ml-2 underline hover:no-underline">
                      View questions →
                    </Link>
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Developers */}
        <Link href="/super/tenants" className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250">
          <div className="flex items-center justify-between mb-3">
            <div className="p-2 bg-brand-50 rounded-lg">
              <Building2 className="w-5 h-5 text-brand-600" />
            </div>
            {stats?.tenants.newThisMonth && stats.tenants.newThisMonth > 0 && (
              <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                +{stats.tenants.newThisMonth} this month
              </span>
            )}
          </div>
          <p className="text-3xl font-bold text-neutral-900">{stats?.tenants.total || 0}</p>
          <p className="text-sm text-neutral-500 mt-1">Developers</p>
        </Link>

        {/* Developments */}
        <Link href="/super/developments" className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250">
          <div className="flex items-center justify-between mb-3">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Home className="w-5 h-5 text-blue-600" />
            </div>
            <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
              {stats?.developments.active || 0} active
            </span>
          </div>
          <p className="text-3xl font-bold text-neutral-900">{stats?.developments.total || 0}</p>
          <p className="text-sm text-neutral-500 mt-1">Developments</p>
        </Link>

        {/* Units */}
        <Link href="/super/units" className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250">
          <div className="flex items-center justify-between mb-3">
            <div className="p-2 bg-emerald-50 rounded-lg">
              <FileText className="w-5 h-5 text-emerald-600" />
            </div>
          </div>
          <p className="text-3xl font-bold text-neutral-900">{stats?.units.total || 0}</p>
          <p className="text-sm text-neutral-500 mt-1">Total Units</p>
          <div className="mt-2 flex gap-3 text-xs">
            <span className="text-neutral-500">{stats?.units.withPurchaser || 0} assigned</span>
            <span className="text-emerald-600">{stats?.units.handedOver || 0} handed over</span>
          </div>
        </Link>

        {/* Questions */}
        <Link href="/super/analytics" className="bg-white border border-gold-100 rounded-lg p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-250">
          <div className="flex items-center justify-between mb-3">
            <div className="p-2 bg-purple-50 rounded-lg">
              <MessageSquare className="w-5 h-5 text-purple-600" />
            </div>
            {stats?.questions.thisWeek && stats.questions.thisWeek > 0 && (
              <span className="text-xs font-medium text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full">
                {stats.questions.thisWeek} this week
              </span>
            )}
          </div>
          <p className="text-3xl font-bold text-neutral-900">{stats?.questions.total || 0}</p>
          <p className="text-sm text-neutral-500 mt-1">Questions Asked</p>
        </Link>
      </div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Actions */}
        <div className="bg-white border border-gold-100 rounded-lg p-6 shadow-sm">
          <h2 className="font-semibold text-neutral-900 mb-4">Quick Actions</h2>
          <div className="space-y-2">
            <Link 
              href="/super/projects/new"
              className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg hover:bg-brand-50 hover:border-brand-200 border border-transparent transition-colors group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white rounded-lg shadow-sm">
                  <Building2 className="w-4 h-4 text-brand-600" />
                </div>
                <span className="font-medium text-neutral-700">Create New Development</span>
              </div>
              <ArrowRight className="w-4 h-4 text-neutral-400 group-hover:text-brand-500 transition-colors" />
            </Link>
            
            <Link 
              href="/super/developer-codes"
              className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg hover:bg-brand-50 border border-transparent transition-colors group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white rounded-lg shadow-sm">
                  <Zap className="w-4 h-4 text-amber-600" />
                </div>
                <span className="font-medium text-neutral-700">Generate Invitation Code</span>
              </div>
              <ArrowRight className="w-4 h-4 text-neutral-400 group-hover:text-brand-500 transition-colors" />
            </Link>
            
            <Link 
              href="/super/onboarding-submissions"
              className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg hover:bg-brand-50 border border-transparent transition-colors group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white rounded-lg shadow-sm">
                  <FileText className="w-4 h-4 text-blue-600" />
                </div>
                <span className="font-medium text-neutral-700">Review Onboarding Submissions</span>
                {stats?.onboarding.pending && stats.onboarding.pending > 0 && (
                  <span className="text-xs font-medium text-white bg-amber-500 px-2 py-0.5 rounded-full">
                    {stats.onboarding.pending}
                  </span>
                )}
              </div>
              <ArrowRight className="w-4 h-4 text-neutral-400 group-hover:text-brand-500 transition-colors" />
            </Link>
            
            <Link 
              href="/super/units"
              className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg hover:bg-brand-50 border border-transparent transition-colors group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white rounded-lg shadow-sm">
                  <Home className="w-4 h-4 text-emerald-600" />
                </div>
                <span className="font-medium text-neutral-700">Manage Units</span>
              </div>
              <ArrowRight className="w-4 h-4 text-neutral-400 group-hover:text-brand-500 transition-colors" />
            </Link>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white border border-gold-100 rounded-lg p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-neutral-900">Recent Activity</h2>
            <Link href="/super/activity" className="text-sm text-brand-600 hover:text-brand-700">
              View all
            </Link>
          </div>
          
          {activity.length === 0 ? (
            <div className="text-center py-8">
              <Activity className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
              <p className="text-sm text-neutral-500">No recent activity</p>
            </div>
          ) : (
            <div className="space-y-3">
              {activity.slice(0, 5).map((item) => {
                const Icon = activityIcons[item.type] || Activity;
                return (
                  <div key={item.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-neutral-50 transition-colors">
                    <div className="p-1.5 bg-neutral-100 rounded-lg">
                      <Icon className="w-3.5 h-3.5 text-neutral-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-neutral-900 truncate">{item.title}</p>
                      <p className="text-xs text-neutral-500">{item.subtitle}</p>
                    </div>
                    <span className="text-xs text-neutral-400 whitespace-nowrap">
                      {formatTimeAgo(item.timestamp)}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Platform Health */}
      <div className="bg-white border border-gold-100 rounded-lg p-6 shadow-sm">
        <h2 className="font-semibold text-neutral-900 mb-4">Platform Health</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-emerald-50 rounded-lg">
            <div className="w-3 h-3 bg-emerald-500 rounded-full mx-auto mb-2" />
            <p className="text-sm font-medium text-emerald-900">Database</p>
            <p className="text-xs text-emerald-600">Healthy</p>
          </div>
          <div className="text-center p-4 bg-emerald-50 rounded-lg">
            <div className="w-3 h-3 bg-emerald-500 rounded-full mx-auto mb-2" />
            <p className="text-sm font-medium text-emerald-900">AI Assistant</p>
            <p className="text-xs text-emerald-600">Operational</p>
          </div>
          <div className="text-center p-4 bg-emerald-50 rounded-lg">
            <div className="w-3 h-3 bg-emerald-500 rounded-full mx-auto mb-2" />
            <p className="text-sm font-medium text-emerald-900">Storage</p>
            <p className="text-xs text-emerald-600">Available</p>
          </div>
          <div className="text-center p-4 bg-emerald-50 rounded-lg">
            <div className="w-3 h-3 bg-emerald-500 rounded-full mx-auto mb-2" />
            <p className="text-sm font-medium text-emerald-900">Email</p>
            <p className="text-xs text-emerald-600">Connected</p>
          </div>
        </div>
      </div>
    </div>
  );
}
