import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function GET(request: NextRequest) {
  try {
    // Get all units with related data
    const { data: units, error } = await supabaseAdmin
      .from('units')
      .select(`
        id,
        address,
        unit_number,
        unit_type,
        purchaser_name,
        purchaser_email,
        purchaser_phone,
        handover_date,
        status,
        created_at,
        updated_at,
        development_id,
        tenant_id,
        developments(id, name),
        tenants(id, name)
      `)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching units:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    // Transform and enrich unit data
    const enrichedUnits = (units || []).map(unit => {
      // Determine status
      let status: 'available' | 'reserved' | 'sold' | 'handed_over' = 'available';
      
      if (unit.handover_date && new Date(unit.handover_date) <= new Date()) {
        status = 'handed_over';
      } else if (unit.purchaser_name) {
        status = 'sold';
      } else if (unit.status === 'reserved') {
        status = 'reserved';
      }

      return {
        id: unit.id,
        address: unit.address,
        unit_number: unit.unit_number,
        unit_type: unit.unit_type || 'Standard',
        development_id: unit.development_id,
        development_name: (unit as any).developments?.name || 'Unknown',
        tenant_name: (unit as any).tenants?.name || 'Unknown',
        purchaser_name: unit.purchaser_name,
        purchaser_email: unit.purchaser_email,
        purchaser_phone: unit.purchaser_phone,
        status,
        handover_date: unit.handover_date,
        handover_scheduled: !!unit.handover_date,
        created_at: unit.created_at,
        last_activity: unit.updated_at,
        documents_count: 0, // Would come from documents table
        questions_count: 0  // Would come from messages table
      };
    });

    return NextResponse.json({ units: enrichedUnits });
  } catch (err) {
    console.error('Server error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
